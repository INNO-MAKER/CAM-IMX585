# IMX585 Tegra Binary Package — User Manual (v2.0)

Version: v2.0
Date: 2026-06-27
Kernel: 5.15.148-tegra (Jetson Orin Nano, L4T R36.4.4)

This manual describes only behaviour that was verified on the validated
configuration below. Anything not listed here was not tested for this release
and is intentionally not documented rather than estimated.

---

## 1. Overview

Prebuilt IMX585 driver for Jetson Orin Nano. Ships:

- precompiled kernel module (`binary/imx585.ko`),
- device-tree overlays for **CAM0**, **CAM1**, and **dual CAM0+CAM1**
  (`overlays/*.dtbo`),
- ISP configuration (`isp/`),
- customer scripts (`scripts/`) and internal diagnostics (`develop/`).

Operating modes (switchable at runtime):

| Mode    | Description                                              |
|---------|----------------------------------------------------------|
| Normal  | Linear RAW12, low conversion gain (LCG). Default at boot. |
| HCG     | Linear RAW12, high conversion gain — lower noise / better low-light. |
| ClearHDR 12-bit | High dynamic range, gradation-compressed 12-bit. |
| ClearHDR 16-bit | High dynamic range, 16-bit.                      |

HCG and ClearHDR are opt-in; Normal is active after every boot.

---

## 2. Validated configuration

- **Camera:** CAM0, single module, 2-lane @ 1188 Mbps/lane.
- **Framerate:** 20 fps @ 4K (3840×2160); 40 fps @ 1080p (1920×1080, 2×2 binned).
- **Modes (mono module, V4L2 capture):** Normal, HCG, ClearHDR 12-bit, and
  ClearHDR 16-bit each produce real images at 4K.

CAM1 and dual CAM0+CAM1 overlays are included. Dual two-camera operation needs
two modules and was not benchmarked in this release.

---

## 3. Installation

```bash
cd imx585_tegra_binary_1188_working_5.15.148_20260627_v2_0
sudo ./install_binary.sh
```

The installer copies the module and overlays into place, auto-stamps each
overlay's CSI header name for this machine, installs the ISP config, configures
module autoload, and installs + enables `imx585-reload.service` (loads Normal
mode at boot). It does **not** edit `/boot/extlinux/extlinux.conf`.

### Activate a camera overlay (jetson-io)

```bash
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX585 CAM0'
sudo reboot
```

Header 2 is the CSI connector. Available names:
`Camera IMX585 CAM0` · `Camera IMX585 CAM1` · `Dual Camera IMX585 CAM0 CAM1`.
Enable one at a time, then reboot.

### Verify after reboot

```bash
./scripts/switch_mode.sh status            # -> Current mode: Normal LCG
v4l2-ctl --list-devices                     # imx585 video node present
```

---

## 4. Choosing the right path

- **Mono module → use the Argus mono scripts** (`preview_argus_mono.sh`,
  `preview_argus_mono_hdr.sh`). They run through the Argus ISP, which produces a
  clean image (the ISP corrects the sensor's inherent fixed-pattern row noise).
  The scripts force GRAY8 so the mono data does not pick up a colour cast.
  - A raw, full-resolution V4L2 path is **also** provided (`preview_mono.sh`,
    `capture_mono_image.sh`) for applications that need raw luminance or higher
    sharpness. It is unprocessed, so it shows the sensor's **fixed-pattern row
    noise** (~0.5% of signal, most visible on high-contrast content with
    aggressive level stretching). Use 4K (1080p is 2×2 binned and shows it more).
- **Colour module → use the Argus colour scripts** (`preview_argus.sh`,
  `capture_argus_image.sh`, `capture_argus_video.sh`).

The fixed-pattern row noise on the raw mono path is a **sensor characteristic**,
not a driver fault — verified identical across driver versions, both CSI ports,
and both link rates. The Argus ISP removes it; that is why the Argus mono path is
recommended for a clean image.

---

## 5. Switching modes

Always use `switch_mode.sh` — it stops nvargus, reloads the module with the new
mode, and restarts nvargus in one step:

```bash
./scripts/switch_mode.sh status            # show current mode (no root)
sudo ./scripts/switch_mode.sh normal       # linear LCG (default)
sudo ./scripts/switch_mode.sh hcg          # linear HCG (low-noise / low-light)
sudo ./scripts/switch_mode.sh hdr12        # ClearHDR 12-bit
sudo ./scripts/switch_mode.sh hdr16        # ClearHDR 16-bit
```

---

## 6. Mono module — preview and capture

### Recommended: Argus mono preview (clean image)

```bash
DISPLAY=:0 ./scripts/preview_argus_mono.sh 1080p      # live mono preview
DISPLAY=:0 ./scripts/preview_argus_mono.sh 4k
DISPLAY=:0 ./scripts/preview_argus_mono_hdr.sh 4k     # mono ClearHDR preview
```

These use the Argus ISP (clean, fixed-pattern noise corrected) and force GRAY8 so
the mono data has no colour cast. **Argus requires `nvargus-daemon` running** (the
default). If a prior raw-V4L2 session left it stopped:
`sudo systemctl start nvargus-daemon`.

`preview_argus_mono_hdr.sh` previews ClearHDR with a **locked** exposure (Argus
auto-exposure drives HDR frames to black, so it is locked). Pass tunables as
`KEY=VALUE` in any order; resolution is case-insensitive and a bare integer is the
duration in seconds, e.g.
`./scripts/preview_argus_mono_hdr.sh 4k 10 EXPOSURE_MS=1`.

| Parameter     | Default | Range (usable)                | Notes |
|---------------|---------|-------------------------------|-------|
| `EXPOSURE_MS` | `0.3`   | ~0.25 … 1000/fps (≈100 @ 4K)  | **Main brightness knob.** Below ~0.25 ms Argus drops frames; above one frame period it also drops frames. Raise for a dark room, lower for a bright one. |
| `EXPOSURE_NS` | 300000  | same knob in ns               | `0.3 ms = 300000`. Use `EXPOSURE_MS` instead unless you need ns. |
| `GAIN`        | `1`     | 1 … 80                        | Analog gain. **Weak lever in ClearHDR** (gradation-compressed output) — fine-trim only. |
| `ISP_DGAIN`   | `1`     | 1 … 256                       | ISP digital gain; minor effect. |
| `FRAMERATE`   | 10/1 (4K), 30/1 (1080p) | ≤ mode cap        | Higher than the mode supports makes Argus abort. |

> ClearHDR output is bright even at short exposure, so the default is a low
> 0.3 ms tuned for a **lit / daylight** room. **Too bright → lower `EXPOSURE_MS`;
> too dark → raise it.** GAIN barely changes brightness here.

```bash
DISPLAY=:0 ./scripts/preview_argus_mono_hdr.sh 4k EXPOSURE_MS=1     # darker room
DISPLAY=:0 ./scripts/preview_argus_mono_hdr.sh 4k EXPOSURE_MS=0.2   # very bright scene
DISPLAY=:0 ./scripts/preview_argus_mono_hdr.sh 4k 10 GAIN=8         # 10 s, more gain
```

### Optional: raw full-resolution V4L2 preview

```bash
DISPLAY=:0 ./scripts/preview_mono.sh 4k
```

Use this when you need raw full-res luminance / maximum sharpness. It is
unprocessed, so it shows the sensor's fixed-pattern row noise (see §4); prefer
4K. `preview_mono.sh` stops nvargus for direct V4L2 access while previewing, and
on exit (normal end, window close, or Ctrl-C) automatically reloads the module
and restarts nvargus — no manual cleanup is needed afterwards.

Useful options (environment variables):

| Variable    | Default | Meaning                                        |
|-------------|---------|------------------------------------------------|
| `EXPOSURE`  | 10000   | Exposure (sensor units).                        |
| `GAIN`      | 0       | Gain.                                            |
| `OVERRIDE_ENABLE` | 1 | Apply the manual `EXPOSURE`/`GAIN` above. Set to 0 to use defaults. |
| `PREVIEW_SCALE` | 0.5 (4K) | Display scale for the software preview.      |
| `DURATION`  | 0       | Seconds to run; 0 = until you quit.             |

> Manual `EXPOSURE`/`GAIN` only take effect when `OVERRIDE_ENABLE=1` (the
> default). With `OVERRIDE_ENABLE=0` the manual values are ignored.

### Single-frame capture

```bash
./scripts/capture_mono_image.sh 4k /tmp/frame.png     # PNG (also .pgm / .jpg)
```

Works in every mode — switch first with `switch_mode.sh`, then capture. For
ClearHDR, lower the exposure if the frame is bright, e.g.:

```bash
sudo ./scripts/switch_mode.sh hdr12
EXPOSURE=5000 ./scripts/capture_mono_image.sh 4k /tmp/hdr12.png
```

---

## 7. Colour module — preview and capture (Argus)

```bash
DISPLAY=:0 ./scripts/preview_argus.sh 1080p           # live colour preview
./scripts/capture_argus_image.sh 4k /tmp/photo.jpg     # colour JPEG
./scripts/capture_argus_video.sh 1080p /tmp/v.mp4 30   # colour MP4 (30 s)
```

### Colour ClearHDR preview

`preview_argus_hdr.sh` previews ClearHDR on the colour module with a **locked**
exposure (Argus auto-exposure drives HDR frames to black, so it is locked). It
takes the same tunables as the mono HDR script — pass them as `KEY=VALUE` in any
order; resolution is case-insensitive and a bare integer is the duration:

```bash
DISPLAY=:0 ./scripts/preview_argus_hdr.sh 4k                    # bright room, defaults
DISPLAY=:0 ./scripts/preview_argus_hdr.sh 4k EXPOSURE_MS=1      # darker room
DISPLAY=:0 ./scripts/preview_argus_hdr.sh 4k 10 GAIN=8          # 10 s, more gain
```

| Parameter     | Default | Range (usable)               | Notes |
|---------------|---------|------------------------------|-------|
| `EXPOSURE_MS` | `0.3`   | ~0.25 … 1000/fps (≈100 @ 4K) | **Main brightness knob.** Below ~0.25 ms or above one frame period, Argus drops frames. Raise for a dark room, lower for a bright one. |
| `EXPOSURE_NS` | 300000  | same knob in ns              | `0.3 ms = 300000`. |
| `GAIN`        | `1`     | 1 … 80                       | **Weak lever in ClearHDR** (gradation-compressed) — fine-trim only. |
| `ISP_DGAIN`   | `1`     | 1 … 256                      | Minor effect. |
| `FRAMERATE`   | 10/1 (4K), 30/1 (1080p) | ≤ mode cap       | Higher than the mode supports makes Argus abort. |

> Same as mono HDR: the output is bright even at short exposure, so the default
> is a low 0.3 ms for a lit/daylight room. **Too bright → lower `EXPOSURE_MS`;
> too dark → raise it.**

---

## 8. Troubleshooting

| Symptom | Action |
|---------|--------|
| jetson-io doesn't list the overlay | Confirm `install_binary.sh` ran and the board rebooted; re-run `config-by-hardware.py -l`. |
| No video node after reboot | Check the overlay is the active one in jetson-io; `./scripts/switch_mode.sh status`. |
| Argus mono fails: "Connecting to nvargus-daemon ... Connection refused" | nvargus-daemon is stopped (a prior V4L2 session stops it). `sudo systemctl start nvargus-daemon`, then retry. Argus needs it running; V4L2 needs it stopped. |
| Raw V4L2 mono shows faint horizontal lines (fixed-pattern row noise) | Sensor characteristic. For a clean image use `preview_argus_mono.sh` (Argus ISP corrects it); if staying on V4L2, use 4K. |
| Mono image looks soft | The Argus mono path applies ISP processing (slightly softer). For maximum sharpness use the raw V4L2 path (`preview_mono.sh 4k`), accepting the row noise above. |
| ClearHDR Argus preview too bright / too dark | It uses a locked exposure. Lower `EXPOSURE_MS` if too bright, raise it if too dark (e.g. `preview_argus_hdr.sh 4k EXPOSURE_MS=1`). GAIN has little effect in ClearHDR. |
| ClearHDR V4L2 capture looks too bright | Lower `EXPOSURE` (e.g. `EXPOSURE=5000 ./scripts/capture_mono_image.sh 4k out.png`). |
| Camera unresponsive after a manual V4L2 session | `sudo systemctl restart imx585-reload.service` (preview_mono.sh does this automatically). |

---

## 9. Files

```
install_binary.sh          One-step installer
binary/imx585.ko           Precompiled kernel module
overlays/*.dtbo            CAM0 / CAM1 / dual device-tree overlays
isp/                       ISP configuration
imx585-reload.service      Boot-time reload service (Normal mode)
scripts/                   Customer scripts (preview / capture / switch / install)
develop/                   Internal diagnostics (not for end users)
README.md                  Quick reference
USER_MANUAL.md             This file
```
