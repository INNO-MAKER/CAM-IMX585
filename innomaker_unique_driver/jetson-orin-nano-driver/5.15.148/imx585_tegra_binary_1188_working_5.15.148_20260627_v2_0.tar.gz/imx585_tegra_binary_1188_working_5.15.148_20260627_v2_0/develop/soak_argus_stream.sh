#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-1080p}"
DURATION="${2:-30}"
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-}"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160|native4k|full4k|3856x2180} [duration_seconds]" >&2
		exit 2
		;;
esac

# Default framerate by resolution (4-lane single-camera). Env FRAMERATE overrides.
if [ -z "${FRAMERATE}" ]; then
	if [ "${SENSOR_MODE}" -eq 1 ]; then FRAMERATE="60/1"; else FRAMERATE="30/1"; fi
fi
FRAMES_PER_SECOND_NUM="${FRAMERATE%%/*}"
FRAMES_PER_SECOND_DEN="${FRAMERATE##*/}"

if ! [[ "${DURATION}" =~ ^[0-9]+$ ]] || [ "${DURATION}" -lt 1 ]; then
	echo "duration_seconds must be a positive integer" >&2
	exit 2
fi

NUM_BUFFERS=$(((DURATION * FRAMES_PER_SECOND_NUM + FRAMES_PER_SECOND_DEN - 1) / FRAMES_PER_SECOND_DEN))

gst-launch-1.0 -e \
	nvarguscamerasrc sensor-id="${SENSOR_ID}" sensor-mode="${SENSOR_MODE}" num-buffers="${NUM_BUFFERS}" \
	! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
	! fpsdisplaysink video-sink=fakesink text-overlay=false sync=false fps-update-interval=1000
