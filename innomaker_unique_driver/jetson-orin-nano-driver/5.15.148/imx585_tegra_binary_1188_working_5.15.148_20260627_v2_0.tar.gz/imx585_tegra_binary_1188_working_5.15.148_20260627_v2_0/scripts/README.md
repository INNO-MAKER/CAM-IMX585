# IMX585 Driver Scripts (v2.0)

Customer-facing scripts. Internal diagnostics live in `../develop/`.

## Quick reference

### Mono module
| Script | Purpose |
|--------|---------|
| `preview_argus_mono.sh [1080p\|4k] [seconds]` | **Recommended** live mono preview (Argus ISP, clean; GRAY8). Needs nvargus-daemon running. |
| `preview_argus_mono_hdr.sh [4k\|1080p] [seconds] [EXPOSURE_MS=N] [GAIN=N]` | Mono ClearHDR preview (Argus, locked exposure). Brightness via `EXPOSURE_MS` (ranges below). |
| `preview_mono.sh [4k\|1080p] [seconds]` | Optional raw full-res V4L2 preview (sharper, but shows sensor row FPN). Defaults to 4K. Auto-restores the camera on exit. |
| `capture_mono_image.sh [4k\|1080p] [out.png\|.pgm\|.jpg]` | Raw single mono frame (V4L2). Works in every mode. |

### Colour module — Argus
| Script | Purpose |
|--------|---------|
| `preview_argus.sh [1080p\|4k] [seconds]` | Live colour preview. |
| `preview_argus_hdr.sh [4k\|1080p] [seconds] [EXPOSURE_MS=N] [GAIN=N]` | Colour ClearHDR preview (locked exposure). Same tunables/ranges as `preview_argus_mono_hdr.sh` (below). |
| `capture_argus_image.sh [1080p\|4k] [out.jpg]` | Colour JPEG. |
| `capture_argus_video.sh [1080p\|4k] [out.mp4] [seconds]` | Colour MP4. |
| `capture_v4l2_image.sh [1080p\|4k] [out.raw]` | Raw colour frame via V4L2. |

### Mode switching
| Script | Purpose |
|--------|---------|
| `switch_mode.sh {normal\|hcg\|hdr12\|hdr16\|status}` | Switch NORMAL / HCG / ClearHDR. The only supported way to change mode. `status` needs no root. |

### Install / configure
| Script | Purpose |
|--------|---------|
| `install_isp.sh` / `install_starter_isp.sh` | Install ISP override / starter tuning. |
| `install_imx585_reload_service.sh` | Install the boot-time reload service (Normal mode). |
| `configure_module_autoload.sh` | Configure module autoload. |
| `configure_extlinux_overlay.sh` | Headless overlay helper (prefer jetson-io; see README.md). |
| `imx585_raw16_to_pnm.py` | Helper used by `capture_mono_image.sh` (raw → PNM). |

## Notes

- **Mono recommended path = Argus** (`preview_argus_mono.sh`): the ISP corrects
  the sensor's inherent fixed-pattern row noise → clean image. The raw V4L2 path
  (`preview_mono.sh`) is sharper/full-res but shows that row noise.
- **nvargus-daemon**: Argus scripts need it **running**; V4L2 scripts need it
  **stopped**. If Argus says "Connection refused", run
  `sudo systemctl start nvargus-daemon`.
- **`preview_mono.sh` cleans up after itself** — on exit it reloads the module
  and restarts nvargus, so Argus works again immediately afterwards.
- **Use 4K on the raw V4L2 mono path** — 1080p is 2×2 binned and shows the row
  noise more on high-contrast content.
- **Manual exposure/gain** in the V4L2 scripts apply only with
  `OVERRIDE_ENABLE=1` (the default). Example:
  `EXPOSURE=5000 GAIN=0 ./capture_mono_image.sh 4k /tmp/f.png`.
- **ClearHDR Argus preview tunables** — apply to both `preview_argus_hdr.sh`
  (colour) and `preview_argus_mono_hdr.sh` (mono). Pass as `KEY=VALUE`, any
  order; ClearHDR locks exposure, and its output is bright even at short exposure:

  | Parameter | Default | Range | Notes |
  |-----------|---------|-------|-------|
  | `EXPOSURE_MS` | 0.3 | ~0.25 … 1000/fps (≈100 @ 4K) | **Main brightness knob.** Too bright → lower; too dark → raise. Below ~0.25 ms or above one frame period, Argus drops frames. |
  | `EXPOSURE_NS` | 300000 | same in ns | `0.3 ms = 300000`. |
  | `GAIN` | 1 | 1 … 80 | Weak lever in ClearHDR; fine-trim only. |
  | `ISP_DGAIN` | 1 | 1 … 256 | Minor effect. |
  | `FRAMERATE` | 10/1 (4K) · 30/1 (1080p) | ≤ mode cap | Above the cap, Argus aborts. |

## Examples

```bash
# Mono preview (recommended: Argus, clean)
DISPLAY=:0 ./preview_argus_mono.sh 1080p

# Mono ClearHDR 12-bit capture (raw V4L2)
sudo ./switch_mode.sh hdr12
EXPOSURE=5000 ./capture_mono_image.sh 4k /tmp/hdr12.png
sudo ./switch_mode.sh normal

# Colour preview + photo
DISPLAY=:0 ./preview_argus.sh 1080p
./capture_argus_image.sh 4k /tmp/photo.jpg
```
