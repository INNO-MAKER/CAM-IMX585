#!/usr/bin/env bash
set -euo pipefail

# IMX585 Argus JPEG capture helper.
#
# Normal mode: lets Argus AE auto-expose.
# ClearHDR mode (auto-detected from /sys/module/imx585/parameters/hdr_mode):
#   pins a default locked exposure/gain because Argus AE misreads HDR luminance
#   and drives the frame to all-black without the lock.
#
# Environment variables (used in HDR mode unless overridden):
#   EXPOSURE_NS  exposure time, nanoseconds       (default 20000000 = 20 ms)
#   GAIN         analog gain, Argus units 1..240  (default 10)
#   ISP_DGAIN    ISP digital gain, 1..256          (default 1)
#   NUM_BUFFERS  number of buffers to capture     (default 60 in HDR, 1 in Normal)
#   SENSOR_ID    nvarguscamerasrc sensor id        (default 0)
#   FRAMERATE    Argus framerate fraction          (default: 4K 30 fps, 1080p 60 fps)
#
# Recommended HDR resolution: 4k (sensor-mode=0). Binned 1080p HDR produces
# all-black Argus output in v1.4 (see USER_MANUAL.md "Known limitations").

MODE="${1:-1080p}"
OUT="${2:-/tmp/imx585_argus_${MODE}.jpg}"
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-}"

EXPOSURE_NS="${EXPOSURE_NS:-20000000}"
GAIN="${GAIN:-10}"
ISP_DGAIN="${ISP_DGAIN:-1}"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160|native4k|full4k|3856x2180} [output.jpg]" >&2
		echo "Env (HDR mode): EXPOSURE_NS=20000000 GAIN=10 ISP_DGAIN=1 NUM_BUFFERS=60" >&2
		exit 2
		;;
esac

# Default framerate by resolution (4-lane single-camera). Env FRAMERATE overrides.
if [ -z "${FRAMERATE}" ]; then
	if [ "${SENSOR_MODE}" -eq 1 ]; then FRAMERATE="60/1"; else FRAMERATE="30/1"; fi
fi

case "${OUT##*.}" in
	jpg|jpeg) ;;
	*)
		echo "Only JPEG output is supported by this Argus helper: ${OUT}" >&2
		exit 2
		;;
esac

HDR_MODE_NOW=0
if [ -r /sys/module/imx585/parameters/hdr_mode ]; then
	HDR_MODE_NOW="$(cat /sys/module/imx585/parameters/hdr_mode)"
fi

EXTRA_SRC_ARGS=()
if [ "${HDR_MODE_NOW}" = "1" ]; then
	NUM_BUFFERS="${NUM_BUFFERS:-60}"
	EXTRA_SRC_ARGS+=(
		aelock=true
		exposuretimerange="${EXPOSURE_NS} ${EXPOSURE_NS}"
		gainrange="${GAIN} ${GAIN}"
		ispdigitalgainrange="${ISP_DGAIN} ${ISP_DGAIN}"
	)
	echo "HDR mode detected: locking exposure=${EXPOSURE_NS} ns gain=${GAIN} dgain=${ISP_DGAIN}; capturing ${NUM_BUFFERS} buffers"
	if [ "${SENSOR_MODE}" = "1" ]; then
		echo "WARNING: HDR + 1080p binned currently produces all-black Argus output (v1.4). Use 4k." >&2
	fi
else
	NUM_BUFFERS="${NUM_BUFFERS:-1}"
fi

rm -f "${OUT}"

gst-launch-1.0 -e \
	nvarguscamerasrc sensor-id="${SENSOR_ID}" sensor-mode="${SENSOR_MODE}" num-buffers="${NUM_BUFFERS}" \
		"${EXTRA_SRC_ARGS[@]}" \
	! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
	! nvjpegenc \
	! filesink location="${OUT}"

echo "Wrote ${OUT}"
