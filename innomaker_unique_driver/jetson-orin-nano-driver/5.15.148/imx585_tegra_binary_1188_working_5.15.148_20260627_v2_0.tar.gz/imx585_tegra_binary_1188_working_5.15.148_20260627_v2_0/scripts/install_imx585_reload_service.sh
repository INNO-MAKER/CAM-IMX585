#!/usr/bin/env bash
# Install IMX585 reload service to fix boot initialization issue

set -euo pipefail

SERVICE_FILE="imx585-reload.service"
SERVICE_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/${SERVICE_FILE}"
SERVICE_DST="/etc/systemd/system/${SERVICE_FILE}"

if [ ! -f "$SERVICE_SRC" ]; then
    echo "ERROR: ${SERVICE_SRC} not found" >&2
    exit 1
fi

echo "Installing IMX585 reload service..."
sudo install -m 0644 "$SERVICE_SRC" "$SERVICE_DST"

echo "Enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable imx585-reload.service

echo ""
echo "Service installed and enabled."
echo "This service will reload imx585 module after boot to ensure proper initialization."
echo ""
echo "To test: sudo systemctl start imx585-reload.service"
echo "To check status: sudo systemctl status imx585-reload.service"
echo ""
echo "Reboot to verify automatic fix."
