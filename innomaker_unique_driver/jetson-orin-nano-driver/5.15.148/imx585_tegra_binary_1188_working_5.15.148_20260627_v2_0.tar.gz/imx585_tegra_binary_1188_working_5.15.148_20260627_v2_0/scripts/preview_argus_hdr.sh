#!/usr/bin/env bash
set -euo pipefail

# IMX585 ClearHDR Argus preview.
#
# In ClearHDR mode the Argus AE algorithm misreads the HDR luminance histogram
# (high max + low mean) as overexposed and drives exposure to minimum, producing
# all-black frames. This script pins a *locked* exposure + gain so the preview is
# usable out of the box.
#
# Usage:
#   preview_argus_hdr.sh [RES] [SECONDS] [KEY=VALUE ...]
#
#   RES        resolution: 4k (default) | 1080p | native4k   (case-insensitive)
#   SECONDS    bare integer = preview duration (0 = run until you quit)
#   KEY=VALUE  tunables, in any order (ranges = usable/verified):
#                EXPOSURE_MS=<ms>    exposure, ms.  range ~0.25 .. (1000/fps) -- default 0.3
#                                    (~0.25 ms floor: below it Argus drops frames;
#                                     upper bound = one frame period, ~100 ms at 4K 10 fps)
#                                    MAIN brightness knob.
#                EXPOSURE_NS=<ns>    same knob in nanoseconds (0.3 ms = 300000)
#                GAIN=<1..80>        analog gain, default 1 -- weak in ClearHDR (gradation-compressed)
#                ISP_DGAIN=<1..256>  ISP digital gain, default 1 (minor effect)
#                FRAMERATE=<n/d>     Argus framerate, default 4K 10 fps / 1080p 30 fps;
#                                    must be <= the mode cap or Argus aborts
#
#   Examples:
#     ./preview_argus_hdr.sh 4k                       # bright room, defaults
#     ./preview_argus_hdr.sh 4k 10                    # 10 s preview
#     ./preview_argus_hdr.sh 4k EXPOSURE_MS=1         # darker room: longer exposure
#     ./preview_argus_hdr.sh 4k EXPOSURE_MS=0.2 GAIN=1   # very bright scene
#
# ClearHDR is gradation-compressed, so its output is bright even at short
# exposure -- EXPOSURE is the strong lever, GAIN only nudges. The default 0.3 ms
# is tuned for a lit / daylight room; RAISE EXPOSURE_MS for a darker scene,
# LOWER it for a brighter one (Argus floor ~0.25 ms; below that it drops frames).
#
# Other env overrides: SENSOR_ID (default 0), PREVIEW_SINK (auto).
#
# This script does NOT change the driver mode — switch first with
#   sudo ./switch_mode.sh hdr12     or
#   sudo ./switch_mode.sh hdr16
#
# Use 4K. Binned 1080p in HDR mode currently produces all-black Argus output
# (driver-side registers are correct; the limitation is in the Argus/VI binned
# pipeline). See USER_MANUAL.md "Known limitations".

MODE="4k"
DURATION=0
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-}"
PREVIEW_SINK="${PREVIEW_SINK:-}"

EXPOSURE_NS="${EXPOSURE_NS:-300000}"   # 0.3 ms; overridden by EXPOSURE_MS if given
GAIN="${GAIN:-1}"
ISP_DGAIN="${ISP_DGAIN:-1}"

# Flexible positional parsing: KEY=VALUE anywhere, a bare integer is the
# duration, anything else is the resolution (case-insensitive).
for arg in "$@"; do
	case "${arg}" in
		*=*)
			key="${arg%%=*}"; val="${arg#*=}"
			case "${key^^}" in
				GAIN)                 GAIN="${val}" ;;
				EXPOSURE_MS)          EXPOSURE_NS="$(awk "BEGIN{printf \"%d\", ${val}*1000000}")" ;;
				EXPOSURE_NS|EXPOSURE) EXPOSURE_NS="${val}" ;;
				ISP_DGAIN)            ISP_DGAIN="${val}" ;;
				FRAMERATE)            FRAMERATE="${val}" ;;
				DURATION|SECONDS)     DURATION="${val}" ;;
				*) echo "Unknown option: ${key}" >&2; exit 2 ;;
			esac
			;;
		*[!0-9]*|'') MODE="${arg,,}" ;;
		*)           DURATION="${arg}" ;;
	esac
done
# EXPOSURE_MS env var (not positional) also wins over the ns default.
if [ -n "${EXPOSURE_MS:-}" ]; then
	EXPOSURE_NS="$(awk "BEGIN{printf \"%d\", ${EXPOSURE_MS}*1000000}")"
fi

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		echo "WARNING: HDR + 1080p binned Argus is currently all-black (v1.4)." >&2
		echo "         Use 4k for a real HDR preview." >&2
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 [4k|1080p|native4k] [seconds] [EXPOSURE_MS=N] [GAIN=N] [ISP_DGAIN=N] [FRAMERATE=n/d]" >&2
		echo "  e.g. $0 4k EXPOSURE_MS=1      (darker room)" >&2
		echo "       $0 4k 10 GAIN=5          (10 s preview, gain 5)" >&2
		echo "Defaults: 4k, exposure 0.3 ms, gain 1 (tuned for a lit/daylight room)." >&2
		exit 2
		;;
esac

# Default framerate by resolution. ClearHDR halves the effective rate, so use half of
# the normal 2-lane@1188 caps (4K 20 -> 10; binned 60 -> 30). Requesting more than the
# mode supports makes Argus abort ("Frame Rate specified is greater than supported").
# Env FRAMERATE overrides.
if [ -z "${FRAMERATE}" ]; then
	if [ "${SENSOR_MODE}" -eq 1 ]; then FRAMERATE="30/1"; else FRAMERATE="10/1"; fi
fi
FRAMES_PER_SECOND_NUM="${FRAMERATE%%/*}"
FRAMES_PER_SECOND_DEN="${FRAMERATE##*/}"

if ! [[ "${DURATION}" =~ ^[0-9]+$ ]]; then
	echo "duration_seconds must be a non-negative integer; use 0 for continuous preview" >&2
	exit 2
fi

if [ -r /sys/module/imx585/parameters/hdr_mode ]; then
	HDR_MODE_NOW="$(cat /sys/module/imx585/parameters/hdr_mode)"
	if [ "${HDR_MODE_NOW}" != "1" ]; then
		echo "WARNING: imx585 hdr_mode=${HDR_MODE_NOW}, not 1." >&2
		echo "         Run 'sudo ./switch_mode.sh hdr12' or 'hdr16' first, or this will preview Normal mode." >&2
	fi
fi

if [ -z "${PREVIEW_SINK}" ]; then
	if gst-inspect-1.0 nv3dsink >/dev/null 2>&1; then
		PREVIEW_SINK="nv3dsink"
	elif gst-inspect-1.0 nveglglessink >/dev/null 2>&1; then
		PREVIEW_SINK="nveglglessink"
	else
		PREVIEW_SINK="autovideosink"
	fi
fi

NUM_BUFFERS_ARG=()
if [ "${DURATION}" -gt 0 ]; then
	NUM_BUFFERS=$(((DURATION * FRAMES_PER_SECOND_NUM + FRAMES_PER_SECOND_DEN - 1) / FRAMES_PER_SECOND_DEN))
	NUM_BUFFERS_ARG=(num-buffers="${NUM_BUFFERS}")
fi

echo "Preview (ClearHDR) mode=${MODE} sensor-mode=${SENSOR_MODE} ${OUT_W}x${OUT_H} framerate=${FRAMERATE}"
echo "  Locked exposure: ${EXPOSURE_NS} ns (= $(awk "BEGIN{printf \"%.2f\", ${EXPOSURE_NS}/1000000}") ms), gain ${GAIN}, ISP dgain ${ISP_DGAIN}"
echo "  Too bright? lower EXPOSURE_MS.  Too dark? raise EXPOSURE_MS."
echo "  Sink: ${PREVIEW_SINK}"

gst-launch-1.0 -e \
	nvarguscamerasrc sensor-id="${SENSOR_ID}" "${NUM_BUFFERS_ARG[@]}" \
		sensor-mode="${SENSOR_MODE}" wbmode=0 \
		aelock=true \
		exposuretimerange="${EXPOSURE_NS} ${EXPOSURE_NS}" \
		gainrange="${GAIN} ${GAIN}" \
		ispdigitalgainrange="${ISP_DGAIN} ${ISP_DGAIN}" \
	! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
	! nvvidconv \
	! "video/x-raw,format=I420,width=${OUT_W},height=${OUT_H},framerate=${FRAMERATE}" \
	! videoconvert \
	! fpsdisplaysink video-sink="${PREVIEW_SINK}" text-overlay=false sync=false fps-update-interval=1000
