#!/usr/bin/env python3
import argparse
import sys
import time

import cv2
import numpy as np


def parse_args():
    parser = argparse.ArgumentParser(
        description="Preview IMX585 RG12 V4L2 frames as software MONO.")
    parser.add_argument("--device", default="/dev/video0")
    parser.add_argument("--sensor-width", type=int, required=True)
    parser.add_argument("--sensor-height", type=int, required=True)
    parser.add_argument("--crop-width", type=int, required=True)
    parser.add_argument("--crop-height", type=int, required=True)
    parser.add_argument("--duration", type=float, default=0.0)
    parser.add_argument("--frames", type=int, default=0)
    parser.add_argument("--raw-bits", type=int, default=12)
    parser.add_argument("--raw-component", choices=("auto", "lo", "hi", "none"),
                        default="none")
    parser.add_argument("--shift-right", type=int, default=4)
    parser.add_argument("--black", type=int, default=64)
    parser.add_argument("--white", type=int, default=4095)
    parser.add_argument("--mono-method", choices=("raw", "bayer2x2", "debayer"),
                        default="raw")
    parser.add_argument("--auto-levels", action="store_true")
    parser.add_argument("--percentile-low", type=float, default=1.0)
    parser.add_argument("--percentile-high", type=float, default=99.0)
    parser.add_argument("--auto-stride", type=int, default=16)
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--window-title", default="IMX585 MONO")
    return parser.parse_args()


def raw_frame_from_cv(frame, width, height):
    expected = width * height * 2
    data = np.asarray(frame)
    if data.dtype == np.uint16 and data.size == width * height:
        return data.reshape(height, width)

    data_u8 = np.ascontiguousarray(data).view(np.uint8).reshape(-1)
    if data_u8.size != expected:
        raise ValueError(f"frame bytes {data_u8.size} != expected {expected}")
    return np.frombuffer(data_u8, dtype="<u2").reshape(height, width)


def select_raw_component(raw, args):
    if args.raw_component == "none":
        return raw, "none"

    mask = (1 << args.raw_bits) - 1
    lo = raw & mask
    hi = raw >> (16 - args.raw_bits)

    if args.raw_component == "lo":
        return lo, "lo"
    if args.raw_component == "hi":
        return hi, "hi"

    lo_p99 = np.percentile(lo[::16, ::16], 99)
    hi_p99 = np.percentile(hi[::16, ::16], 99)
    return (lo, "lo") if lo_p99 >= hi_p99 else (hi, "hi")


def bayer2x2_luma(raw):
    even_h = raw.shape[0] & ~1
    even_w = raw.shape[1] & ~1
    src = raw[:even_h, :even_w].astype(np.uint32)
    block = (
        src[0::2, 0::2] + src[0::2, 1::2] +
        src[1::2, 0::2] + src[1::2, 1::2]
    ) // 4
    return np.repeat(np.repeat(block, 2, axis=0), 2, axis=1).astype(raw.dtype)


def debayer_to_gray(raw):
    """Debayer RGGB Bayer pattern to grayscale using luminance weights.

    Uses standard Rec. 709 weights: Y = 0.2126*R + 0.7152*G + 0.0722*B
    Applied directly on Bayer pattern without full RGB reconstruction.
    """
    h, w = raw.shape
    # Ensure even dimensions for Bayer processing
    h = h & ~1
    w = w & ~1
    raw = raw[:h, :w]

    # Extract Bayer channels (RGGB pattern)
    # R  G1
    # G2 B
    R  = raw[0::2, 0::2].astype(np.float32)  # Red
    G1 = raw[0::2, 1::2].astype(np.float32)  # Green (row 0)
    G2 = raw[1::2, 0::2].astype(np.float32)  # Green (row 1)
    B  = raw[1::2, 1::2].astype(np.float32)  # Blue

    # Average the two green channels
    G = (G1 + G2) / 2.0

    # Apply Rec. 709 luminance weights
    Y = 0.2126 * R + 0.7152 * G + 0.0722 * B

    # Upsample back to full resolution (2x2 blocks)
    Y_full = np.repeat(np.repeat(Y, 2, axis=0), 2, axis=1)

    return Y_full.astype(raw.dtype)


def scale_to_u8(raw, args):
    raw, component = select_raw_component(raw, args)

    if args.shift_right > 0:
        raw = raw >> args.shift_right

    if args.mono_method == "bayer2x2":
        raw = bayer2x2_luma(raw)
    elif args.mono_method == "debayer":
        raw = debayer_to_gray(raw)

    left = max(0, (args.sensor_width - args.crop_width) // 2)
    top = max(0, (args.sensor_height - args.crop_height) // 2)
    crop = raw[top:top + args.crop_height, left:left + args.crop_width]

    if args.auto_levels:
        stride = max(1, args.auto_stride)
        sample = crop[::stride, ::stride].reshape(-1)
        black = int(np.percentile(sample, args.percentile_low))
        white = int(np.percentile(sample, args.percentile_high))
    else:
        black = args.black
        white = args.white

    if white <= black:
        white = black + 1

    out = (crop.astype(np.int32) - black) * 255 // (white - black)
    return np.clip(out, 0, 255).astype(np.uint8), black, white, component


def main():
    args = parse_args()
    cap = cv2.VideoCapture(args.device, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_CONVERT_RGB, 0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.sensor_width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.sensor_height)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc("R", "G", "1", "2"))

    if not cap.isOpened():
        sys.exit(f"ERROR: failed to open {args.device}")

    start = time.monotonic()
    last_report = start
    count = 0

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                sys.exit("ERROR: failed to read frame")

            raw = raw_frame_from_cv(frame, args.sensor_width, args.sensor_height)
            mono, black, white, component = scale_to_u8(raw, args)
            count += 1

            now = time.monotonic()
            if now - last_report >= 2.0:
                fps = count / max(now - start, 0.001)
                print(
                    f"frames={count} fps={fps:.2f} "
                    f"component={component} method={args.mono_method} "
                    f"levels={black}:{white}",
                    file=sys.stderr,
                    flush=True)
                last_report = now

            if not args.headless:
                view = mono
                if args.scale > 0 and args.scale != 1.0:
                    view = cv2.resize(
                        mono, None, fx=args.scale, fy=args.scale,
                        interpolation=cv2.INTER_AREA)
                cv2.imshow(args.window_title, view)
                key = cv2.waitKey(1) & 0xff
                if key in (27, ord("q")):
                    break

            if args.frames > 0 and count >= args.frames:
                break
            if args.duration > 0 and now - start >= args.duration:
                break
    finally:
        cap.release()
        if not args.headless:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
