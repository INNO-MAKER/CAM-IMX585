#!/usr/bin/env bash
# IMX585 mode switcher (full reload — safest path).
#
# Cleanly switches between Normal / ClearHDR 12bit / ClearHDR 16bit by:
#   1. Stopping nvargus-daemon (releases /dev/video0)
#   2. modprobe -r imx585  (clears all driver state)
#   3. modprobe imx585 with new params
#   4. Restarting nvargus-daemon (or leaving it stopped for V4L2-only HDR16)
#
# Why full reload instead of just sysfs param + Argus restart:
#   - sysfs hdr_mode/hdr_bit_depth changes are picked up on next set_mode(),
#     but mixed Argus → V4L2 transitions can leave the sensor in an
#     intermediate state where V4L2 streams hang with no frames delivered.
#   - rmmod fully releases /dev/video0 and resets the tegracam private state.
#   - This is the same path the imx585-reload.service uses at boot.
#
# Usage:
#   sudo ./switch_mode.sh normal             # RAW12 linear LCG, Argus + V4L2
#   sudo ./switch_mode.sh hcg                # RAW12 linear HCG (low-noise), Argus + V4L2
#   sudo ./switch_mode.sh hdr12              # ClearHDR 12bit, Argus + V4L2
#   sudo ./switch_mode.sh hdr16              # ClearHDR 16bit, V4L2 RAW only
#   sudo ./switch_mode.sh hdr16 --no-argus   # same but leave nvargus stopped
#   ./switch_mode.sh status                  # read-only, no root needed

set -euo pipefail

MODE="${1:-status}"
RESTART_ARGUS=1
if [ "${2:-}" = "--no-argus" ]; then
    RESTART_ARGUS=0
fi

SYS_HDR_MODE=/sys/module/imx585/parameters/hdr_mode
SYS_HDR_BD=/sys/module/imx585/parameters/hdr_bit_depth
SYS_HCG=/sys/module/imx585/parameters/hcg

if [[ "$EUID" -ne 0 && "$MODE" != "status" ]]; then
    echo "ERROR: switching modes requires root. Re-run with sudo." >&2
    exit 1
fi

print_status() {
    if [ ! -e "$SYS_HDR_MODE" ]; then
        echo "Current mode: imx585 not loaded"
        return
    fi
    local hdr_mode hdr_bd hcg
    hdr_mode="$(cat "$SYS_HDR_MODE")"
    hdr_bd="$(cat "$SYS_HDR_BD")"
    hcg="$( [ -e "$SYS_HCG" ] && cat "$SYS_HCG" || echo 0 )"
    case "${hdr_mode}:${hdr_bd}" in
        0:*)  if [ "$hcg" = "1" ]; then
                  echo "Current mode: Normal HCG (hdr_mode=0 hcg=1, high conversion gain / low-noise)"
              else
                  echo "Current mode: Normal LCG (hdr_mode=0 hcg=0)"
              fi;;
        1:12) echo "Current mode: ClearHDR 12bit (hdr_mode=1 hdr_bit_depth=12)";;
        1:16) echo "Current mode: ClearHDR 16bit (hdr_mode=1 hdr_bit_depth=16)";;
        *)    echo "Current mode: UNKNOWN (hdr_mode=$hdr_mode hdr_bit_depth=$hdr_bd)";;
    esac
}

switch_to() {
    local params="$1"
    local label="$2"

    echo ">>> Switching to: $label"
    if [ -n "$params" ]; then
        echo "    modprobe params: imx585 $params"
    else
        echo "    modprobe params: imx585  (no HDR params)"
    fi

    systemctl stop nvargus-daemon || true
    sleep 1

    if lsmod | awk '{print $1}' | grep -qx imx585; then
        if ! modprobe -r imx585; then
            echo "ERROR: failed to unload imx585. Active users may be holding /dev/video0." >&2
            if command -v fuser >/dev/null 2>&1; then
                fuser -v /dev/video0 >&2 || true
            fi
            if [ "$RESTART_ARGUS" = "1" ]; then
                systemctl start nvargus-daemon || true
            fi
            exit 2
        fi
        sleep 1
    fi

    # shellcheck disable=SC2086
    if ! modprobe imx585 $params; then
        echo "ERROR: failed to load imx585 with params: $params" >&2
        echo "       Check: sudo dmesg | tail -30" >&2
        if [ "$RESTART_ARGUS" = "1" ]; then
            systemctl start nvargus-daemon || true
        fi
        exit 3
    fi
    sleep 1

    if [ "$RESTART_ARGUS" = "1" ]; then
        systemctl start nvargus-daemon || true
        echo ">>> nvargus-daemon restarted."
    else
        echo ">>> nvargus-daemon left stopped (--no-argus); use V4L2 directly."
    fi

    echo ">>> Done."
    print_status

    if [ -e "$SYS_HDR_MODE" ] && [ "$(cat "$SYS_HDR_MODE")" = "1" ]; then
        echo
        echo "ClearHDR is active. Capture one frame to confirm streaming, e.g.:"
        echo "  ./capture_v4l2_image.sh 4k /tmp/hdr.raw"
    fi
}

case "$MODE" in
    normal|0)
        switch_to "" "Normal (RAW12 linear, LCG)"
        ;;
    hcg)
        switch_to "hcg=1" "Normal HCG (RAW12 linear, high conversion gain / low-noise)"
        ;;
    hdr12|12)
        switch_to "hdr_mode=1 hdr_bit_depth=12" "ClearHDR 12bit (RAW12 compressed, Argus + V4L2)"
        ;;
    hdr16|16)
        switch_to "hdr_mode=1 hdr_bit_depth=16" "ClearHDR 16bit (RAW16 linear, V4L2 RAW only)"
        ;;
    status)
        print_status
        ;;
    *)
        cat >&2 <<EOF
Usage: $0 {normal|hcg|hdr12|hdr16|status} [--no-argus]

  normal       Normal RAW12, LCG (default at boot)
  hcg          Normal RAW12, HCG (high conversion gain, low-noise / low-light)
  hdr12        ClearHDR 12bit (Argus + V4L2)
  hdr16        ClearHDR 16bit (V4L2 RAW only)
  status       Show current mode (no root needed)

  normal/hcg are linear modes (mutually exclusive conversion gain).
  HCG is auto-ignored if ClearHDR is enabled.

Options:
  --no-argus   Skip restarting nvargus-daemon (useful for V4L2-only HDR16 use)
EOF
        exit 1
        ;;
esac
