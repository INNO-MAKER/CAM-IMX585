# IMX585 Tegra Binary Package - v1.5.2 (stable) with ClearHDR 12bit/16bit Support

Build date: 2026-06-17
Kernel ABI validated: 5.15.148-tegra

Prebuilt IMX585 binary release for NVIDIA Jetson Orin Nano (L4T R36.4.4) with **Normal mode (default)** plus **ClearHDR 12bit / 16bit (opt-in)**. Includes precompiled kernel module (.ko), device tree overlays (.dtbo), ISP configuration, and ready-to-use scripts.

**Default mode after install: Normal (RAW12 linear).** Switch to ClearHDR with the helper:
```bash
sudo ./scripts/switch_mode.sh hdr12      # ClearHDR 12bit (Argus, 4K, locked exposure)
sudo ./scripts/switch_mode.sh hdr16      # ClearHDR 16bit (Argus, 4K, locked exposure)
sudo ./scripts/switch_mode.sh normal     # back to Normal
./scripts/switch_mode.sh status          # show current mode
```

## What's New in v1.5.2

- **dtbo install hardened (standard "imx296 way")** — `install_binary.sh` now
  copies the overlays to `/boot`, installs the `.ko`, and **auto-stamps each
  overlay's `jetson-header-name` with this machine's live CSI header name** so
  jetson-io always lists them (BSP-proof across 24pin / 22pin). The installer
  **never touches `/boot/extlinux/extlinux.conf`** — activate the camera with
  NVIDIA jetson-io:
  ```bash
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l
  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX585 CAM1'
  sudo reboot
  ```
- Package name now carries the validated kernel (`5.15.148`) + date + version.

## What's New in v1.5.1

- **Binary package hardening** — the prebuilt module and all package
  documentation/scripts no longer expose internal sensor-register details.
  The driver is functionally identical to v1.5 (same modes, same behavior,
  same kernel ABI); only the verbose register debug output and the
  register-level notes were removed from the binary deliverable.

## What's New in v1.5

- **Mode-specific sensor timing**: Normal and ClearHDR now use
  independently tuned internal timing. This removes a faint grid / watermark
  pattern that could appear at high analog gain in Normal mode on earlier
  releases.
- **HDR-aware exposure / gain limits**: in ClearHDR the driver enforces the
  sensor's HDR exposure floor and analog-gain ceiling, so requests outside
  the valid HDR operating range are clamped instead of silently dropped.
- **New `scripts/preview_argus_mono_hdr.sh`** ⭐ — mono ClearHDR preview
  combining HDR aelock (so Argus AE doesn't drive HDR frames to black) and
  the GRAY8 round-trip (so the Bayer-assumed mono raw doesn't get a colour
  cast from the Argus AWB / CCM).
- **`scripts/` reorganisation** — diagnostic-only helpers moved to
  `develop/` (`check_argus_imx585.sh`, `soak_argus_stream.sh`). The customer
  surface in `scripts/` is now four preview helpers + four capture helpers +
  `switch_mode.sh` + installers, all documented in `scripts/README.md`.
- **Bug fix**: `imx585_raw16_to_pnm.py` is now shipped in `scripts/`. v1.4
  forgot to bundle it, which broke `capture_mono_image.sh` and
  `capture_v4l2_image.sh`.

## Carried over from v1.4

- ClearHDR 12-bit / 16-bit split via `hdr_bit_depth` module parameter.
- `imx585-reload.service` for boot-time driver reload (works around an
  initial-probe race).
- `switch_mode.sh` one-command full reload between Normal / hdr12 / hdr16.
- Default boot mode: Normal (RAW12 linear). ClearHDR is opt-in.

## Features

- **Normal mode (default)**: Standard linear imaging (RAW12), Argus + V4L2 RAW.
- **ClearHDR 12bit / 16bit (opt-in, Argus 4K only)**: high dynamic range via the standard RG12 Argus path. 4K resolution with locked exposure. Binned 1080p HDR and V4L2 RAW HDR have known limitations carried from v1.4 — see USER_MANUAL.md.
- **Mode-specific sensor timing**: Normal and ClearHDR use independently tuned timing (removes a high-gain grid/watermark artifact in Normal).
- **MONO sensor support**: Grayscale pipeline for IMX585 MONO version, including the dedicated `preview_argus_mono_hdr.sh` for mono ClearHDR.
- **Boot initialization service**: Auto-loads Normal mode at boot.
- **Module autoload**: Driver loads automatically at boot.
- **One-command mode switcher**: `scripts/switch_mode.sh`.

## Validated Configuration

- CAM1, 2 lanes, `serial_c`, `/dev/video0`
- Link speed: 720 Mbps/lane (up to 12.5 fps)
- Resolutions: 1080p (1920×1080), 4K (3840×2160)
- Color output via Argus ISP

## Installation

```bash
cd imx585_tegra_binary_720_working_5.15.148_20260617_v1_5_2
sudo ./install_binary.sh
```

The install script:
1. Installs precompiled module to `/lib/modules/5.15.148-tegra/`
2. Installs device tree overlays to `/boot`
3. Installs the ISP configuration
4. Configures module autoload
5. **Installs `imx585-reload.service` and enables it** (loads Normal mode at boot)
6. Restarts the camera services

Configure overlay (required after first install):

```bash
sudo ./scripts/configure_extlinux_overlay.sh
sudo reboot
```

## ⭐ Auto-Boot Service (Default: Normal mode)

After installation, `imx585-reload.service` is enabled and loads the driver in Normal mode on every boot. ClearHDR is opt-in via `switch_mode.sh` after boot.

### Verify after installation

```bash
# Service must be enabled (returns "enabled")
systemctl is-enabled imx585-reload.service

# Service must have run successfully after boot
systemctl status imx585-reload.service

# Module parameters must reflect Normal mode
cat /sys/module/imx585/parameters/hdr_mode      # 0
cat /sys/module/imx585/parameters/hdr_bit_depth # 12 (unused in Normal mode)

# Or one-liner via helper:
./scripts/switch_mode.sh status
# Expected: Current mode: Normal (hdr_mode=0)
```

### Make ClearHDR the boot default

```bash
sudo systemctl edit imx585-reload.service
```

Add (for ClearHDR 12bit):
```ini
[Service]
ExecStart=
ExecStart=/sbin/modprobe imx585 hdr_mode=1 hdr_bit_depth=12
```

To revert to Normal default:
```bash
sudo systemctl revert imx585-reload.service
sudo systemctl daemon-reload
```

## Quick Start

After reboot, Normal mode is already active. Just capture or preview:

```bash
cd scripts

# Preview (Normal mode, color)
DISPLAY=:0 ./preview_argus.sh 1080p

# Preview (Normal mode, mono sensor)
DISPLAY=:0 ./preview_argus_mono.sh 1080p

# Capture image (Normal mode)
./capture_argus_image.sh 1080p /tmp/photo.jpg

# Record video (Normal mode)
./capture_argus_video.sh 1080p /tmp/video.mp4 30
```

See `scripts/README.md` for the full per-script reference and the
**`preview_argus_mono_hdr.sh` scene-tuning table** for mono ClearHDR users.

## Switching Between Modes

Use `switch_mode.sh` — it handles `stop nvargus → rmmod → modprobe → start nvargus` in one command:

```bash
./scripts/switch_mode.sh status          # show current mode
sudo ./scripts/switch_mode.sh normal     # Normal RAW12 (default)
sudo ./scripts/switch_mode.sh hdr12      # ClearHDR 12bit (Argus + V4L2)
sudo ./scripts/switch_mode.sh hdr16      # ClearHDR 16bit (V4L2 RAW only)
```

### After switching to HDR12 or HDR16, capture via Argus at 4K:
```bash
# capture_argus_image.sh detects hdr_mode=1 and pins a default locked exposure;
# override via EXPOSURE_NS=20000000 GAIN=10 if you need a specific operating point.
./scripts/capture_argus_image.sh 4k /tmp/hdr.jpg
```

Use 4K (`sensor-mode=0`). Binned 1080p HDR Argus is currently all-black (the sensor is configured correctly; the issue is in the Argus binned pipeline). V4L2 RAW HDR is also not recommended — `v4l2-ctl --set-ctrl=gain` is not propagated by tegracam in HDR, so HDR data collapses. Use Argus 4K for HDR.

## Documentation

- `USER_MANUAL.md` - Complete user manual
- `scripts/README.md` - Per-script reference and scene-tuning tables
- `develop/README.md` - Internal diagnostic helpers (not for end users)
- `README.md` - This file (quick reference)

## Version History

**v1.5.1 (2026-06-14)** — Binary package hardening
- Removed internal sensor-register details from the prebuilt module, docs, and scripts. Driver functionally identical to v1.5.

**v1.5 (2026-06-09)** — Stable release (timing fix + scripts reorg)
- Mode-specific sensor timing (removes high-gain grid/watermark in Normal).
- HDR-aware exposure / gain clamping in ClearHDR.
- New `preview_argus_mono_hdr.sh` (mono ClearHDR with locked AE + GRAY8).
- Scripts reorganized: customer-facing in `scripts/`, diagnostics in `develop/`.
- `scripts/README.md` written for customer reference.
- Bug fix: `imx585_raw16_to_pnm.py` is now shipped (required by mono / V4L2
  capture scripts; v1.4 forgot to bundle it).

**v1.4 (2026-06-08)** — ClearHDR 12bit/16bit working via Argus 4K
- ClearHDR 12bit driver fix (self-contained mode tables, eliminates v1.3 stuck test-pattern).
- ClearHDR 16bit refactor: delivered through the standard RG12 Argus path with the sensor's second-stage gradation compression disabled, replacing an earlier container format that Argus could not parse.
- Argus AE quirk in HDR mode documented; capture/preview scripts pin a default locked exposure.
- Module parameters: `hdr_mode` (0/1) and `hdr_bit_depth` (12/16).
- **Default mode: Normal** — auto-boot service loads `modprobe imx585` (no HDR params).
- `scripts/switch_mode.sh` for one-command mode switching.
- `install_binary.sh` now installs reload service.

**v1.3 (2026-06-06)** - ClearHDR initial support (had test pattern issue)

**v1.2 (2026-06-01)** - Boot initialization service

**v1.1 (2026-05-31)** - ISP starter tuning profile

**v1.0 (2026-05-30)** - Initial release
