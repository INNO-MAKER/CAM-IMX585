# IMX585 Tegra Binary Package — v2.0

Build date: 2026-06-27
Kernel ABI: 5.15.185-tegra (Jetson Orin Nano, L4T R36.4.4)

Prebuilt IMX585 binary release for NVIDIA Jetson Orin Nano. Includes the
precompiled kernel module (`.ko`), device-tree overlays (`.dtbo`) for **CAM0,
CAM1, and dual CAM0+CAM1**, ISP configuration, and ready-to-use scripts.

Default mode after install: **Normal (RAW12 linear)**. HCG and ClearHDR are
opt-in via `scripts/switch_mode.sh`.

> Scope of this document: every command below was run on the validated
> configuration (see "Validated configuration"). Behaviour outside that
> configuration is not described here rather than guessed at.

## What's new in v2.0

- **CAM0 overlay added** ⭐ — this release ships a working **CAM0** overlay in
  addition to CAM1. Previous releases only routed CAM1 correctly.
- **Dual CAM0+CAM1 overlay** — a dual-camera overlay is included alongside the
  single-camera CAM0 / CAM1 overlays.
- **Higher framerate (2-lane @ 1188 Mbps/lane)** ⭐ — single-camera CAM0 reaches
  **20 fps @ 4K** and **40 fps @ 1080p** (verified on hardware).
- **NORMAL / HCG / ClearHDR switching** ⭐ — one command switches the sensor
  between linear Normal, linear **HCG** (high-conversion-gain, low-noise /
  low-light), and **ClearHDR** (12-bit and 16-bit):
  ```bash
  sudo ./scripts/switch_mode.sh normal     # linear, LCG (default at boot)
  sudo ./scripts/switch_mode.sh hcg         # linear, HCG (low-noise / low-light)
  sudo ./scripts/switch_mode.sh hdr12       # ClearHDR 12-bit
  sudo ./scripts/switch_mode.sh hdr16       # ClearHDR 16-bit
  ./scripts/switch_mode.sh status           # show current mode (no root)
  ```
  Mode switching is **only** done through `switch_mode.sh` — it performs the full
  stop-nvargus → reload-module → start-nvargus sequence so the change always
  takes effect cleanly.
- **Mono support** ⭐ — the **recommended mono preview is `preview_argus_mono.sh`**
  (and `preview_argus_mono_hdr.sh` for ClearHDR). It runs through the Argus ISP,
  which delivers a clean image. A full-resolution V4L2 path (`preview_mono.sh`,
  `capture_mono_image.sh`) is also provided for applications that need raw
  full-res luminance — note it shows a faint **fixed-pattern row noise** that is
  inherent to the sensor (the Argus ISP corrects it; see "Mono notes" below).
  `preview_mono.sh` defaults to 4K and auto-restores the camera service on exit.

## Validated configuration (what was tested for this release)

- **Camera: CAM0, single module, 2-lane @ 1188 Mbps/lane.**
- **Framerate:** 20 fps @ 4K (3840×2160), 40 fps @ 1080p (1920×1080, 2×2 binned).
- **Modes, mono module, V4L2 capture:** Normal, HCG, ClearHDR 12-bit, and
  ClearHDR 16-bit each produce real images at 4K.
- **Mono notes:** the mono sensor has an inherent **fixed-pattern row noise**
  (~0.5% of signal, fixed per frame) that the Argus ISP corrects but the raw
  V4L2 path does not. For a clean mono image use `preview_argus_mono.sh`. If you
  use the raw V4L2 path, prefer **4K** (1080p is 2×2 binned and shows it more on
  high-contrast content). This is a sensor characteristic, not a driver fault —
  verified identical across driver versions, both CSI ports, and both link rates.

Single CAM1 and dual CAM0+CAM1 overlays are included; dual two-camera operation
requires two modules and was not benchmarked in this release.

## Installation

```bash
cd imx585_tegra_binary_1188_working_5.15.185_20260627_v2_0
sudo ./install_binary.sh
```

The installer:
1. Installs the precompiled module to `/lib/modules/5.15.185-tegra/`
2. Copies the overlays to `/boot` and **auto-stamps each overlay's CSI header
   name** with this machine's live value so jetson-io always lists them
3. Installs the ISP configuration
4. Configures module autoload and installs/enables `imx585-reload.service`
   (loads Normal mode at boot)
5. Restarts the camera services

It **never edits `/boot/extlinux/extlinux.conf`**. Activate one overlay with
NVIDIA jetson-io, then reboot:

```bash
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX585 CAM0'
sudo reboot
```

Header 2 is the CSI connector. Pick one of:
`Camera IMX585 CAM0` · `Camera IMX585 CAM1` · `Dual Camera IMX585 CAM0 CAM1`.

## Quick start (after reboot — Normal mode is already active)

```bash
cd scripts

# --- MONO module (recommended: Argus, clean image) ---
DISPLAY=:0 ./preview_argus_mono.sh 1080p   # live mono preview (Argus ISP)
DISPLAY=:0 ./preview_argus_mono_hdr.sh 4k  # mono ClearHDR preview
# Optional raw full-res mono via V4L2 (sharper, but shows sensor row FPN):
DISPLAY=:0 ./preview_mono.sh 4k            # auto-restores the camera on exit
./capture_mono_image.sh 4k /tmp/photo.png  # single mono frame -> PNG/PGM/JPG

# --- COLOUR module: use Argus ---
DISPLAY=:0 ./preview_argus.sh 1080p        # live colour preview
./capture_argus_image.sh 4k /tmp/photo.jpg # colour JPEG
./capture_argus_video.sh 1080p /tmp/v.mp4 30
```

## Switching modes (NORMAL / HCG / ClearHDR)

```bash
./scripts/switch_mode.sh status            # show current mode
sudo ./scripts/switch_mode.sh normal       # linear LCG (default)
sudo ./scripts/switch_mode.sh hcg          # linear HCG (low-noise / low-light)
sudo ./scripts/switch_mode.sh hdr12        # ClearHDR 12-bit
sudo ./scripts/switch_mode.sh hdr16        # ClearHDR 16-bit
```

For the mono module, capture any mode at 4K via V4L2:
```bash
./scripts/capture_mono_image.sh 4k /tmp/frame.png
```

## Documentation

- `USER_MANUAL.md` — full user manual
- `scripts/README.md` — per-script reference
- `develop/README.md` — internal diagnostic helpers (not for end users)

## Version history (summary)

- **v2.0 (2026-06-27)** — CAM0 overlay added; dual CAM0+CAM1 overlay; 2-lane
  @1188 (4K 20 fps / 1080p 40 fps); NORMAL/HCG/ClearHDR switching; mono via V4L2
  (`preview_mono.sh`, 4K, auto-restore on exit).
- **v1.5.x (2026-06)** — stable Normal + ClearHDR line, dtbo install hardened
  (jetson-io, header-name auto-stamp), binary package hardening.
- **v1.0–v1.4 (2026-05/06)** — initial release through ClearHDR bring-up.
