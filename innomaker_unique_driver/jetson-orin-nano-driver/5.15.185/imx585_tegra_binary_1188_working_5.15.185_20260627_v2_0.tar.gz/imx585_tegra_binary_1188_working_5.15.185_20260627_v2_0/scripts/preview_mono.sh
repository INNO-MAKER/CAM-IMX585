#!/usr/bin/env bash
set -euo pipefail

# Default 4K: the mono V4L2 path is clean at 4K. 1080p binned can show a faint
# 2/4-row comb in bright areas (binning-specific), so 4K is the recommended mono mode.
MODE="${1:-4k}"
DURATION="${2:-0}"
DEVICE="${DEVICE:-/dev/video0}"
EXPOSURE="${EXPOSURE:-10000}"
GAIN="${GAIN:-0}"
# override_enable=1 makes the manual EXPOSURE/GAIN above actually reach the sensor.
# With override_enable=0 (tegracam default) they are IGNORED (AE/defaults used).
OVERRIDE_ENABLE="${OVERRIDE_ENABLE:-1}"
FRAME_RATE="${FRAME_RATE:-12500000}"
RAW_COMPONENT="${RAW_COMPONENT:-hi}"
SHIFT_RIGHT="${SHIFT_RIGHT:-0}"
AUTO_LEVELS="${AUTO_LEVELS:-1}"
BLACK="${BLACK:-64}"
WHITE="${WHITE:-4095}"
# MONO sensor: every pixel is a real luminance sample -> use full-res "raw" (no demosaic).
# "debayer" treats the data as RGGB, drops to half-res per quadrant and block-replicates 2x2
# on upscale -> staircase/jaggies (sawtooth) on edges. "bayer2x2" = soft half-res. Default raw.
MONO_METHOD="${MONO_METHOD:-raw}"
# PREVIEW_SCALE default is per-mode (set after the case below): 4K -> 0.5 so the
# CPU/OpenCV software preview keeps up (full-res 4K can't sustain fps -> motion
# ghosting/tearing); 1080p -> 1.0. Override with PREVIEW_SCALE=... anytime.
PREVIEW_SCALE="${PREVIEW_SCALE:-}"
HEADLESS="${HEADLESS:-0}"
FRAMES="${FRAMES:-0}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		SENSOR_W=1928
		SENSOR_H=1090
		CROP_W=1920
		CROP_H=1080
		DEFAULT_SCALE=1.0
		echo "NOTE: 1080p is 2x2 binned and may show a faint horizontal comb in bright" >&2
		echo "      areas on mono. For the cleanest mono image use 4k (the default)." >&2
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		SENSOR_W=3856
		SENSOR_H=2180
		CROP_W=3840
		CROP_H=2160
		DEFAULT_SCALE=0.5
		;;
	*)
		echo "Usage: $0 {4k|3840x2160|2160p|1080p|1920x1080} [duration_seconds]   (default: 4k)" >&2
		echo "Optional env: DEVICE=/dev/video0 EXPOSURE=10000 GAIN=0 OVERRIDE_ENABLE=1 FRAME_RATE=12500000 RAW_COMPONENT=hi SHIFT_RIGHT=0 AUTO_LEVELS=1 BLACK=64 WHITE=4095 MONO_METHOD=raw PREVIEW_SCALE=<4K:0.5,1080p:1.0> HEADLESS=0 FRAMES=0" >&2
		exit 2
		;;
esac

# Resolve per-mode default scale (4K=0.5, 1080p=1.0) unless the user set PREVIEW_SCALE.
PREVIEW_SCALE="${PREVIEW_SCALE:-${DEFAULT_SCALE}}"

if ! [[ "${DURATION}" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
	echo "duration_seconds must be a non-negative number; use 0 for continuous preview" >&2
	exit 2
fi

# On exit (normal end, Ctrl-C, or error) restore the camera automatically so the
# next Argus/capture works with no manual steps: prefer the imx585-reload service
# (stop nvargus -> reload module -> start nvargus), which also clears a wedged VI
# bypass channel that a killed V4L2 stream can leave behind. Falls back to a manual
# reload if the service isn't installed.
RESTORE_DONE=0
restore_camera() {
	[ "${RESTORE_DONE}" = "1" ] && return
	RESTORE_DONE=1
	echo "Restoring camera (reload module + nvargus)..." >&2
	if systemctl list-unit-files 2>/dev/null | grep -q '^imx585-reload\.service'; then
		sudo systemctl restart imx585-reload.service 2>/dev/null || true
	else
		sudo systemctl stop nvargus-daemon 2>/dev/null || true
		sudo modprobe -r imx585 2>/dev/null || true
		sudo modprobe imx585 2>/dev/null || true
		sudo systemctl start nvargus-daemon 2>/dev/null || true
	fi
}
trap restore_camera EXIT INT TERM

# Stop nvargus-daemon to allow V4L2 direct access
echo "Stopping nvargus-daemon for V4L2 access..." >&2
sudo systemctl stop nvargus-daemon 2>/dev/null || true

v4l2-ctl -d "${DEVICE}" \
	--set-ctrl="bypass_mode=0,override_enable=${OVERRIDE_ENABLE},sensor_mode=${SENSOR_MODE},exposure=${EXPOSURE},gain=${GAIN},frame_rate=${FRAME_RATE}" \
	--set-fmt-video="width=${SENSOR_W},height=${SENSOR_H},pixelformat=RG12" >/dev/null

LEVEL_ARGS=(--black "${BLACK}" --white "${WHITE}")
if [ "${AUTO_LEVELS}" = "1" ]; then
	LEVEL_ARGS=(--auto-levels)
fi

HEADLESS_ARG=()
if [ "${HEADLESS}" = "1" ]; then
	HEADLESS_ARG=(--headless)
fi

python3 "${SCRIPT_DIR}/preview_mono_v4l2.py" \
	--device "${DEVICE}" \
	--sensor-width "${SENSOR_W}" --sensor-height "${SENSOR_H}" \
	--crop-width "${CROP_W}" --crop-height "${CROP_H}" \
	--duration "${DURATION}" \
	--frames "${FRAMES}" \
	--raw-component "${RAW_COMPONENT}" \
	--shift-right "${SHIFT_RIGHT}" \
	--mono-method "${MONO_METHOD}" \
	--scale "${PREVIEW_SCALE}" \
	"${LEVEL_ARGS[@]}" \
	"${HEADLESS_ARG[@]}"

# Camera is restored by the EXIT trap (restore_camera) — runs on normal end,
# Ctrl-C, or error, so no manual reload is ever needed after a preview.
