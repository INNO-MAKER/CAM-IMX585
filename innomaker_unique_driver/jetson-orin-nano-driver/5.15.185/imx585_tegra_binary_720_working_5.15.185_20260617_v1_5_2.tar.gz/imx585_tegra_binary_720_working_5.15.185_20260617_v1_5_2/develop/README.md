# IMX585 develop/ — internal diagnostics

These scripts are kept in the release package for driver-development and
support workflows. They are not part of the customer-facing surface and are
not documented in `scripts/README.md`.

- `check_argus_imx585.sh` — dumps `dmesg | grep imx585` plus nvargus-daemon
  status / journal lines. Quick first-pass when triaging a preview failure.
- `soak_argus_stream.sh` — runs an Argus capture continuously to look for
  capture / VI dropouts over time.

If a customer hits a reproducible issue, asking them to run
`./develop/check_argus_imx585.sh > issue.log` is the fastest way to collect
the relevant context.
