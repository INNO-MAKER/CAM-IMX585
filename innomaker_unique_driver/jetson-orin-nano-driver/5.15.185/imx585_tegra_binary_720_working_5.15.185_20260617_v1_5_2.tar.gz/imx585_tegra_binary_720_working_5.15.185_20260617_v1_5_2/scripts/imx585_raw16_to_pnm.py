#!/usr/bin/env python3
import argparse
import array
import math
import sys


def parse_args():
    parser = argparse.ArgumentParser(
        description="Crop IMX585 unpacked RAW12/16 Bayer and write PGM/PPM.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--width", type=int, required=True)
    parser.add_argument("--height", type=int, required=True)
    parser.add_argument("--crop-width", type=int, required=True)
    parser.add_argument("--crop-height", type=int, required=True)
    parser.add_argument("--left", type=int)
    parser.add_argument("--top", type=int)
    parser.add_argument("--format", choices=("pgm", "ppm"), default="ppm")
    parser.add_argument("--black", type=int, default=64)
    parser.add_argument("--white", type=int, default=4095)
    parser.add_argument("--raw-bits", type=int, default=12)
    parser.add_argument("--raw-component", choices=("auto", "lo", "hi", "none"),
                        default="none",
                        help="Select the useful component from Tegra 16-bit RAW containers.")
    parser.add_argument("--shift-right", type=int, default=0,
                        help="Right-shift each 16-bit sample before scaling.")
    parser.add_argument("--mono-method", choices=("raw", "bayer2x2"),
                        default="raw",
                        help="PGM output method. bayer2x2 suppresses RGGB CFA grid.")
    parser.add_argument("--auto-levels", action="store_true",
                        help="Set black/white from sampled crop percentiles.")
    parser.add_argument("--percentile-low", type=float, default=1.0)
    parser.add_argument("--percentile-high", type=float, default=99.0)
    parser.add_argument("--auto-stride", type=int, default=16)
    return parser.parse_args()


def clamp_u8(value):
    if value < 0:
        return 0
    if value > 255:
        return 255
    return value


def scale_to_u8(value, black, white):
    if white <= black:
        white = black + 1
    return clamp_u8((value - black) * 255 // (white - black))


def percentile(sorted_values, pct):
    if not sorted_values:
        return 0
    if pct <= 0:
        return sorted_values[0]
    if pct >= 100:
        return sorted_values[-1]
    pos = (len(sorted_values) - 1) * pct / 100.0
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return sorted_values[lo]
    frac = pos - lo
    return sorted_values[lo] * (1.0 - frac) + sorted_values[hi] * frac


def auto_levels(raw, width, left, top, crop_width, crop_height, stride,
                pct_low, pct_high):
    stride = max(1, stride)
    values = []
    for y in range(top, top + crop_height, stride):
        base = y * width + left
        for x in range(0, crop_width, stride):
            values.append(raw[base + x])
    values.sort()
    black = int(round(percentile(values, pct_low)))
    white = int(round(percentile(values, pct_high)))
    if white <= black:
        white = black + 1
    return black, white


def select_raw_component(raw, bits, component):
    if component == "none":
        return raw, "none"

    mask = (1 << bits) - 1
    lo = array.array("H", (value & mask for value in raw))
    hi = array.array("H", (value >> (16 - bits) for value in raw))

    if component == "lo":
        return lo, "lo"
    if component == "hi":
        return hi, "hi"

    lo_sample = sorted(lo[::16])
    hi_sample = sorted(hi[::16])
    lo_p99 = percentile(lo_sample, 99)
    hi_p99 = percentile(hi_sample, 99)
    return (lo, "lo") if lo_p99 >= hi_p99 else (hi, "hi")


def sample(raw, width, height, x, y):
    if x < 0:
        x = 0
    elif x >= width:
        x = width - 1
    if y < 0:
        y = 0
    elif y >= height:
        y = height - 1
    return raw[y * width + x]


def debayer_rggb(raw, width, height, x, y):
    p = sample(raw, width, height, x, y)
    row = y & 1
    col = x & 1

    if row == 0 and col == 0:
        r = p
        g = (sample(raw, width, height, x - 1, y) +
             sample(raw, width, height, x + 1, y) +
             sample(raw, width, height, x, y - 1) +
             sample(raw, width, height, x, y + 1)) // 4
        b = (sample(raw, width, height, x - 1, y - 1) +
             sample(raw, width, height, x + 1, y - 1) +
             sample(raw, width, height, x - 1, y + 1) +
             sample(raw, width, height, x + 1, y + 1)) // 4
    elif row == 0:
        r = (sample(raw, width, height, x - 1, y) +
             sample(raw, width, height, x + 1, y)) // 2
        g = p
        b = (sample(raw, width, height, x, y - 1) +
             sample(raw, width, height, x, y + 1)) // 2
    elif col == 0:
        r = (sample(raw, width, height, x, y - 1) +
             sample(raw, width, height, x, y + 1)) // 2
        g = p
        b = (sample(raw, width, height, x - 1, y) +
             sample(raw, width, height, x + 1, y)) // 2
    else:
        r = (sample(raw, width, height, x - 1, y - 1) +
             sample(raw, width, height, x + 1, y - 1) +
             sample(raw, width, height, x - 1, y + 1) +
             sample(raw, width, height, x + 1, y + 1)) // 4
        g = (sample(raw, width, height, x - 1, y) +
             sample(raw, width, height, x + 1, y) +
             sample(raw, width, height, x, y - 1) +
             sample(raw, width, height, x, y + 1)) // 4
        b = p
    return r, g, b


def bayer2x2_luma(raw, width, height, x, y):
    bx = x & ~1
    by = y & ~1
    if bx + 1 >= width:
        bx = max(0, width - 2)
    if by + 1 >= height:
        by = max(0, height - 2)
    base = by * width + bx
    return (raw[base] + raw[base + 1] +
            raw[base + width] + raw[base + width + 1]) // 4


def main():
    args = parse_args()
    expected_bytes = args.width * args.height * 2
    with open(args.input, "rb") as f:
        data = f.read()
    if len(data) != expected_bytes:
        sys.exit(
            f"input size {len(data)} does not match {expected_bytes} bytes")

    raw = array.array("H")
    raw.frombytes(data)
    if sys.byteorder != "little":
        raw.byteswap()
    raw, component = select_raw_component(raw, args.raw_bits,
                                          args.raw_component)
    if args.shift_right > 0:
        for i, value in enumerate(raw):
            raw[i] = value >> args.shift_right

    left = args.left
    top = args.top
    if left is None:
        left = (args.width - args.crop_width) // 2
    if top is None:
        top = (args.height - args.crop_height) // 2
    left = max(0, min(left, args.width - args.crop_width))
    top = max(0, min(top, args.height - args.crop_height))

    black = args.black
    white = args.white
    if args.auto_levels:
        black, white = auto_levels(raw, args.width, left, top,
                                   args.crop_width, args.crop_height,
                                   args.auto_stride,
                                   args.percentile_low,
                                   args.percentile_high)

    with open(args.output, "wb") as out:
        if args.format == "pgm":
            out.write(f"P5\n{args.crop_width} {args.crop_height}\n255\n".encode())
            buf = bytearray(args.crop_width * args.crop_height)
            i = 0
            for y in range(top, top + args.crop_height):
                base = y * args.width + left
                for x in range(args.crop_width):
                    if args.mono_method == "bayer2x2":
                        value = bayer2x2_luma(raw, args.width, args.height,
                                              left + x, y)
                    else:
                        value = raw[base + x]
                    buf[i] = scale_to_u8(value, black, white)
                    i += 1
            out.write(buf)
        else:
            out.write(f"P6\n{args.crop_width} {args.crop_height}\n255\n".encode())
            buf = bytearray(args.crop_width * args.crop_height * 3)
            i = 0
            for y in range(top, top + args.crop_height):
                for x in range(left, left + args.crop_width):
                    r, g, b = debayer_rggb(raw, args.width, args.height, x, y)
                    buf[i] = scale_to_u8(r, black, white)
                    buf[i + 1] = scale_to_u8(g, black, white)
                    buf[i + 2] = scale_to_u8(b, black, white)
                    i += 3
            out.write(buf)


if __name__ == "__main__":
    main()
