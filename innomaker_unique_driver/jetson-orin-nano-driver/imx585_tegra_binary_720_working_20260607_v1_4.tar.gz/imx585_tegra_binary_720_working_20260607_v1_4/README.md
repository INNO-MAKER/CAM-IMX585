# IMX585 Tegra Binary Package - v1.4 with ClearHDR 12bit/16bit Support

Build date: 2026-06-07
Kernel ABI validated: 5.15.148-tegra

Prebuilt IMX585 binary release for NVIDIA Jetson Orin Nano (L4T R36.4.4) with **Normal mode (default)** plus **ClearHDR 12bit / 16bit (opt-in)**. Includes precompiled kernel module (.ko), device tree overlays (.dtbo), ISP configuration, and ready-to-use scripts.

**Default mode after install: Normal (RAW12 linear).** Switch to ClearHDR with the helper:
```bash
sudo ./scripts/switch_mode.sh hdr12      # ClearHDR 12bit (Argus, 4K, locked exposure)
sudo ./scripts/switch_mode.sh hdr16      # ClearHDR 16bit (Argus, 4K, locked exposure)
sudo ./scripts/switch_mode.sh normal     # back to Normal
./scripts/switch_mode.sh status          # show current mode
```

## What's New in v1.4

- **ClearHDR 12bit fix**: self-contained mode tables eliminate v1.3's stuck test-pattern issue.
- **ClearHDR 16bit fix**: `hdr_bit_depth=16` switched from MDBIT=0x03 (true RAW16, not parseable by Argus, hangs V4L2) to MDBIT=0x01 RG12 + CCMP_EN=0x00. The sensor does not output raw HCG/LCG-interleaved 16-bit (Sony app note + Pi reference driver both confirm), so "16-bit" now means *uncompressed gradation* in the standard RG12 container — Argus can render it.
- **HDR capture/preview scripts now pin a default locked exposure.** Argus AE misreads HDR luminance and drives exposure to all-black without the lock; customers can still override via env vars.
- **Module parameters** `hdr_mode` and `hdr_bit_depth` for runtime configuration.
- **Default mode: Normal** — `imx585-reload.service` loads plain `modprobe imx585` at boot; ClearHDR is opt-in via `switch_mode.sh`.
- **Mode switch helper** `scripts/switch_mode.sh {normal|hdr12|hdr16|status}` performs stop-Argus → rmmod → modprobe → start-Argus in one command.
- **One-step install** `install_binary.sh` installs the reload service automatically.

## Features

- **Normal mode (default)**: Standard linear imaging (RAW12), Argus + V4L2 RAW.
- **ClearHDR 12bit / 16bit (opt-in, Argus 4K only)**: high dynamic range via the standard RG12 Argus path. 4K resolution with locked exposure. Binned 1080p HDR and V4L2 RAW HDR have known limitations in v1.4 — see USER_MANUAL.md.
- **Correct ClearHDR timing**: Registers 0x493c/0x4940 = 0x23 (per Sony datasheet).
- **MONO sensor support**: Grayscale pipeline for IMX585 MONO version.
- **Boot initialization service**: Auto-loads Normal mode at boot.
- **Module autoload**: Driver loads automatically at boot.
- **One-command mode switcher**: `scripts/switch_mode.sh`.

## Validated Configuration

- CAM1, 2 lanes, `serial_c`, `/dev/video0`
- Link speed: 720 Mbps/lane (up to 12.5 fps)
- Resolutions: 1080p (1920×1080), 4K (3840×2160)
- Color output via Argus ISP

## Installation

```bash
cd imx585_tegra_binary_720_working_20260607_v1_4
sudo ./install_binary.sh
```

The install script:
1. Installs precompiled module to `/lib/modules/5.15.148-tegra/`
2. Installs device tree overlays to `/boot`
3. Installs the ISP configuration
4. Configures module autoload
5. **Installs `imx585-reload.service` and enables it** (loads Normal mode at boot)
6. Restarts the camera services

Configure overlay (required after first install):

```bash
sudo ./scripts/configure_extlinux_overlay.sh
sudo reboot
```

## ⭐ Auto-Boot Service (Default: Normal mode)

After installation, `imx585-reload.service` is enabled and loads the driver in Normal mode on every boot. ClearHDR is opt-in via `switch_mode.sh` after boot.

### Verify after installation

```bash
# Service must be enabled (returns "enabled")
systemctl is-enabled imx585-reload.service

# Service must have run successfully after boot
systemctl status imx585-reload.service

# Module parameters must reflect Normal mode
cat /sys/module/imx585/parameters/hdr_mode      # 0
cat /sys/module/imx585/parameters/hdr_bit_depth # 12 (unused in Normal mode)

# Or one-liner via helper:
./scripts/switch_mode.sh status
# Expected: Current mode: Normal (hdr_mode=0)
```

### Make ClearHDR the boot default

```bash
sudo systemctl edit imx585-reload.service
```

Add (for ClearHDR 12bit):
```ini
[Service]
ExecStart=
ExecStart=/sbin/modprobe imx585 hdr_mode=1 hdr_bit_depth=12
```

To revert to Normal default:
```bash
sudo systemctl revert imx585-reload.service
sudo systemctl daemon-reload
```

## Quick Start

After reboot, Normal mode is already active. Just capture:

```bash
cd scripts

# Capture image (Normal mode)
./capture_argus_image.sh 1080p /tmp/photo.jpg

# Record video (Normal mode)
./capture_argus_video.sh 1080p /tmp/video.mp4 30
```

## Switching Between Modes

Use `switch_mode.sh` — it handles `stop nvargus → rmmod → modprobe → start nvargus` in one command:

```bash
./scripts/switch_mode.sh status          # show current mode
sudo ./scripts/switch_mode.sh normal     # Normal RAW12 (default)
sudo ./scripts/switch_mode.sh hdr12      # ClearHDR 12bit (Argus + V4L2)
sudo ./scripts/switch_mode.sh hdr16      # ClearHDR 16bit (V4L2 RAW only)
```

### After switching to HDR12 or HDR16, capture via Argus at 4K:
```bash
# capture_argus_image.sh detects hdr_mode=1 and pins a default locked exposure;
# override via EXPOSURE_NS=20000000 GAIN=10 if you need a specific operating point.
./scripts/capture_argus_image.sh 4k /tmp/hdr.jpg
```

Use 4K (`sensor-mode=0`). Binned 1080p HDR Argus is currently all-black (driver registers verify correct; the issue is in the Argus binned pipeline). V4L2 RAW HDR is also not recommended in v1.4 — `v4l2-ctl --set-ctrl=gain` is not propagated by tegracam, so HDR data collapses.

## Documentation

- `USER_MANUAL.md` - Complete user manual
- `README.md` - This file (quick reference)

## Version History

**v1.4 (2026-06-08)** — ClearHDR 12bit/16bit working via Argus 4K
- ClearHDR 12bit driver fix (self-contained mode tables, eliminates v1.3 stuck test-pattern).
- ClearHDR 16bit refactor: MDBIT=0x01 RG12 + CCMP_EN=0x00 (no second-stage gradation compression). Replaces earlier v1.4 MDBIT=0x03 that Argus could not parse.
- Argus AE quirk in HDR mode documented; capture/preview scripts pin a default locked exposure.
- Module parameters: `hdr_mode` (0/1) and `hdr_bit_depth` (12/16).
- **Default mode: Normal** — auto-boot service loads `modprobe imx585` (no HDR params).
- `scripts/switch_mode.sh` for one-command mode switching.
- `install_binary.sh` now installs reload service.

**v1.3 (2026-06-06)** - ClearHDR initial support (had test pattern issue)

**v1.2 (2026-06-01)** - Boot initialization service

**v1.1 (2026-05-31)** - ISP starter tuning profile

**v1.0 (2026-05-30)** - Initial release
