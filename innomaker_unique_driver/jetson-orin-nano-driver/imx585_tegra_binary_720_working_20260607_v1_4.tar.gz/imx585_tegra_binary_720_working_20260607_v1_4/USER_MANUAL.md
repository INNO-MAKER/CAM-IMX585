# IMX585 Tegra Binary Package - User Manual

Version: v1.4
Date: 2026-06-07
Kernel: 5.15.148-tegra (Jetson Orin Nano)

## What's New in v1.4

- **ClearHDR 12bit driver fix** — self-contained mode tables eliminate v1.3's stuck test-pattern issue.
- **ClearHDR 16bit driver fix** — `hdr_bit_depth=16` now produces a real Argus image at 4K. Earlier v1.4 builds wrote MDBIT=0x03 (true RAW16 container), which the Argus ISP does not parse and which hangs the V4L2 RAW path. The sensor itself does not output raw HCG/LCG interleaved 16-bit (confirmed against Sony app note and Pi reference driver), so 16-bit now keeps the RG12 container and only disables the second-stage gradation compression (`CCMP_EN=0x00`). The "16" label refers to gradation quality, not container width.
- **HDR captures require a locked exposure** — Argus AE misreads the HDR luminance histogram (high max + low mean) as overexposed and drives exposure to minimum, producing all-black frames. Capture/preview scripts pin `exposuretimerange` and `gainrange` by default and expose env vars so customers can override.
- **Module parameters** `hdr_mode` and `hdr_bit_depth` for runtime control.
- **Default mode: Normal** — `imx585-reload.service` loads plain `modprobe imx585` at boot; ClearHDR is opt-in.
- **Mode switch helper** `scripts/switch_mode.sh {normal|hdr12|hdr16|status}` performs the full stop-Argus → rmmod → modprobe → start-Argus dance in one command.

## ⭐ Auto-Boot Service - GUARANTEED ENABLED (Normal mode default)

After running `sudo ./install_binary.sh`, the package **guarantees**:

1. **Service installed**: `/etc/systemd/system/imx585-reload.service`
2. **Service enabled**: Runs automatically at every boot
3. **Normal mode default**: Module loaded with plain `modprobe imx585` (no HDR params)

### Service Content

```ini
[Unit]
Description=Reload IMX585 module and restart nvargus-daemon after boot
After=nvargus-daemon.service

[Service]
Type=oneshot
ExecStartPre=/bin/sleep 5
ExecStartPre=/bin/systemctl stop nvargus-daemon
ExecStartPre=/sbin/modprobe -r imx585
ExecStart=/sbin/modprobe imx585
ExecStartPost=/bin/systemctl start nvargus-daemon
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

### Verify After Install

```bash
# 1. Service must be enabled
systemctl is-enabled imx585-reload.service
# Expected: enabled

# 2. After reboot, parameters must show Normal mode
cat /sys/module/imx585/parameters/hdr_mode      # 0
cat /sys/module/imx585/parameters/hdr_bit_depth # 12 (unused in Normal mode)

# Or use the helper:
./scripts/switch_mode.sh status
# Expected: Current mode: Normal (hdr_mode=0)
```

## Three Operating Modes & How to Switch

The IMX585 driver supports **three operating modes**, selected at module load time via the `hdr_mode` and `hdr_bit_depth` parameters:

| Mode | `hdr_mode` | `hdr_bit_depth` | MDBIT | CCMP_EN | Output | Argus 4K | Argus 1080p | V4L2 RAW | Default? |
|------|-----------|------------------|-------|---------|--------|----------|-------------|----------|----------|
| **Normal** | 0 | (n/a) | 0x01 | (off) | RAW12 linear | ✅ | ✅ | ✅ | ⭐ Yes |
| ClearHDR 12bit | 1 | 12 | 0x01 | 0x01 | RAW12 compressed HDR | ✅ (locked exposure) | ❌ binned all-black | ⚠️ gain not propagated | ❌ |
| ClearHDR 16bit | 1 | 16 | 0x01 | 0x00 | RG12 container, uncompressed gradation HDR | ✅ (locked exposure) | ❌ binned all-black | ⚠️ gain not propagated | ❌ |

**Default after install:** Normal mode (loaded by `imx585-reload.service` at every boot). ClearHDR is opt-in.

**Known limitations of v1.4 ClearHDR (recommended path: 4K Argus with locked exposure):**

- **HDR + 1080p binned does not produce a usable Argus image.** The binned-mode Argus output stays at mean=16 (all black) for both HDR12 and HDR16 regardless of exposure/gain. Cause is in the Argus ISP / VI binned-mode handling, not in the sensor — driver-side registers verify correct (WDMODE=0x10 COMBI_EN=0x02, GAIN/SHR applied). Use 4K when capturing in HDR mode.
- **V4L2 RAW gain does not reach the sensor.** `v4l2-ctl --set-ctrl=gain=N` returns the value but the tegracam framework does not propagate it; the sensor stays at GAIN=0 and HDR data collapses to a near-constant pixel value. V4L2 RAW HDR capture is therefore not a recommended workflow in v1.4. Use Argus.
- **HDR16 vs HDR12 visible difference is subtle.** Both modes now use the same RG12 container; HDR16 only differs in that the sensor's second-stage gradation compression is disabled, giving more unique levels in the highlight/midtone roll-off. The improvement may not be obvious in 8-bit JPEG output and is more apparent when raw frames are tonemapped externally.

### Recommended: use `switch_mode.sh`

The helper wraps the four reload steps. Same effect, single command:

```bash
sudo ./scripts/switch_mode.sh normal     # Normal RAW12 (default)
sudo ./scripts/switch_mode.sh hdr12      # ClearHDR 12bit
sudo ./scripts/switch_mode.sh hdr16      # ClearHDR 16bit (use --no-argus for V4L2-only)
./scripts/switch_mode.sh status          # read-only, no root needed
```

### Manual switching (equivalent)

```bash
sudo systemctl stop nvargus-daemon         # 1. Stop Argus daemon
sudo modprobe -r imx585                    # 2. Unload driver
sudo modprobe imx585 <PARAMS>              # 3. Reload with new params
sudo systemctl start nvargus-daemon        # 4. Restart Argus daemon
```

Replace `<PARAMS>` per the mode you want (see below).

---

### Mode 1: Normal Mode — DEFAULT (no HDR)

Standard linear RAW12 output. Default after install — **no action needed unless you switched away**.

Use this when:
- You want the simplest data path (no HDR compression)
- You need maximum framerate
- ISP tuning was done for normal mode

```bash
sudo ./scripts/switch_mode.sh normal
# equivalent manual:
# sudo systemctl stop nvargus-daemon
# sudo modprobe -r imx585
# sudo modprobe imx585
# sudo systemctl start nvargus-daemon
```

Verify:
```bash
cat /sys/module/imx585/parameters/hdr_mode   # 0
sudo dmesg | grep "streaming started" | tail -1
# Should show: MDBIT=0x1 (HDR regs line follows with WDMODE=0x0 CCMP_EN=0x0)
```

---

### Mode 2: ClearHDR 12bit (opt-in, recommended for HDR scenes)

Compressed HDR output, fully compatible with Argus pipeline. Use this when:
- You want better dynamic range in bright/dark scenes
- You're using Argus (`gst-launch-1.0 nvarguscamerasrc ...`)

```bash
sudo ./scripts/switch_mode.sh hdr12
# equivalent manual:
# sudo systemctl stop nvargus-daemon
# sudo modprobe -r imx585
# sudo modprobe imx585 hdr_mode=1 hdr_bit_depth=12
# sudo systemctl start nvargus-daemon
```

Verify:
```bash
cat /sys/module/imx585/parameters/hdr_mode      # 1
cat /sys/module/imx585/parameters/hdr_bit_depth # 12
sudo dmesg | grep "HDR regs" | tail -1
# Should show: WDMODE=0x10 COMBI_EN=0x2 CCMP_EN=0x1 ...
```

---

### Mode 3: ClearHDR 16bit (Argus, 4K, locked exposure)

Same delivery path as HDR12 (RG12 container via Argus), but the sensor's second-stage gradation compression is disabled (CCMP_EN=0x00) so HDR16 carries more unique gradation levels in the highlight roll-off. Use this when:
- You want the finest gradation HDR the sensor can output
- You're using Argus at 4K with a locked exposure
- You've already evaluated HDR12 and want a side-by-side comparison

```bash
sudo ./scripts/switch_mode.sh hdr16
./scripts/capture_argus_image.sh 4k /tmp/hdr16_4k.jpg
# (capture script auto-pins exposuretimerange + gainrange when hdr_mode=1.
#  Override via EXPOSURE_NS=... GAIN=... if you need a specific operating point.)
```

Verify:
```bash
cat /sys/module/imx585/parameters/hdr_bit_depth # 16
sudo dmesg | grep "HDR regs" | tail -1
# Should show: WDMODE=0x10 COMBI_EN=0x2 CCMP_EN=0x0 ...  (note CCMP_EN=0x0)
sudo dmesg | grep "streaming started" | tail -1
# Should show: ... MDBIT=0x1 ... (HDR16 now uses 12-bit container — RG12 path)
```

> **Important:** Argus AE misreads HDR luminance (high max + low mean) as overexposed and drives exposure to minimum, producing all-black output. The capture/preview scripts therefore pin `exposuretimerange` and `gainrange` by default. If you build your own pipeline, set
> `aelock=true exposuretimerange="20000000 20000000" gainrange="10 10"`
> (or your own values) on `nvarguscamerasrc`. Use 4K resolution — binned 1080p HDR is currently unusable (see Known Limitations above).

---

### Making a Mode Switch Permanent (Survive Reboot)

The `imx585-reload.service` runs plain `modprobe imx585` at every boot (Normal mode). To make a different mode persistent, override the service:

```bash
sudo systemctl edit imx585-reload.service
```

In the editor, add (for ClearHDR 12bit at boot):
```ini
[Service]
ExecStart=
ExecStart=/sbin/modprobe imx585 hdr_mode=1 hdr_bit_depth=12
```

Or (for ClearHDR 16bit):
```ini
[Service]
ExecStart=
ExecStart=/sbin/modprobe imx585 hdr_mode=1 hdr_bit_depth=16
```

Save and exit. The override survives package upgrades.

To revert to default (Normal):
```bash
sudo systemctl revert imx585-reload.service
sudo systemctl daemon-reload
```


## Overview

This package provides a prebuilt IMX585 camera driver for NVIDIA Jetson Orin Nano, validated at 720 Mbps/lane on 2-lane MIPI CSI-2. It includes the kernel module, device tree overlays, ISP configuration, and usage scripts.

**Validated Configuration:**
- 2-lane MIPI CSI-2 @ 720 Mbps/lane
- CAM1 connector (serial_c, i2c@1)
- Device: /dev/video0
- Resolutions: 1080p (1920×1080) and 4K (3840×2160)
- Frame rate: up to 18 fps (1188 Mbps mode)
- Color output via Argus ISP

## Package Contents

```
imx585_tegra_binary_720_working_20260601_v1_2/
├── README.md                          # Technical details
├── USER_MANUAL.md                     # This file
├── install_binary.sh                  # Main installation script
├── imx585-reload.service              # Boot initialization service
├── binary/
│   └── imx585.ko                      # Prebuilt kernel module
├── overlays/
│   ├── tegra234-p3767-camera-p3768-imx585-cam0.dtbo
│   ├── tegra234-p3767-camera-p3768-imx585-cam1.dtbo
│   └── tegra234-p3767-camera-p3768-imx585-dual.dtbo
├── isp/
│   └── camera_overrides.imx585_starter.isp
└── scripts/
    ├── install_imx585_reload_service.sh
    ├── install_starter_isp.sh
    ├── configure_extlinux_overlay.sh
    ├── preview_argus.sh               # Live color preview
    ├── preview_argus_mono.sh          # Live preview for MONO IMX585 (grayscale pipeline)
    ├── preview_argus_hdr.sh           # Live preview with ClearHDR mode (high dynamic range)
    ├── capture_argus_image.sh         # Capture JPEG image
    ├── capture_argus_video.sh         # Record video
    ├── capture_v4l2_image.sh          # Capture RAW image
    ├── soak_argus_stream.sh           # Stress test
    └── check_argus_imx585.sh          # Quick verification
```

## Installation

### Prerequisites

- NVIDIA Jetson Orin Nano with L4T R36.4.4
- Kernel 5.15.148-tegra
- IMX585 camera connected to CAM1 connector
- sudo access

### Step 1: Install Driver

```bash
cd imx585_tegra_binary_720_working_20260601_v1_2
sudo ./install_binary.sh
```

The installer will:
1. Install kernel module to `/lib/modules/$(uname -r)/kernel/drivers/media/i2c/`
2. Install device tree overlays to `/boot/`
3. Install ISP configuration to `/var/nvidia/nvcam/settings/`
4. Configure module autoload
5. Install boot initialization service
6. Reload module and restart nvargus-daemon

### Step 2: Configure Device Tree Overlay

```bash
sudo ./scripts/configure_extlinux_overlay.sh
```

Select the overlay for your camera configuration:
- **CAM0**: Camera on CAM0 connector
- **CAM1**: Camera on CAM1 connector (recommended)
- **Dual**: Cameras on both CAM0 and CAM1

### Step 3: Reboot

```bash
sudo reboot
```

After reboot, the driver will automatically load and initialize.

## Verification

Check that the camera is detected:

```bash
# Check kernel module
lsmod | grep imx585

# Check video device
v4l2-ctl --list-devices

# Quick Argus test
cd scripts
./check_argus_imx585.sh
```

Expected output:
```
NVIDIA Tegra Video Input Device (platform:tegra-camrtc-ca):
	/dev/media0

vi-output, imx585 9-001a (platform:tegra-capture-vi:2):
	/dev/video0
```

## Usage Examples

### Live Preview

```bash
cd scripts

# 1080p preview (color sensor)
./preview_argus.sh 1080p

# 4K preview (color sensor)
./preview_argus.sh 4k

# Live preview for MONO version IMX585 (forces grayscale,
# neutralizes Argus AWB/CCM pink cast on no-Bayer sensors)
./preview_argus_mono.sh 1080p
./preview_argus_mono.sh 4k

# Live preview with ClearHDR mode (high dynamic range)
./preview_argus_hdr.sh 1080p
./preview_argus_hdr.sh 4k
```

Press `q` or `Ctrl+C` to stop.

### Capture Images

```bash
# Capture JPEG (1080p)
./capture_argus_image.sh 1080p /tmp/imx585_photo.jpg

# Capture JPEG (4K)
./capture_argus_image.sh 4k /tmp/imx585_4k.jpg

# Capture RAW (for analysis)
./capture_v4l2_image.sh 1080p /tmp/imx585_raw.png
```

### Record Video

```bash
# Record 30 seconds at 1080p
./capture_argus_video.sh 1080p /tmp/imx585_video.mp4 30

# Record 10 seconds at 4K
./capture_argus_video.sh 4k /tmp/imx585_4k.mp4 10
```

### Stress Test

```bash
# Stream for 60 seconds
./soak_argus_stream.sh 1080p 60
```

## Camera Controls

Adjust exposure, gain, and frame rate using environment variables:

```bash
# Custom exposure (microseconds, range: 2-39000)
EXPOSURE=20000 ./preview_argus.sh 1080p

# Custom gain (range: 0-240)
GAIN=10 ./preview_argus.sh 1080p

# Custom frame rate (micro-fps)
FRAME_RATE=18000000 ./preview_argus.sh 1080p  # 18 fps

# Combine multiple settings
EXPOSURE=15000 GAIN=5 ./capture_argus_image.sh 1080p /tmp/custom.jpg
```

## ClearHDR Quick Reference

Use the unified `switch_mode.sh` + capture-script workflow above. The remainder
of this section is a quick reference; for the full matrix and known
limitations, see **Three Operating Modes & How to Switch**.

- HDR12 / HDR16 deliver via the same RG12 Argus path as v1.4's MDBIT=0x01
  refactor. HDR16 differs only in disabling the sensor's second-stage
  gradation compression (CCMP_EN=0x00) for finer roll-off.
- Use 4K (`sensor-mode=0`). Binned 1080p in HDR mode currently produces an
  all-black Argus image — driver-side registers verify correct but the
  Argus/VI binned path does not deliver usable luma.
- Lock exposure: `aelock=true exposuretimerange="20000000 20000000" gainrange="10 10"`
  on `nvarguscamerasrc` (or use the capture/preview scripts that auto-pin
  these). Argus AE drives HDR luminance to all-black without the lock.
- V4L2 RAW HDR capture is not supported in v1.4: `v4l2-ctl --set-ctrl=gain`
  is not propagated by tegracam, so the sensor stays at GAIN=0 and HDR data
  collapses.
- Frame rate: ClearHDR runs at roughly 50% of Normal-mode framerate.
- Mode is fixed per module load — use `scripts/switch_mode.sh` to swap
  cleanly; `nvargus-daemon` must be stopped first (the helper handles this).

### Persist HDR mode across reboots

See **Making a Mode Switch Permanent (Survive Reboot)** above (drop-in for
`imx585-reload.service` via `systemctl edit`). The legacy
`/etc/modprobe.d/imx585-hdr.conf` approach still works but is less robust
across upgrades.

## Troubleshooting

### Camera not detected after reboot

**Symptom:** `/dev/video0` missing or `v4l2-ctl --list-devices` shows no camera

**Solution:**
```bash
# Check if module loaded
lsmod | grep imx585

# If not loaded, load manually
sudo modprobe imx585

# Check dmesg for errors
sudo dmesg | grep -i imx585
```

### Preview shows corrupted/garbled image

**Symptom:** Preview window shows distorted colors or patterns

**Solution:** The boot initialization service should fix this automatically. If not:
```bash
# Manually reload module
sudo systemctl stop nvargus-daemon
sudo rmmod imx585
sudo modprobe imx585
sudo systemctl start nvargus-daemon

# Then try preview again
./scripts/preview_argus.sh 1080p
```

### "Connection refused" error

**Symptom:** `Connecting to nvargus-daemon failed: Connection refused`

**Solution:**
```bash
# Restart nvargus-daemon
sudo systemctl restart nvargus-daemon

# Check status
sudo systemctl status nvargus-daemon
```

### Device tree overlay not active

**Symptom:** Camera not detected even though module loads

**Solution:**
```bash
# Check extlinux.conf
grep OVERLAYS /boot/extlinux/extlinux.conf

# Should show:
# OVERLAYS /boot/...,/boot/tegra234-p3767-camera-p3768-imx585-cam1.dtbo

# If missing, run:
sudo ./scripts/configure_extlinux_overlay.sh
sudo reboot
```

## Uninstallation

To remove the driver:

```bash
# Stop and disable services
sudo systemctl stop imx585-reload.service
sudo systemctl disable imx585-reload.service
sudo rm /etc/systemd/system/imx585-reload.service
sudo systemctl daemon-reload

# Remove module
sudo rmmod imx585
sudo rm /lib/modules/$(uname -r)/kernel/drivers/media/i2c/imx585.ko
sudo depmod -a

# Remove overlays from extlinux.conf (manual edit)
sudo nano /boot/extlinux/extlinux.conf
# Remove the imx585 dtbo from OVERLAYS line

# Reboot
sudo reboot
```

## Technical Specifications

**Sensor:** Sony IMX585 (Color, RGGB Bayer)  
**Interface:** 2-lane MIPI CSI-2  
**Data Rate:** 720 Mbps/lane (validated), 1188 Mbps/lane (experimental)  
**Resolutions:**
- 4K: 3856×2180 (sensor), 3840×2160 (output)
- 1080p: 1928×1090 (sensor), 1920×1080 (output)

**Frame Rates:**
- 720 Mbps: up to 12.5 fps
- 1188 Mbps: up to 18 fps

**Pixel Format:** RG12 (12-bit Bayer)  
**ISP:** Argus with starter tuning profile

## Known Limitations

1. **Frame rate limited by link speed** - Maximum 18 fps at 1188 Mbps
2. **ISP tuning is basic** - Color accuracy not production-calibrated
3. **Single camera only** - Dual camera mode not fully tested
4. **No hardware trigger support** - Software trigger only

## Support

For issues or questions:
1. Check dmesg: `sudo dmesg | grep -i imx585`
2. Check nvargus logs: `sudo journalctl -u nvargus-daemon`
3. Verify installation: `./scripts/check_argus_imx585.sh`

## Version History

**v1.4 (2026-06-08)**
- ClearHDR 12bit fix: self-contained mode tables eliminate v1.3 stuck test-pattern.
- ClearHDR 16bit fix: `hdr_bit_depth=16` switched from MDBIT=0x03 RAW16 (not parseable by Argus, hangs V4L2) to MDBIT=0x01 RG12 + CCMP_EN=0x00 (uncompressed gradation through the standard Argus path).
- Documented Argus AE failure on HDR luminance: capture/preview scripts now pin `exposuretimerange` / `gainrange` by default. Override via env vars.
- Documented known limitations: HDR binned 1080p Argus all-black, V4L2 gain not propagated in HDR.
- Added `scripts/switch_mode.sh` for clean Normal / HDR12 / HDR16 transitions.

**v1.3 (2026-06-06)**
- Added ClearHDR mode support for high dynamic range imaging
- Mode selection via `imx585` module parameter `hdr_mode`
- Added preview_argus_hdr.sh script (auto-reloads module)
- Added MONO sensor preview support (preview_argus_mono.sh)

**v1.2 (2026-06-01)**
- Added boot initialization service for reliable startup
- Integrated ISP installation into main installer
- Integrated module autoload configuration
- Improved installation reliability

**v1.1 (2026-05-31)**
- Added ISP starter tuning profile
- Fixed color preview issues

**v1.0 (2026-05-30)**
- Initial release
- 720 Mbps validated configuration
