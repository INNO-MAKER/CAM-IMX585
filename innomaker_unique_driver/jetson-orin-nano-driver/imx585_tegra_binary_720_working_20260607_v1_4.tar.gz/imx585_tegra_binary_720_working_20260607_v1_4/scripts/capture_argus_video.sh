#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-1080p}"
OUT="${2:-/tmp/imx585_argus_${MODE}.mp4}"
DURATION="${3:-5}"
SENSOR_ID="${SENSOR_ID:-0}"
BITRATE="${BITRATE:-20000000}"
BITRATE_KBIT=$((BITRATE / 1000))
FRAMERATE="${FRAMERATE:-25/2}"
FRAMES_PER_SECOND_NUM=25
FRAMES_PER_SECOND_DEN=2

# HDR-mode defaults (auto-applied when /sys/module/imx585/parameters/hdr_mode=1)
EXPOSURE_NS="${EXPOSURE_NS:-20000000}"
GAIN="${GAIN:-10}"
ISP_DGAIN="${ISP_DGAIN:-1}"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160|native4k|full4k|3856x2180} [output.mp4] [duration_seconds]" >&2
		exit 2
		;;
esac

case "${OUT##*.}" in
	mp4) ;;
	*)
		echo "Only MP4 output is supported by this Argus video helper: ${OUT}" >&2
		exit 2
		;;
esac

if ! [[ "${DURATION}" =~ ^[0-9]+$ ]] || [ "${DURATION}" -lt 1 ]; then
	echo "duration_seconds must be a positive integer" >&2
	exit 2
fi

NUM_BUFFERS=$(((DURATION * FRAMES_PER_SECOND_NUM + FRAMES_PER_SECOND_DEN - 1) / FRAMES_PER_SECOND_DEN))

HDR_MODE_NOW=0
if [ -r /sys/module/imx585/parameters/hdr_mode ]; then
	HDR_MODE_NOW="$(cat /sys/module/imx585/parameters/hdr_mode)"
fi

EXTRA_SRC_ARGS=()
if [ "${HDR_MODE_NOW}" = "1" ]; then
	EXTRA_SRC_ARGS+=(
		aelock=true
		exposuretimerange="${EXPOSURE_NS} ${EXPOSURE_NS}"
		gainrange="${GAIN} ${GAIN}"
		ispdigitalgainrange="${ISP_DGAIN} ${ISP_DGAIN}"
	)
	echo "HDR mode detected: locking exposure=${EXPOSURE_NS} ns gain=${GAIN} dgain=${ISP_DGAIN}"
	if [ "${SENSOR_MODE}" = "1" ]; then
		echo "WARNING: HDR + 1080p binned currently produces all-black Argus output (v1.4). Use 4k." >&2
	fi
fi

rm -f "${OUT}"

if gst-inspect-1.0 nvv4l2h264enc >/dev/null 2>&1; then
	gst-launch-1.0 -e \
		nvarguscamerasrc sensor-id="${SENSOR_ID}" sensor-mode="${SENSOR_MODE}" num-buffers="${NUM_BUFFERS}" \
			"${EXTRA_SRC_ARGS[@]}" \
		! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
		! nvv4l2h264enc bitrate="${BITRATE}" insert-sps-pps=true iframeinterval=25 \
		! h264parse \
		! qtmux \
		! filesink location="${OUT}"
elif gst-inspect-1.0 x264enc >/dev/null 2>&1; then
	gst-launch-1.0 -e \
		nvarguscamerasrc sensor-id="${SENSOR_ID}" sensor-mode="${SENSOR_MODE}" num-buffers="${NUM_BUFFERS}" \
			"${EXTRA_SRC_ARGS[@]}" \
		! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
		! nvvidconv \
		! "video/x-raw,format=I420,width=${OUT_W},height=${OUT_H},framerate=${FRAMERATE}" \
		! x264enc bitrate="${BITRATE_KBIT}" speed-preset=ultrafast tune=zerolatency key-int-max=25 \
		! h264parse \
		! qtmux \
		! filesink location="${OUT}"
elif gst-inspect-1.0 openh264enc >/dev/null 2>&1; then
	gst-launch-1.0 -e \
		nvarguscamerasrc sensor-id="${SENSOR_ID}" sensor-mode="${SENSOR_MODE}" num-buffers="${NUM_BUFFERS}" \
			"${EXTRA_SRC_ARGS[@]}" \
		! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
		! nvvidconv \
		! "video/x-raw,format=I420,width=${OUT_W},height=${OUT_H},framerate=${FRAMERATE}" \
		! openh264enc bitrate="${BITRATE}" gop-size=25 \
		! h264parse \
		! qtmux \
		! filesink location="${OUT}"
else
	echo "No supported H.264 encoder found. Install nvv4l2h264enc, x264enc, or openh264enc." >&2
	exit 1
fi

echo "Wrote ${OUT}"
