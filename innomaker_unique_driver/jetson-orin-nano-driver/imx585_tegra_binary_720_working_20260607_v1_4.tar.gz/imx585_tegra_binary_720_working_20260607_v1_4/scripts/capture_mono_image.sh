#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-1080p}"
OUT="${2:-/tmp/imx585_mono_${MODE}.pgm}"
DEVICE="${DEVICE:-/dev/video0}"
TMP_DIR="${TMP_DIR:-/tmp/imx585_capture}"
EXPOSURE="${EXPOSURE:-10000}"
GAIN="${GAIN:-0}"
FRAME_RATE="${FRAME_RATE:-12500000}"
BLACK="${BLACK:-64}"
WHITE="${WHITE:-4095}"
RAW_COMPONENT="${RAW_COMPONENT:-none}"
SHIFT_RIGHT="${SHIFT_RIGHT:-4}"
MONO_METHOD="${MONO_METHOD:-raw}"
AUTO_LEVELS="${AUTO_LEVELS:-1}"
STREAM_SKIP="${STREAM_SKIP:-2}"
STREAM_TIMEOUT="${STREAM_TIMEOUT:-12s}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		SENSOR_W=1928
		SENSOR_H=1090
		CROP_W=1920
		CROP_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		SENSOR_W=3856
		SENSOR_H=2180
		CROP_W=3840
		CROP_H=2160
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160} [output.pgm|output.png|output.jpg]" >&2
		echo "Optional env: DEVICE=/dev/video0 EXPOSURE=10000 GAIN=0 FRAME_RATE=12500000 AUTO_LEVELS=1 BLACK=64 WHITE=4095 RAW_COMPONENT=none SHIFT_RIGHT=4 MONO_METHOD=raw STREAM_SKIP=2 STREAM_TIMEOUT=12s" >&2
		exit 2
		;;
esac

EXT="${OUT##*.}"
case "${EXT}" in
	pgm|png|jpg|jpeg) ;;
	*)
		echo "Unsupported output extension: ${EXT}" >&2
		echo "Use .pgm, .png, .jpg, or .jpeg" >&2
		exit 2
		;;
esac

mkdir -p "${TMP_DIR}"
BASE="${TMP_DIR}/imx585_mono_${SENSOR_W}x${SENSOR_H}"
RAW="${BASE}.raw"
PGM="${BASE}.pgm"

rm -f "${RAW}" "${PGM}" "${OUT}"

LEVEL_ARGS=(--black "${BLACK}" --white "${WHITE}")
if [ "${AUTO_LEVELS}" = "1" ]; then
	LEVEL_ARGS=(--auto-levels)
fi

timeout "${STREAM_TIMEOUT}" v4l2-ctl -d "${DEVICE}" \
	--set-ctrl="sensor_mode=${SENSOR_MODE},exposure=${EXPOSURE},gain=${GAIN},frame_rate=${FRAME_RATE}" \
	--set-fmt-video="width=${SENSOR_W},height=${SENSOR_H},pixelformat=RG12" \
	--stream-mmap \
	--stream-skip="${STREAM_SKIP}" \
	--stream-count=1 \
	--stream-to="${RAW}"

python3 "${SCRIPT_DIR}/imx585_raw16_to_pnm.py" \
	--input "${RAW}" --output "${PGM}" \
	--width "${SENSOR_W}" --height "${SENSOR_H}" \
	--crop-width "${CROP_W}" --crop-height "${CROP_H}" \
	--format pgm "${LEVEL_ARGS[@]}" \
	--raw-component "${RAW_COMPONENT}" \
	--shift-right "${SHIFT_RIGHT}" \
	--mono-method "${MONO_METHOD}"

if [ "${EXT}" = "pgm" ]; then
	mv "${PGM}" "${OUT}"
else
	if [ "${EXT}" = "png" ]; then
		gst-launch-1.0 -q filesrc location="${PGM}" ! pnmdec ! videoconvert ! pngenc ! filesink location="${OUT}"
	else
		gst-launch-1.0 -q filesrc location="${PGM}" ! pnmdec ! videoconvert ! jpegenc ! filesink location="${OUT}"
	fi
fi

echo "Wrote ${OUT}"
