#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-1080p}"
OUT="${2:-/tmp/imx585_${MODE}.png}"
DEVICE="${DEVICE:-/dev/video0}"
TMP_DIR="${TMP_DIR:-/tmp/imx585_capture}"
SHIFT_RIGHT="${SHIFT_RIGHT:-4}"
FRAME_RATE="${FRAME_RATE:-12500000}"
AUTO_LEVELS="${AUTO_LEVELS:-1}"
STREAM_SKIP="${STREAM_SKIP:-2}"
STREAM_TIMEOUT="${STREAM_TIMEOUT:-12s}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		SENSOR_W=1928
		SENSOR_H=1090
		CROP_W=1920
		CROP_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		SENSOR_W=3856
		SENSOR_H=2180
		CROP_W=3840
		CROP_H=2160
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160} [output.png|output.jpg|output.ppm|output.pgm]" >&2
		exit 2
		;;
esac

mkdir -p "${TMP_DIR}"
BASE="${TMP_DIR}/imx585_${SENSOR_W}x${SENSOR_H}"
RAW="${BASE}.raw"
PNM="${BASE}.${OUT##*.}.pnm"
EXT="${OUT##*.}"

case "${EXT}" in
	png|jpg|jpeg|ppm|pgm) ;;
	*)
		echo "Unsupported output extension: ${EXT}" >&2
		exit 2
		;;
esac

rm -f "${RAW}" "${PNM}" "${OUT}"

LEVEL_ARGS=(--black "${BLACK:-64}" --white "${WHITE:-4095}")
if [ "${AUTO_LEVELS}" = "1" ]; then
	LEVEL_ARGS=(--auto-levels)
fi

timeout "${STREAM_TIMEOUT}" v4l2-ctl -d "${DEVICE}" \
	--set-ctrl="sensor_mode=${SENSOR_MODE},frame_rate=${FRAME_RATE}" \
	--set-fmt-video="width=${SENSOR_W},height=${SENSOR_H},pixelformat=RG12" \
	--stream-mmap \
	--stream-skip="${STREAM_SKIP}" \
	--stream-count=1 \
	--stream-to="${RAW}"

if [ "${EXT}" = "pgm" ]; then
	python3 "${SCRIPT_DIR}/imx585_raw16_to_pnm.py" \
		--input "${RAW}" --output "${OUT}" \
		--width "${SENSOR_W}" --height "${SENSOR_H}" \
		--crop-width "${CROP_W}" --crop-height "${CROP_H}" \
		--format pgm "${LEVEL_ARGS[@]}" --shift-right "${SHIFT_RIGHT}"
	echo "Wrote ${OUT}"
	exit 0
fi

if [ "${EXT}" = "ppm" ]; then
	python3 "${SCRIPT_DIR}/imx585_raw16_to_pnm.py" \
		--input "${RAW}" --output "${OUT}" \
		--width "${SENSOR_W}" --height "${SENSOR_H}" \
		--crop-width "${CROP_W}" --crop-height "${CROP_H}" \
		--format ppm "${LEVEL_ARGS[@]}" --shift-right "${SHIFT_RIGHT}"
	echo "Wrote ${OUT}"
	exit 0
fi

python3 "${SCRIPT_DIR}/imx585_raw16_to_pnm.py" \
	--input "${RAW}" --output "${PNM}" \
	--width "${SENSOR_W}" --height "${SENSOR_H}" \
	--crop-width "${CROP_W}" --crop-height "${CROP_H}" \
	--format ppm "${LEVEL_ARGS[@]}" --shift-right "${SHIFT_RIGHT}"

if [ "${EXT}" = "png" ]; then
	gst-launch-1.0 -q filesrc location="${PNM}" ! pnmdec ! videoconvert ! pngenc ! filesink location="${OUT}"
else
	gst-launch-1.0 -q filesrc location="${PNM}" ! pnmdec ! videoconvert ! jpegenc ! filesink location="${OUT}"
fi

echo "Wrote ${OUT}"
