#!/usr/bin/env bash
set -euo pipefail

echo "--- nvargus-daemon ---"
systemctl is-active nvargus-daemon 2>/dev/null || true
ls -l /var/run/argus_socket 2>/dev/null || true

echo "--- Argus sensors/modes ---"
nvargus_nvraw --lps

echo "--- Sensor 0 info ---"
nvargus_nvraw --c 0 --sensorinfo || true
