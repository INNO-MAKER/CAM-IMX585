#!/usr/bin/env bash
set -euo pipefail

CONF="${CONF:-/boot/extlinux/extlinux.conf}"
OVERLAY="${OVERLAY:-/boot/tegra234-p3767-camera-p3768-imx585-cam1.dtbo}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="${CONF}.backup_imx585_${STAMP}"

if [ ! -f "$CONF" ]; then
	echo "ERROR: extlinux config not found: ${CONF}" >&2
	exit 1
fi

if [ ! -f "$OVERLAY" ]; then
	echo "ERROR: overlay not found: ${OVERLAY}" >&2
	echo "Install the IMX585 package first." >&2
	exit 1
fi

DEFAULT_LABEL="$(awk '$1 == "DEFAULT" { print $2; exit }' "$CONF")"
if [ -z "$DEFAULT_LABEL" ]; then
	DEFAULT_LABEL="primary"
fi

echo "Configuring IMX585 overlay in ${CONF}"
echo "Default label: ${DEFAULT_LABEL}"
echo "Overlay: ${OVERLAY}"

SUDO=()
if [ "$(id -u)" -ne 0 ] && { [ ! -w "$CONF" ] || [ ! -w "$(dirname "$CONF")" ]; }; then
	SUDO=(sudo)
fi

"${SUDO[@]}" cp "$CONF" "$BACKUP"
echo "Backup: ${BACKUP}"

TMP="$(mktemp)"
awk -v target="$DEFAULT_LABEL" -v overlay="$OVERLAY" '
function emit_overlay_line(line,    indent, rest, n, i, out, tok) {
	indent = line;
	sub(/[^ \t].*$/, "", indent);
	rest = line;
	sub(/^[ \t]*OVERLAYS[ \t]+/, "", rest);

	n = split(rest, items, ",");
	out = "";
	for (i = 1; i <= n; i++) {
		tok = items[i];
		gsub(/^[ \t]+|[ \t]+$/, "", tok);
		if (tok == "" || tok == overlay)
			continue;
		if (tok ~ /\/boot\/tegra234-p3767-camera-.*\.dtbo$/)
			continue;
		out = out (out == "" ? "" : ",") tok;
	}
	out = out (out == "" ? "" : ",") overlay;
	print indent "OVERLAYS " out;
}

function maybe_insert_overlay() {
	if (in_target && !saw_overlays)
		print "\tOVERLAYS " overlay;
}

$1 == "LABEL" {
	if (in_target)
		maybe_insert_overlay();
	in_target = ($2 == target);
	saw_overlays = 0;
	print;
	next;
}

in_target && $1 == "OVERLAYS" {
	emit_overlay_line($0);
	saw_overlays = 1;
	next;
}

{
	print;
}

END {
	if (in_target)
		maybe_insert_overlay();
}
' "$CONF" > "$TMP"

"${SUDO[@]}" install -m 0644 "$TMP" "$CONF"
rm -f "$TMP"

echo "Updated overlay line:"
awk -v target="$DEFAULT_LABEL" '
$1 == "LABEL" { in_target = ($2 == target) }
in_target && $1 == "OVERLAYS" { print; exit }
' "$CONF"

echo "Reboot is required for the overlay to take effect."
