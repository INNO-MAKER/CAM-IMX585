#!/usr/bin/env bash
# Configure IMX585 kernel module to load automatically at boot

set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "ERROR: This script must be run as root (use sudo)" >&2
    exit 1
fi

MODULES_LOAD_DIR="/etc/modules-load.d"
MODPROBE_DIR="/etc/modprobe.d"
IMX585_MODULES_CONF="${MODULES_LOAD_DIR}/imx585.conf"
IMX585_MODPROBE_CONF="${MODPROBE_DIR}/imx585.conf"

echo "=== Configuring IMX585 Module Autoload ==="
echo ""
echo "IMPORTANT: The imx585 module should load automatically via device tree"
echo "if the IMX585 dtbo is correctly installed and activated in extlinux.conf."
echo ""
echo "If the module does not load after reboot, check:"
echo "  1. Is the dtbo in /boot/extlinux/extlinux.conf OVERLAYS line?"
echo "  2. Did you reboot after installing/changing the dtbo?"
echo "  3. Is the device tree node present: grep -r sony,imx585 /proc/device-tree/"
echo ""
echo "This script creates a fallback autoload configuration in case"
echo "device tree autoloading fails."
echo ""

# Create modules-load.d entry to load imx585 at boot
echo "Creating ${IMX585_MODULES_CONF}..."
cat > "${IMX585_MODULES_CONF}" <<'EOF'
# Load IMX585 camera driver at boot
# Note: tegra-camera is a dependency and should load automatically
# If imx585 fails to load at boot, check: dmesg | grep imx585
imx585
EOF

# Create modprobe.d entry for any module options (currently none needed)
echo "Creating ${IMX585_MODPROBE_CONF}..."
cat > "${IMX585_MODPROBE_CONF}" <<'EOF'
# IMX585 camera driver options
# Add options here if needed, e.g.:
# options imx585 debug=1
EOF

echo ""
echo "Module autoload configured successfully."
echo ""
echo "NEXT STEPS:"
echo "  1. Ensure the IMX585 dtbo is in /boot/extlinux/extlinux.conf"
echo "  2. Reboot the system"
echo "  3. After reboot, verify: lsmod | grep imx585"
echo ""
echo "If the module still does not load automatically after reboot,"
echo "check device tree: grep -r sony,imx585 /proc/device-tree/"
echo ""
echo "The imx585 module loads automatically when the device tree"
echo "contains an imx585 node (via dtbo overlay). The modules-load.d"
echo "configuration created by this script is a fallback mechanism."
echo ""
