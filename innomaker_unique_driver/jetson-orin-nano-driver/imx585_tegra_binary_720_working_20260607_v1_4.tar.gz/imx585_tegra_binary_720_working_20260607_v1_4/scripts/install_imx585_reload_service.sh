#!/usr/bin/env bash
# Install IMX585 reload service to fix boot initialization issue
# v1.4: Auto-loads ClearHDR 12bit at boot (hdr_mode=1 hdr_bit_depth=12)

set -euo pipefail

SERVICE_FILE="imx585-reload.service"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Service file may be in same dir as script, or in parent (package root)
if [ -f "${SCRIPT_DIR}/${SERVICE_FILE}" ]; then
    SERVICE_SRC="${SCRIPT_DIR}/${SERVICE_FILE}"
elif [ -f "${SCRIPT_DIR}/../${SERVICE_FILE}" ]; then
    SERVICE_SRC="${SCRIPT_DIR}/../${SERVICE_FILE}"
else
    echo "ERROR: ${SERVICE_FILE} not found in ${SCRIPT_DIR} or its parent" >&2
    exit 1
fi
SERVICE_DST="/etc/systemd/system/${SERVICE_FILE}"

echo "Installing IMX585 reload service (v1.4 - auto-loads ClearHDR 12bit)..."
echo "Source: ${SERVICE_SRC}"
sudo install -m 0644 "$SERVICE_SRC" "$SERVICE_DST"

echo "Enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable imx585-reload.service

echo ""
echo "Service installed and enabled."
echo "  Default config: hdr_mode=1 hdr_bit_depth=12 (ClearHDR 12bit)"
echo ""
echo "This service will:"
echo "  - Run automatically at boot"
echo "  - Stop nvargus-daemon"
echo "  - Reload imx585 with ClearHDR 12bit"
echo "  - Restart nvargus-daemon"
echo ""
echo "Verify the service is active after reboot:"
echo "  systemctl is-enabled imx585-reload.service  # should be 'enabled'"
echo "  cat /sys/module/imx585/parameters/hdr_mode  # should be '1'"
echo "  sudo dmesg | grep 'HDR regs'  # verify WDMODE=0x10 CCMP_EN=0x1"
echo ""
echo "To test now: sudo systemctl start imx585-reload.service"
echo "To check status: sudo systemctl status imx585-reload.service"
