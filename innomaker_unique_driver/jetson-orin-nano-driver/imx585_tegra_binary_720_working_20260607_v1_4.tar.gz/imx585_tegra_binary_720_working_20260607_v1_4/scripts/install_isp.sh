#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
ISP_FILE="${ISP_FILE:-camera_overrides.imx585_starter.isp}"
SRC="${PACKAGE_DIR}/isp/${ISP_FILE}"
SETTINGS_DIR="/var/nvidia/nvcam/settings"
DST="${SETTINGS_DIR}/camera_overrides.isp"
BACKUP_DIR="${SETTINGS_DIR}/backup_imx585_isp"
STATE_FILE="${BACKUP_DIR}/last_install_state"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [ ! -s "$SRC" ]; then
	echo "ERROR: missing or empty ISP override: ${SRC}" >&2
	exit 1
fi

if [ "${IMX585_INSTALL_EXPERIMENTAL_ISP:-0}" != "1" ]; then
	echo "Refusing to install the experimental IMX585 ISP override by default." >&2
	echo "Validation showed this file can produce black/green Argus JPEG output." >&2
	echo "Set IMX585_INSTALL_EXPERIMENTAL_ISP=1 to install it for ISP tuning experiments." >&2
	echo "Optional: set ISP_FILE=<file under isp/> to install a specific backup." >&2
	exit 2
fi

echo "Installing IMX585 ISP override: ${ISP_FILE}"
sudo mkdir -p "$SETTINGS_DIR" "$BACKUP_DIR"

if [ -f "$DST" ]; then
	BACKUP_FILE="${BACKUP_DIR}/camera_overrides.isp.${STAMP}.bak"
	sudo cp "$DST" "$BACKUP_FILE"
	printf "backup=%s\n" "$BACKUP_FILE" | sudo tee "$STATE_FILE" >/dev/null
	echo "Backed up existing override to: ${BACKUP_FILE}"
else
	printf "backup=\n" | sudo tee "$STATE_FILE" >/dev/null
	echo "No existing override found. Rollback will remove the installed file."
fi

sudo install -m 0644 "$SRC" "$DST"
sudo install -m 0644 "$SRC" "${SETTINGS_DIR}/${ISP_FILE}"

echo "Restarting nvargus-daemon"
sudo systemctl restart nvargus-daemon || true
echo "Installed: ${DST}"
