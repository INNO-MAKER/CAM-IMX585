#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
ISP_FILE="camera_overrides.imx585_starter.isp"
SRC="${PACKAGE_DIR}/isp/${ISP_FILE}"
SETTINGS_DIR="/var/nvidia/nvcam/settings"
DST="${SETTINGS_DIR}/camera_overrides.isp"
BACKUP_DIR="${SETTINGS_DIR}/backup_imx585_isp"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [ ! -s "$SRC" ]; then
	echo "ERROR: missing or empty ISP override: ${SRC}" >&2
	exit 1
fi

sudo mkdir -p "$SETTINGS_DIR" "$BACKUP_DIR"

if [ -f "$DST" ] && ! cmp -s "$SRC" "$DST"; then
	BACKUP_FILE="${BACKUP_DIR}/camera_overrides.isp.${STAMP}.bak"
	sudo cp "$DST" "$BACKUP_FILE"
	echo "Backed up existing override to: ${BACKUP_FILE}"
fi

sudo install -m 0644 "$SRC" "$DST"
sudo install -m 0644 "$SRC" "${SETTINGS_DIR}/${ISP_FILE}"

echo "Restarting nvargus-daemon"
sudo systemctl restart nvargus-daemon || true
echo "Installed starter ISP: ${DST}"
