#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-1080p}"
DURATION="${2:-0}"
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-25/2}"
FRAMES_PER_SECOND_NUM=25
FRAMES_PER_SECOND_DEN=2
PREVIEW_SINK="${PREVIEW_SINK:-}"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160|native4k|full4k|3856x2180} [duration_seconds]" >&2
		exit 2
		;;
esac

if ! [[ "${DURATION}" =~ ^[0-9]+$ ]]; then
	echo "duration_seconds must be a non-negative integer; use 0 for continuous preview" >&2
	exit 2
fi

if [ -z "${PREVIEW_SINK}" ]; then
	if gst-inspect-1.0 nv3dsink >/dev/null 2>&1; then
		PREVIEW_SINK="nv3dsink"
	elif gst-inspect-1.0 nveglglessink >/dev/null 2>&1; then
		PREVIEW_SINK="nveglglessink"
	else
		PREVIEW_SINK="autovideosink"
	fi
fi

NUM_BUFFERS_ARG=()
if [ "${DURATION}" -gt 0 ]; then
	NUM_BUFFERS=$(((DURATION * FRAMES_PER_SECOND_NUM + FRAMES_PER_SECOND_DEN - 1) / FRAMES_PER_SECOND_DEN))
	NUM_BUFFERS_ARG=(num-buffers="${NUM_BUFFERS}")
fi

echo "Preview mode=${MODE} sensor-mode=${SENSOR_MODE} ${OUT_W}x${OUT_H} framerate=${FRAMERATE} sink=${PREVIEW_SINK}"

case "${PREVIEW_SINK}" in
	autovideosink|xvimagesink|ximagesink)
		gst-launch-1.0 -e \
			nvarguscamerasrc sensor-id="${SENSOR_ID}" "${NUM_BUFFERS_ARG[@]}" \
				sensor-mode="${SENSOR_MODE}" \
			! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
			! nvvidconv \
			! "video/x-raw,format=I420,width=${OUT_W},height=${OUT_H},framerate=${FRAMERATE}" \
			! videoconvert \
			! fpsdisplaysink video-sink="${PREVIEW_SINK}" text-overlay=false sync=false fps-update-interval=1000
		;;
	*)
		gst-launch-1.0 -e \
			nvarguscamerasrc sensor-id="${SENSOR_ID}" "${NUM_BUFFERS_ARG[@]}" \
				sensor-mode="${SENSOR_MODE}" \
			! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
			! fpsdisplaysink video-sink="${PREVIEW_SINK}" text-overlay=false sync=false fps-update-interval=1000
		;;
esac
