# IMX585 Driver Scripts

This directory contains the shell helpers shipped with the IMX585 Tegra driver.
Customer-facing scripts (preview / capture / mode switching / install) are
documented in detail below. Diagnostic / soak-test helpers
(`check_argus_imx585.sh`, `soak_argus_stream.sh`, `analyze_raw_imx585.py`) are
for driver development and are not covered here — release packages move them
into a `develop/` subdirectory.

All scripts assume the IMX585 driver is already installed and the `imx585`
module is loaded (`lsmod | grep imx585`). If a display is required, prefix the
command with `DISPLAY=:0`.

---

## 1. Quick reference

### Preview (most-used)

| Script                       | Sensor | Mode    | Purpose                                                        |
|------------------------------|--------|---------|----------------------------------------------------------------|
| `preview_argus.sh`           | color  | Normal  | Argus realtime preview (1080p/4K), AE auto                     |
| `preview_argus_hdr.sh`       | color  | ClearHDR| ClearHDR preview with locked AE (workaround for Argus AE bug)  |
| `preview_argus_mono.sh`      | mono   | Normal  | Mono preview, drops Argus AWB/CCM color cast via GRAY8 round-trip |
| `preview_argus_mono_hdr.sh` ⭐| mono  | ClearHDR| Mono ClearHDR preview, locked AE + GRAY8 round-trip            |

> ⭐ `preview_argus_mono_hdr.sh` is the recommended entry point for mono
> ClearHDR users. See section **3.1** for scene-tuning guidance.

### Capture

| Script                      | Path  | Output    | Purpose                                                      |
|-----------------------------|-------|-----------|--------------------------------------------------------------|
| `capture_argus_image.sh`    | Argus | JPEG      | Single-shot JPEG (auto-locks AE in HDR mode)                 |
| `capture_argus_video.sh`    | Argus | H.264/MP4 | Short video clip (auto-locks AE in HDR mode)                 |
| `capture_mono_image.sh`     | V4L2  | PGM/PNG/JPG | Single-shot mono RAW16 → 8-bit grayscale image             |
| `capture_v4l2_image.sh`     | V4L2  | PPM/PNG/JPG/PGM | Single-shot RAW16 → demosaiced color image (or PGM)    |

### Mode switching

| Script           | Purpose                                                                       |
|------------------|-------------------------------------------------------------------------------|
| `switch_mode.sh` | One-shot switch between Normal / ClearHDR 12-bit / ClearHDR 16-bit (`status` is read-only) |

### First-time install / re-install

| Script                                | Purpose                                                           |
|---------------------------------------|-------------------------------------------------------------------|
| `install_source.sh`                   | Build `imx585.ko` + dtbo from source and install (source pkg only) |
| `configure_extlinux_overlay.sh`       | Inject IMX585 dtbo into `extlinux.conf`                           |
| `configure_module_autoload.sh`        | Create `/etc/modules-load.d/imx585.conf` fallback                 |
| `install_imx585_reload_service.sh`    | Install boot-time reload service (works around initial-load bug)  |
| `install_isp.sh`                      | Install Argus ISP override (experimental, gated by env var)       |
| `install_starter_isp.sh`              | Install vetted starter Argus ISP override                         |

---

## 2. Common conventions

All preview / capture scripts share the same positional arguments:

```
<script> {1080p|4k|native4k} [duration_or_output]
```

Resolution aliases:

| Alias       | Sensor mode | Output size                                  |
|-------------|-------------|----------------------------------------------|
| `1080p`     | 1           | 1920 x 1080 (binned)                         |
| `4k`        | 0           | 3840 x 2160 (cropped from full sensor)       |
| `native4k`  | 0           | 3856 x 2180 (full sensor active area)        |

Common environment overrides:

| Variable        | Default        | Notes                                                       |
|-----------------|----------------|-------------------------------------------------------------|
| `SENSOR_ID`     | `0`            | nvarguscamerasrc / `/dev/videoN` selector                   |
| `FRAMERATE`     | `25/2`         | Argus framerate fraction (12.5 fps default)                 |
| `PREVIEW_SINK`  | auto-detected  | Falls back through `nv3dsink` → `nveglglessink` → `autovideosink` |
| `EXPOSURE_NS`   | `20000000`     | Argus locked exposure (only used in HDR-locked scripts)     |
| `GAIN`          | `10`           | Argus locked analog gain                                    |
| `ISP_DGAIN`     | `1`            | Argus ISP digital gain                                      |

> **HDR sensor mode**: Always use `4k` for ClearHDR preview. Binned 1080p HDR
> currently outputs all-black Argus frames (driver registers are correct; the
> limitation is in the Argus/VI binned pipeline). See `USER_MANUAL.md` "Known
> limitations".

---

## 3. Preview scripts

### 3.1 `preview_argus_mono_hdr.sh` ⭐ — mono ClearHDR preview

The recommended entry point for **mono + ClearHDR** users. Combines two
workarounds:

1. **HDR aelock** (from `preview_argus_hdr.sh`): in ClearHDR mode the Argus AE
   algorithm misreads the HDR luminance histogram (high max + low mean) as
   overexposed and pushes the frame to all-black. Locking exposure/gain
   bypasses Argus AE entirely.
2. **GRAY8 round-trip** (from `preview_argus_mono.sh`): with `wbmode=0`,
   convert NV12 → I420 → GRAY8 → I420 to drop the Argus AWB/CCM color cast
   that otherwise appears when the mono sensor's raw Bayer-typed pixels are
   tinted by ISP color processing.

#### Usage

```bash
# 1. Make sure the driver is in ClearHDR mode
sudo ./switch_mode.sh hdr12        # or hdr16 for 16-bit ClearHDR

# 2. Run the preview (4k recommended; 1080p binned HDR is currently all-black)
DISPLAY=:0 ./preview_argus_mono_hdr.sh 4k

# Time-limited preview (10 seconds, useful for unattended capture)
DISPLAY=:0 ./preview_argus_mono_hdr.sh 4k 10
```

#### Scene-tuning table

The defaults (`EXPOSURE_NS=20000000`, `GAIN=10`, `ISP_DGAIN=1`) are tuned for
a dim indoor room. Override per scene:

| Scene                  | `EXPOSURE_NS`         | `GAIN` | `ISP_DGAIN` |
|------------------------|-----------------------|--------|-------------|
| Outdoor / strong window light | `1000000`  (1 ms)  | `1`    | `1`         |
| Bright indoor          | `3000000`   (3 ms)    | `2`    | `1`         |
| Normal indoor lighting | `8000000`   (8 ms)    | `4`    | `1`         |
| Dim room / dusk        | `20000000`  (20 ms)   | `10`   | `1`         |
| Very dark              | `33000000`  (33 ms)   | `20`   | `2`         |

Example:

```bash
# Outdoor scene — short exposure, no analog gain
DISPLAY=:0 EXPOSURE_NS=1000000 GAIN=1 ISP_DGAIN=1 \
    ./preview_argus_mono_hdr.sh 4k

# Very dark scene — long exposure, gain pushed up
DISPLAY=:0 EXPOSURE_NS=33000000 GAIN=20 ISP_DGAIN=2 \
    ./preview_argus_mono_hdr.sh 4k
```

#### Tuning tips

- If the image still washes out under bright light, drop `EXPOSURE_NS` first
  (analog gain headroom is more useful at low light than highlight rolloff).
- The script clamps `GAIN` per Argus's ClearHDR ceiling (≤ 80). Above that the
  driver rejects the value silently. The defaults above stay well within the
  HDR ceiling.
- If preview is black even with these settings, verify the mode actually
  switched: `./switch_mode.sh status` and `dmesg | grep "HDR regs" | tail -1`.

---

### 3.2 `preview_argus_hdr.sh` — color ClearHDR preview

Same HDR aelock workaround as `preview_argus_mono_hdr.sh`, without the GRAY8
round-trip. Use this with a color IMX585.

```bash
sudo ./switch_mode.sh hdr12
DISPLAY=:0 ./preview_argus_hdr.sh 4k
DISPLAY=:0 EXPOSURE_NS=8000000 GAIN=4 ./preview_argus_hdr.sh 4k 10
```

The same scene-tuning values from section 3.1 apply.

---

### 3.3 `preview_argus_mono.sh` — mono Normal preview

GRAY8 round-trip only — Argus AE runs normally because Normal mode does not
hit the HDR aelock issue.

```bash
sudo ./switch_mode.sh normal
DISPLAY=:0 ./preview_argus_mono.sh 1080p          # binned preview
DISPLAY=:0 ./preview_argus_mono.sh 4k             # full-res preview
DISPLAY=:0 ./preview_argus_mono.sh 4k 10          # 10-second clip
```

---

### 3.4 `preview_argus.sh` — color Normal preview

The simplest preview, no AE locking, no color drop. Use with a color IMX585 in
Normal mode.

```bash
sudo ./switch_mode.sh normal
DISPLAY=:0 ./preview_argus.sh 1080p
DISPLAY=:0 ./preview_argus.sh 4k 10
```

---

## 4. Capture scripts

### 4.1 `capture_argus_image.sh`

Argus JPEG capture. In Normal mode Argus AE auto-exposes (single frame). In
ClearHDR mode the script auto-applies aelock and captures 60 buffers by
default so the locked-AE warmup has time to settle.

```bash
# Normal SDR JPEG (Argus auto-AE)
./capture_argus_image.sh 4k /tmp/normal.jpg

# ClearHDR JPEG (auto-locked AE, override exposure/gain via env)
EXPOSURE_NS=8000000 GAIN=4 ./capture_argus_image.sh 4k /tmp/hdr.jpg
```

### 4.2 `capture_argus_video.sh`

Argus → H.264 → MP4. Picks `nvv4l2h264enc` if present, falls back to
`x264enc` / `openh264enc`. ClearHDR mode auto-applies aelock.

```bash
# 5-second 4K MP4
./capture_argus_video.sh 4k /tmp/clip.mp4 5

# 10-second 4K ClearHDR clip with custom locked exposure
EXPOSURE_NS=20000000 GAIN=10 ./capture_argus_video.sh 4k /tmp/hdr.mp4 10
```

### 4.3 `capture_mono_image.sh`

Mono V4L2 RAW16 → PGM / PNG / JPG via the bundled `imx585_raw16_to_pnm.py`.
Drops the Bayer color path so the output is true single-channel grayscale.

```bash
./capture_mono_image.sh 1080p /tmp/mono.pgm
EXPOSURE=20000 GAIN=10 ./capture_mono_image.sh 4k /tmp/mono.png
```

Useful env vars: `EXPOSURE` (μs), `GAIN` (V4L2 0..240), `AUTO_LEVELS=0`
combined with `BLACK` / `WHITE` for manual stretch.

### 4.4 `capture_v4l2_image.sh`

Color V4L2 RAW16 → demosaiced PNG / JPG / PPM (or PGM if you want the raw
luminance). Use this when you want a colour image bypassing Argus.

```bash
./capture_v4l2_image.sh 1080p /tmp/color.png
./capture_v4l2_image.sh 4k /tmp/color.ppm
```

---

## 5. Mode switching

### `switch_mode.sh`

```bash
sudo ./switch_mode.sh normal        # RAW12 linear (default)
sudo ./switch_mode.sh hdr12         # ClearHDR 12-bit (Argus + V4L2)
sudo ./switch_mode.sh hdr16         # ClearHDR 16-bit (V4L2 RAW only)
sudo ./switch_mode.sh hdr16 --no-argus  # Skip restarting nvargus-daemon
./switch_mode.sh status             # Show current mode (no sudo)
```

The script performs a clean full reload — `systemctl stop nvargus-daemon` →
`modprobe -r imx585` → `modprobe imx585 hdr_mode=... hdr_bit_depth=...` →
`systemctl start nvargus-daemon`. This is the same path the
`imx585-reload.service` uses at boot.

> **Why full reload**: sysfs-only mode changes are picked up at the next
> `set_mode()`, but mixed Argus → V4L2 transitions can leave the sensor in an
> intermediate state where V4L2 streams hang. `rmmod` fully releases
> `/dev/video0` and resets tegracam private state.

After a switch, verify the HDR registers (only meaningful for hdr12/hdr16
once one frame has been captured):

```
sudo dmesg | grep 'HDR regs' | tail -1
# expected (hdr12): WDMODE=0x10 COMBI_EN=0x2 CCMP_EN=0x1
# expected (hdr16): WDMODE=0x10 COMBI_EN=0x2 CCMP_EN=0x0
```

---

## 6. First-time install / re-install

Recommended order for a fresh install (source package). Binary package users
skip step 1.

```bash
# 1. (source only) Build .ko + dtbo and install module
./install_source.sh

# 2. Inject the IMX585 overlay into extlinux.conf
sudo ./configure_extlinux_overlay.sh

# 3. (optional) fallback autoload via modules-load.d
sudo ./configure_module_autoload.sh

# 4. Install the boot-time reload service (works around an initial-load
#    race where ClearHDR config is not applied on the very first probe)
./install_imx585_reload_service.sh

# 5. (optional) Install starter Argus ISP override
./install_starter_isp.sh

# Reboot
sudo reboot
```

### Script details

- **`install_source.sh`** (source pkg only): builds `imx585.ko` against the
  running kernel, builds the IMX585 dtbo, installs both, and runs
  `install_imx585_reload_service.sh` for you. Override `L4T_ROOT`,
  `IMX585_2LANE_LINK_MBPS` (`720`, default) or `IMX585_2LANE_HMAX` if you
  need a non-default link rate.
- **`configure_extlinux_overlay.sh`**: edits `/boot/extlinux/extlinux.conf`
  to add the IMX585 dtbo to the `OVERLAYS` line of the DEFAULT entry.
  Idempotent: it strips any existing `tegra234-p3767-camera-*.dtbo` before
  appending the IMX585 one. Override the conf path via `CONF=...`.
- **`configure_module_autoload.sh`**: creates `/etc/modules-load.d/imx585.conf`
  as a fallback. Normally the dtbo causes auto-load; this is only needed when
  device-tree-driven autoload fails.
- **`install_imx585_reload_service.sh`**: installs `imx585-reload.service`
  (systemd) which runs once at boot to reload `imx585` cleanly. Required for
  reliable ClearHDR boots.
- **`install_starter_isp.sh`**: installs the validated starter Argus ISP
  override (`isp/camera_overrides.imx585_starter.isp`). Backs up any existing
  override to `/var/nvidia/nvcam/settings/backup_imx585_isp/`.
- **`install_isp.sh`**: installs the experimental ISP override. Gated by
  `IMX585_INSTALL_EXPERIMENTAL_ISP=1` because that file is known to produce
  black/green Argus output on some scenes — use only for ISP tuning
  experiments.

---

## 7. Troubleshooting

| Symptom                                | First thing to check                                                  |
|----------------------------------------|------------------------------------------------------------------------|
| All-black HDR preview                  | Are you in ClearHDR mode? `./switch_mode.sh status`                    |
| All-black HDR preview at 1080p         | Switch to `4k` — binned 1080p HDR is a known v1.4 limitation           |
| Pink/green cast on mono sensor         | Use the `_mono` preview / capture script (GRAY8 round-trip)            |
| `modprobe` complains module in use     | `sudo systemctl stop nvargus-daemon`, then `switch_mode.sh` again      |
| HDR registers wrong after switch       | Capture one frame first; the registers are programmed on `start_streaming` |
| `preview_argus.sh` hangs at boot       | Wait for the reload service or `sudo systemctl restart imx585-reload`  |

For deeper diagnosis the `develop/` directory contains
`check_argus_imx585.sh` (dmesg + nvargus log dump) and `soak_argus_stream.sh`
(long-running capture stability test). These are intended for driver
development, not customer support.
