#!/usr/bin/env bash
set -euo pipefail

# IMX585 ClearHDR Argus preview for MONO sensors.
#
# Combines the HDR aelock logic from preview_argus_hdr.sh with the GRAY8
# round-trip used by preview_argus_mono.sh:
#
#   * aelock + locked exposure/gain so Argus AE doesn't drive HDR frames
#     to all-black (the HDR luminance histogram fools the AE algorithm).
#   * wbmode=0 + GRAY8 conversion to drop the Argus AWB/CCM color cast
#     that appears when the mono sensor's RAW is treated as Bayer.
#
# This script does NOT change the driver mode — switch first with
#   sudo ./switch_mode.sh hdr12     or
#   sudo ./switch_mode.sh hdr16
#
# Use 4K. Binned 1080p in HDR mode currently produces all-black Argus output
# (driver-side registers are correct; the limitation is in the Argus/VI binned
# pipeline). See USER_MANUAL.md "Known limitations".
#
# Environment overrides:
#   EXPOSURE_NS  exposure time, nanoseconds       (default 20000000 = 20 ms)
#   GAIN         analog gain, Argus units 1..80   (default 10, HDR ceiling)
#   ISP_DGAIN    ISP digital gain, 1..256          (default 1, no extra push)
#   FRAMERATE    Argus framerate fraction          (default 25/2 = 12.5 fps)
#   SENSOR_ID    nvarguscamerasrc sensor id        (default 0)
#   PREVIEW_SINK gstreamer sink element            (default nv3dsink/nveglglessink/autovideosink)

MODE="${1:-4k}"
DURATION="${2:-0}"
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-25/2}"
FRAMES_PER_SECOND_NUM=25
FRAMES_PER_SECOND_DEN=2
PREVIEW_SINK="${PREVIEW_SINK:-}"

EXPOSURE_NS="${EXPOSURE_NS:-20000000}"
GAIN="${GAIN:-10}"
ISP_DGAIN="${ISP_DGAIN:-1}"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		echo "WARNING: HDR + 1080p binned Argus is currently all-black (v1.4)." >&2
		echo "         Use 4k for a real HDR preview." >&2
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160|native4k|full4k|3856x2180} [duration_seconds]" >&2
		echo "Env: EXPOSURE_NS=20000000 GAIN=10 ISP_DGAIN=1 FRAMERATE=25/2 SENSOR_ID=0 PREVIEW_SINK=..." >&2
		exit 2
		;;
esac

if ! [[ "${DURATION}" =~ ^[0-9]+$ ]]; then
	echo "duration_seconds must be a non-negative integer; use 0 for continuous preview" >&2
	exit 2
fi

if [ -r /sys/module/imx585/parameters/hdr_mode ]; then
	HDR_MODE_NOW="$(cat /sys/module/imx585/parameters/hdr_mode)"
	if [ "${HDR_MODE_NOW}" != "1" ]; then
		echo "WARNING: imx585 hdr_mode=${HDR_MODE_NOW}, not 1." >&2
		echo "         Run 'sudo ./switch_mode.sh hdr12' or 'hdr16' first, or this will preview Normal mode." >&2
	fi
fi

if [ -z "${PREVIEW_SINK}" ]; then
	if gst-inspect-1.0 nv3dsink >/dev/null 2>&1; then
		PREVIEW_SINK="nv3dsink"
	elif gst-inspect-1.0 nveglglessink >/dev/null 2>&1; then
		PREVIEW_SINK="nveglglessink"
	else
		PREVIEW_SINK="autovideosink"
	fi
fi

NUM_BUFFERS_ARG=()
if [ "${DURATION}" -gt 0 ]; then
	NUM_BUFFERS=$(((DURATION * FRAMES_PER_SECOND_NUM + FRAMES_PER_SECOND_DEN - 1) / FRAMES_PER_SECOND_DEN))
	NUM_BUFFERS_ARG=(num-buffers="${NUM_BUFFERS}")
fi

echo "Preview (ClearHDR MONO) mode=${MODE} sensor-mode=${SENSOR_MODE} ${OUT_W}x${OUT_H} framerate=${FRAMERATE}"
echo "  Locked exposure: ${EXPOSURE_NS} ns, gain ${GAIN}, ISP dgain ${ISP_DGAIN}"
echo "  Sink: ${PREVIEW_SINK}"
echo "  Pipeline forces GRAY8 to drop Argus AWB/CCM color cast on mono sensor."

gst-launch-1.0 -e \
	nvarguscamerasrc sensor-id="${SENSOR_ID}" "${NUM_BUFFERS_ARG[@]}" \
		sensor-mode="${SENSOR_MODE}" wbmode=0 \
		aelock=true \
		exposuretimerange="${EXPOSURE_NS} ${EXPOSURE_NS}" \
		gainrange="${GAIN} ${GAIN}" \
		ispdigitalgainrange="${ISP_DGAIN} ${ISP_DGAIN}" \
	! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
	! nvvidconv \
	! "video/x-raw,format=I420,width=${OUT_W},height=${OUT_H},framerate=${FRAMERATE}" \
	! videoconvert \
	! "video/x-raw,format=GRAY8" \
	! videoconvert \
	! "video/x-raw,format=I420" \
	! fpsdisplaysink video-sink="${PREVIEW_SINK}" text-overlay=false sync=false fps-update-interval=1000
