# Installation Guide

## Before Installation

### Check Kernel Version

```bash
uname -r
```

**Must show**: `6.12.47+rpt-rpi-2712`

If your kernel version is different, you cannot use this binary package. Please use the source package instead.

### Verify System

```bash
# Check if Pi 5
cat /proc/device-tree/model
# Should show: Raspberry Pi 5

# Check OS
cat /etc/os-release | grep VERSION_CODENAME
# Should show: bookworm
```

## Installation Steps

### Method 1: Automatic Installation (Recommended)

```bash
cd driver/
sudo ./install.sh
```

The script will:
1. Copy `imx585.ko` to `/lib/modules/6.12.47+rpt-rpi-2712/kernel/drivers/media/i2c/`
2. Run `depmod -a`
3. Install tuning files to `/usr/local/share/libcamera/ipa/rpi/pisp/`

### Method 2: Manual Installation

```bash
# Install driver
sudo cp driver/imx585.ko /lib/modules/$(uname -r)/kernel/drivers/media/i2c/
sudo depmod -a

# Install tuning files
sudo mkdir -p /usr/local/share/libcamera/ipa/rpi/pisp
sudo cp tuning/*.json /usr/local/share/libcamera/ipa/rpi/pisp/

# Verify
ls -lh /lib/modules/$(uname -r)/kernel/drivers/media/i2c/imx585.ko
ls -lh /usr/local/share/libcamera/ipa/rpi/pisp/imx585_*.json
```

## Camera Configuration

### For Color Camera

Edit `/boot/firmware/config.txt`:

```bash
sudo nano /boot/firmware/config.txt
```

Add at the end:

```ini
dtoverlay=imx585,cam0
```

### For Mono Camera

```ini
dtoverlay=imx585,cam0,mono
```

### Multiple Cameras (Advanced)

```ini
# Camera 0 (color)
dtoverlay=imx585,cam0

# Camera 1 (mono)
dtoverlay=imx585,cam1,mono
```

## Reboot

```bash
sudo reboot
```

## Verify Installation

### 1. Check Driver Loaded

```bash
lsmod | grep imx585
```

Expected output:
```
imx585                 49152  0
v4l2_cci               49152  1 imx585
```

### 2. Check Camera Detected

```bash
libcamera-hello --list-cameras
```

Expected output:
```
Available cameras
-----------------
0 : imx585 [3856x2180] (/base/axi/pcie@1000120000/rp1/i2c@88000/imx585@1a)
```

### 3. Check Subdevice

```bash
ls -lh /dev/v4l-subdev2
v4l2-ctl -d /dev/v4l-subdev2 --list-ctrls | grep wide_dynamic_range
```

Should show:
```
wide_dynamic_range 0x009a0915 (bool)   : default=0 value=0
```

### 4. Test Capture

```bash
# Normal mode
rpicam-still -o test_normal.jpg

# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# ClearHDR capture
rpicam-still -o test_hdr.jpg
```

## Uninstall

### Remove Driver

```bash
sudo rm /lib/modules/$(uname -r)/kernel/drivers/media/i2c/imx585.ko
sudo depmod -a
```

### Remove Tuning Files

```bash
sudo rm /usr/local/share/libcamera/ipa/rpi/pisp/imx585_*.json
```

### Remove dtoverlay

Edit `/boot/firmware/config.txt` and remove the `dtoverlay=imx585` line.

### Reboot

```bash
sudo reboot
```

## Troubleshooting

### Installation Script Failed

**Error**: "Kernel version mismatch"

```bash
# Check your kernel
uname -r

# If not 6.12.47+rpt-rpi-2712, you need the source package
```

**Error**: "Permission denied"

```bash
# Use sudo
sudo ./install.sh
```

### Driver Not Loading

**Check dmesg**:
```bash
dmesg | grep imx585
```

Common issues:
- Wrong kernel version
- Missing dependencies
- Hardware not connected

### Camera Not Detected

**1. Verify dtoverlay**:
```bash
grep imx585 /boot/firmware/config.txt
```

**2. Check physical connection**:
- Power off Pi
- Reconnect camera cable
- Power on and reboot

**3. Check camera port**:
```bash
# List I2C devices
i2cdetect -y 10
# Should show device at 0x1a
```

### Tuning File Not Found

**Error**: "Failed to load tuning file"

```bash
# Verify installation
ls /usr/local/share/libcamera/ipa/rpi/pisp/imx585_*.json

# Reinstall if missing
sudo cp tuning/*.json /usr/local/share/libcamera/ipa/rpi/pisp/
```

**Specify explicitly**:
```bash
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json -o test.jpg
```

## Next Steps

See **USAGE.md** for detailed usage instructions and examples.
