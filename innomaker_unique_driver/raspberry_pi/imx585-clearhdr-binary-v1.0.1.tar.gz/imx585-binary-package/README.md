# IMX585 ClearHDR Driver - Binary Package

Sony IMX585 ClearHDR driver pre-compiled binary for Raspberry Pi 5.

## Version

- **Version**: 1.0.1
- **Date**: 2026-06-05
- **Kernel**: 6.12.47+rpt-rpi-2712
- **Architecture**: ARM64

## Contents

```
imx585-binary-package/
├── README.md                    # This file
├── INSTALL.md                   # Installation guide
├── USAGE.md                     # Usage manual
├── driver/
│   ├── imx585.ko                # Pre-compiled driver module
│   └── install.sh               # Installation script
├── tuning/
│   ├── imx585_color.json        # Color camera tuning
│   └── imx585_mono.json         # Mono camera tuning
└── tools/
    └── clearhdr_merge.py        # HCG/LCG merge tool
```

## Quick Start

### 1. Install Driver

```bash
cd driver/
sudo ./install.sh
```

### 2. Configure Camera

Edit `/boot/firmware/config.txt`:

```ini
# Color camera
dtoverlay=imx585,cam0

# Mono camera
dtoverlay=imx585,cam0,mono
```

### 3. Reboot

```bash
sudo reboot
```

### 4. Enable ClearHDR and Test

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Test capture
rpicam-still -o test.jpg
```

## System Requirements

- **Hardware**: Raspberry Pi 5
- **OS**: Raspberry Pi OS Bookworm
- **Kernel**: 6.12.47+rpt-rpi-2712 (exact match required)

**Important**: This binary package only works with the exact kernel version above. For other kernel versions, use the source package and compile manually.

## Documentation

- **INSTALL.md** - Installation instructions
- **USAGE.md** - Usage manual and examples

## Features

✅ **ClearHDR 12-bit Mode**
- Compressed HDR output
- 4x contrast improvement
- Real-time performance

✅ **ClearHDR 16-bit Mode**
- Higher bit depth
- Smoother gradation

✅ **Fixed Test Pattern Issue**
- Original driver produced test pattern in ClearHDR mode
- Now outputs real scene data

## Verify Installation

Check driver loaded:
```bash
lsmod | grep imx585
```

Check camera detected:
```bash
libcamera-hello --list-cameras
```

## Troubleshooting

### Wrong Kernel Version

If your kernel doesn't match 6.12.47+rpt-rpi-2712:

```bash
uname -r  # Check your kernel version
```

**Solution**: Download the source package and compile for your kernel.

### Installation Failed

Check dmesg for errors:
```bash
dmesg | grep imx585 | tail -20
```

### Camera Not Detected

1. Verify dtoverlay in `/boot/firmware/config.txt`
2. Check physical connection
3. Reboot after configuration change

## Getting Help

See **USAGE.md** for detailed usage instructions and examples.
