# Usage Manual

## Quick Reference

### Enable ClearHDR

```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
```

### Disable ClearHDR (Normal Mode)

```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0
```

### Basic Capture

```bash
# 12-bit ClearHDR
rpicam-still -o output.jpg

# 16-bit ClearHDR with RAW
rpicam-still --mode 3856:2180:16:U --raw -o output.jpg
```

## ⚠️ Important Note

**16-bit mode (R16) is only available when ClearHDR is enabled.**

- With `wide_dynamic_range=0`: Only R12_CSI2P modes available
- With `wide_dynamic_range=1`: Both R12_CSI2P and R16 modes available

To check available modes:
```bash
# Check ClearHDR status
v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range

# List available camera modes
rpicam-hello --list-cameras
```

## Camera Modes

### Mode 1: Normal (No HDR)

**Use case**: Standard scenes, fastest performance

```bash
# Disable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0

# Capture
rpicam-still -o normal.jpg
```

**Characteristics**:
- Linear response
- Standard dynamic range (~12-bit)
- Auto exposure/gain works normally

### Mode 2: ClearHDR 12-bit (Recommended)

**Use case**: High contrast scenes, real-time HDR

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Capture (12-bit is default)
rpicam-still -o hdr.jpg
```

**Characteristics**:
- Compressed HDR output (~16-bit dynamic range)
- 4x contrast improvement
- Real-time performance
- Suitable for video and still

### Mode 3: ClearHDR 16-bit

**Use case**: Maximum bit depth, smooth gradation

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Capture 16-bit with RAW
rpicam-still --mode 3856:2180:16:U --raw -o hdr16.jpg \
  --shutter 20000 --gain 4 --awbgains 1,1 --immediate
```

**Characteristics**:
- Compressed HDR output (similar to 12-bit)
- More gray levels (smoother gradation)
- Requires manual exposure (PiSP doesn't support 16-bit statistics)
- DNG file available for post-processing

## Common Parameters

### Exposure Control

```bash
# Manual exposure
rpicam-still --shutter 20000 --gain 4 -o output.jpg

# Auto exposure with preview
rpicam-still -t 2000 -o output.jpg
```

Typical values:
- `--shutter`: 10000-50000 (microseconds)
- `--gain`: 1-16 (analog gain)

### Mono Camera

For monochrome IMX585, always specify tuning file:

```bash
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  -o output.jpg
```

Or set as default:

```bash
export LIBCAMERA_RPI_TUNING_FILE=/usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json
rpicam-still -o output.jpg
```

### Color Camera

```bash
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_color.json \
  -o output.jpg
```

## Advanced Usage

### Preview with ClearHDR

```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
rpicam-hello -t 0  # Run until Ctrl+C
```

### Video Recording

```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
rpicam-vid -t 10000 -o hdr_video.h264
```

### RAW Capture with DNG

```bash
# Capture with RAW DNG file
rpicam-still --mode 3856:2180:12:U --raw -o capture.jpg

# DNG file saved as: capture.dng
# JPEG preview saved as: capture.jpg
```

### Check Current Settings

```bash
# Check ClearHDR status
v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range

# Check camera info
libcamera-hello --list-cameras

# Check available modes
v4l2-ctl -d /dev/video0 --list-formats-ext
```

## Resolution Modes

| Mode | Resolution | Bits | Frame Rate | Use Case |
|------|------------|------|------------|----------|
| 1928x1090 | 1080p | 12 | 60 fps | Fast preview |
| 3856x2180 | 4K | 12 | 30 fps | Standard capture |
| 3856x2180 | 4K | 16 | 30 fps | High quality capture |

Specify mode:

```bash
# 1080p 12-bit
rpicam-still --mode 1928:1090:12:U -o output.jpg

# 4K 12-bit
rpicam-still --mode 3856:2180:12:U -o output.jpg

# 4K 16-bit
rpicam-still --mode 3856:2180:16:U -o output.jpg
```

## Troubleshooting

### Warning: "statistics will not be correct"

**Cause**: 16-bit mode selected, PiSP doesn't support 16-bit statistics

**Solution**: Use manual exposure for 16-bit:

```bash
rpicam-still --mode 3856:2180:16:U \
  --shutter 20000 --gain 4 \
  --awbgains 1,1 --immediate \
  -o output.jpg
```

### Image too dark/bright

**Solution**: Adjust exposure parameters:

```bash
# Brighter
rpicam-still --shutter 30000 --gain 8 -o output.jpg

# Darker
rpicam-still --shutter 10000 --gain 2 -o output.jpg
```

### ClearHDR not working

**Check**:

1. Verify driver loaded:
   ```bash
   lsmod | grep imx585
   ```

2. Check WDR control:
   ```bash
   v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range
   ```

3. Check dmesg for errors:
   ```bash
   dmesg | grep imx585 | tail -20
   ```

### Camera not detected

**Check**:

1. dtoverlay configured in `/boot/firmware/config.txt`
2. Camera physically connected
3. Reboot after configuration change

```bash
grep imx585 /boot/firmware/config.txt
sudo reboot
```

## Performance Tips

### Fastest Capture

```bash
# Use immediate mode (skip preview)
rpicam-still --immediate -o fast.jpg

# Use lower resolution
rpicam-still --mode 1928:1090:12:U -o fast.jpg
```

### Best Quality

```bash
# Use 16-bit mode with manual exposure
rpicam-still --mode 3856:2180:16:U --raw \
  --shutter 20000 --gain 4 --awbgains 1,1 \
  --immediate -o best.jpg
```

### Batch Capture

```bash
#!/bin/bash
for i in {1..10}; do
  rpicam-still --immediate -o capture_$i.jpg
  sleep 1
done
```

## HCG/LCG Merge Tool (16-bit)

For 16-bit raw DNG files (if containing interleaved HCG/LCG data):

```bash
cd tools/
python3 clearhdr_merge.py input.dng -o merged.tiff --preview
```

**Note**: Current implementation outputs compressed data, not interleaved HCG/LCG, so this tool may not be needed.

## Examples

### High Contrast Scene

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Capture with preview for framing
rpicam-still -t 2000 -o hdr_scene.jpg
```

### Low Light Scene

```bash
# ClearHDR improves shadow detail
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Increase exposure
rpicam-still --shutter 50000 --gain 8 -o lowlight.jpg
```

### Timelapse with HDR

```bash
#!/bin/bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

for i in {1..100}; do
  rpicam-still --immediate -o timelapse_$i.jpg
  sleep 30
done
```
