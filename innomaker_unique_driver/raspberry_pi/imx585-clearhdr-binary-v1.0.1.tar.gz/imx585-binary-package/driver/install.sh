#!/bin/bash

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "IMX585 ClearHDR Driver Installer v1.0.1"
echo "========================================"
echo

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Error: Please run as root (use sudo)${NC}"
    exit 1
fi

# Check kernel version
KERNEL_VERSION=$(uname -r)
REQUIRED_KERNEL="6.12.47+rpt-rpi-2712"

if [ "$KERNEL_VERSION" != "$REQUIRED_KERNEL" ]; then
    echo -e "${RED}Error: Kernel version mismatch${NC}"
    echo "Required: $REQUIRED_KERNEL"
    echo "Current:  $KERNEL_VERSION"
    echo
    echo "This binary package only works with kernel $REQUIRED_KERNEL"
    echo "Please use the source package to compile for your kernel."
    exit 1
fi

# Check if Raspberry Pi 5
if [ ! -f /proc/device-tree/model ]; then
    echo -e "${YELLOW}Warning: Cannot detect hardware model${NC}"
else
    MODEL=$(cat /proc/device-tree/model)
    if [[ ! "$MODEL" =~ "Raspberry Pi 5" ]]; then
        echo -e "${YELLOW}Warning: This package is designed for Raspberry Pi 5${NC}"
        echo "Detected: $MODEL"
        read -p "Continue anyway? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
fi

# Install driver
echo -e "${GREEN}Installing driver module...${NC}"
DRIVER_DIR="/lib/modules/$KERNEL_VERSION/kernel/drivers/media/i2c"
mkdir -p "$DRIVER_DIR"
cp imx585.ko "$DRIVER_DIR/"
chmod 644 "$DRIVER_DIR/imx585.ko"
echo "  ✓ Copied imx585.ko to $DRIVER_DIR/"

# Run depmod
echo -e "${GREEN}Updating module dependencies...${NC}"
depmod -a
echo "  ✓ Module dependencies updated"

# Install tuning files
echo -e "${GREEN}Installing tuning files...${NC}"
TUNING_DIR="/usr/local/share/libcamera/ipa/rpi/pisp"
mkdir -p "$TUNING_DIR"
cp ../tuning/*.json "$TUNING_DIR/"
chmod 644 "$TUNING_DIR"/imx585_*.json
echo "  ✓ Copied tuning files to $TUNING_DIR/"

# Verify installation
echo
echo -e "${GREEN}Verifying installation...${NC}"

if [ -f "$DRIVER_DIR/imx585.ko" ]; then
    echo "  ✓ Driver module installed"
else
    echo -e "  ${RED}✗ Driver module not found${NC}"
    exit 1
fi

if [ -f "$TUNING_DIR/imx585_color.json" ] && [ -f "$TUNING_DIR/imx585_mono.json" ]; then
    echo "  ✓ Tuning files installed"
else
    echo -e "  ${YELLOW}⚠ Tuning files may be incomplete${NC}"
fi

echo
echo -e "${GREEN}Installation completed successfully!${NC}"
echo
echo "Next steps:"
echo "1. Edit /boot/firmware/config.txt and add:"
echo "     dtoverlay=imx585,cam0        # for color camera"
echo "     dtoverlay=imx585,cam0,mono   # for mono camera"
echo "2. Reboot: sudo reboot"
echo "3. Test: v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1"
echo "         rpicam-still -o test.jpg"
echo
