#!/usr/bin/env python3
"""
IMX585 ClearHDR 16-bit RAW Merge Tool
--------------------------------------
Merges interleaved HCG (High Conversion Gain) and LCG (Low Conversion Gain)
columns from IMX585 ClearHDR RAW16 output into a single HDR image.

In ClearHDR RAW16 mode (CCMP_EN=0, MDBIT=3):
  - Even columns (0, 2, 4, ...): LCG data (low gain, captures highlights)
  - Odd columns  (1, 3, 5, ...): HCG data (high gain, captures shadows)
  - HCG/LCG gain ratio is set by EXP_GAIN register (default +12dB = 4x)

The merge algorithm:
  1. Normalize HCG to LCG scale (divide by gain ratio)
  2. Use HCG for shadow detail (where LCG is near black level)
  3. Use LCG for highlight detail (where HCG is saturated)
  4. Blend in the transition zone for smooth crossover
  5. Output: full-resolution 16-bit linear HDR image

Usage:
  python3 clearhdr_merge.py input.dng [-o output.tiff] [--gain-ratio 4.0]
                                       [--black-level 128] [--preview]

Requirements:
  pip install rawpy numpy tifffile  (or: apt install python3-numpy python3-tifffile)
"""

import argparse
import sys
import os
import numpy as np

def load_raw(path):
    """Load RAW DNG file and return pixel data + metadata."""
    try:
        import rawpy
    except ImportError:
        print("ERROR: rawpy not installed. Run: pip install rawpy", file=sys.stderr)
        sys.exit(1)

    raw = rawpy.imread(path)
    data = raw.raw_image.copy().astype(np.float64)
    raw.close()
    return data


def auto_detect_gain_ratio(data, black_level=128):
    """Auto-detect HCG/LCG gain ratio from the data."""
    even = data[:, ::2]   # LCG
    odd  = data[:, 1::2]  # HCG

    # Use mid-range pixels to estimate ratio (avoid black and saturated)
    lcg_flat = even.flatten()
    hcg_flat = odd.flatten()

    # Pair up corresponding pixels
    mask = (lcg_flat > black_level + 100) & (lcg_flat < 40000) & \
           (hcg_flat > black_level + 100) & (hcg_flat < 40000)

    if mask.sum() < 1000:
        print("WARNING: Not enough mid-range pixels for auto-detection, using default 4.0")
        return 4.0

    lcg_sel = lcg_flat[mask] - black_level
    hcg_sel = hcg_flat[mask] - black_level

    ratio = np.median(hcg_sel / lcg_sel)
    print(f"  Auto-detected gain ratio: {ratio:.2f}x ({20*np.log10(ratio):.1f} dB)")
    return ratio


def merge_hcg_lcg(data, gain_ratio=4.0, black_level=128, sat_level=None):
    """
    Merge interleaved HCG/LCG columns into a single HDR image.

    Parameters:
        data:        Raw 16-bit image (H x W) with interleaved columns
        gain_ratio:  HCG/LCG gain ratio (e.g. 4.0 for +12dB)
        black_level: Optical black level in the raw data
        sat_level:   Saturation level (auto-detect if None)

    Returns:
        merged: Full-resolution HDR image (H x W), float64, linear
    """
    H, W = data.shape
    half_W = W // 2

    # Separate channels
    lcg = data[:, ::2].astype(np.float64)   # Even columns: LCG
    hcg = data[:, 1::2].astype(np.float64)  # Odd columns:  HCG

    # Subtract black level
    lcg = np.maximum(lcg - black_level, 0.0)
    hcg = np.maximum(hcg - black_level, 0.0)

    # Normalize HCG to LCG scale
    hcg_normalized = hcg / gain_ratio

    # Determine saturation threshold
    if sat_level is None:
        sat_level = 65535 - black_level  # Max after BL subtraction

    # LCG saturation threshold (above this, LCG data is unreliable)
    lcg_sat = sat_level * 0.90

    # HCG noise floor: below this in HCG, the data is noisy
    hcg_noise = gain_ratio * 3  # ~3 ADU noise floor scaled

    # Blend zone: use HCG for shadows, LCG for highlights
    # Transition based on LCG signal level
    blend_lo = sat_level * 0.02   # Below this: use HCG (shadows)
    blend_hi = sat_level * 0.15   # Above this: use LCG (highlights)

    # Compute blend weight (0 = pure HCG, 1 = pure LCG)
    alpha = np.clip((lcg - blend_lo) / (blend_hi - blend_lo + 1e-10), 0.0, 1.0)

    # Where HCG is saturated, force LCG
    hcg_saturated = hcg > (sat_level * 0.95)
    alpha = np.where(hcg_saturated, 1.0, alpha)

    # Merge at half resolution
    merged_half = alpha * lcg + (1.0 - alpha) * hcg_normalized

    # Interpolate back to full resolution
    # Each merged pixel corresponds to a pair of original columns
    merged = np.zeros((H, W), dtype=np.float64)

    # Place merged values at even positions
    merged[:, ::2] = merged_half
    # Interpolate odd positions
    if half_W > 1:
        # Interior: average of neighbors
        merged[:, 1:-1:2] = (merged_half[:, :-1] + merged_half[:, 1:]) / 2.0
        # Last column
        merged[:, -1] = merged_half[:, -1] if W % 2 == 0 else merged_half[:, -1]
    else:
        merged[:, 1::2] = merged_half

    # Scale to 16-bit output range
    max_val = merged.max()
    if max_val > 0:
        merged = merged / max_val * 65535.0

    return merged


def save_tiff(path, data):
    """Save 16-bit TIFF."""
    try:
        import tifffile
    except ImportError:
        print("ERROR: tifffile not installed. Run: pip install tifffile", file=sys.stderr)
        sys.exit(1)

    data_u16 = np.clip(data, 0, 65535).astype(np.uint16)
    tifffile.imwrite(path, data_u16)
    print(f"  Saved: {path} ({data_u16.shape[1]}x{data_u16.shape[0]}, 16-bit)")


def save_preview(path, data):
    """Save 8-bit JPEG/PNG preview with simple tone mapping."""
    try:
        from PIL import Image
    except ImportError:
        print("WARNING: Pillow not installed, skipping preview. Run: pip install Pillow")
        return

    # Simple gamma tone mapping
    normalized = data / 65535.0
    gamma = 1.0 / 2.2
    tonemapped = np.power(np.clip(normalized, 0, 1), gamma)
    img_8bit = (tonemapped * 255).astype(np.uint8)

    img = Image.fromarray(img_8bit, mode='L')
    img.save(path, quality=95)
    print(f"  Preview: {path}")


def analyze_raw(data, black_level=128):
    """Print analysis of raw HCG/LCG data."""
    even = data[:, ::2]
    odd  = data[:, 1::2]

    print(f"  Image size: {data.shape[1]} x {data.shape[0]}")
    print(f"  Full range: [{data.min():.0f}, {data.max():.0f}]")
    print(f"  Even columns (LCG): mean={even.mean():.0f}, "
          f"range=[{even.min():.0f}, {even.max():.0f}]")
    print(f"  Odd columns  (HCG): mean={odd.mean():.0f}, "
          f"range=[{odd.min():.0f}, {odd.max():.0f}]")

    # Check for valid HCG/LCG pattern
    if abs(even.mean() - odd.mean()) < even.mean() * 0.1:
        print("  WARNING: Even/odd columns have similar values.")
        print("           This may not be ClearHDR RAW16 data.")
        return False
    return True


def main():
    parser = argparse.ArgumentParser(
        description="IMX585 ClearHDR 16-bit RAW HCG/LCG Merge Tool")
    parser.add_argument("input", help="Input RAW DNG file")
    parser.add_argument("-o", "--output", help="Output TIFF file "
                        "(default: input_merged.tiff)")
    parser.add_argument("--gain-ratio", type=float, default=0,
                        help="HCG/LCG gain ratio (0=auto-detect, default=0)")
    parser.add_argument("--black-level", type=int, default=128,
                        help="Optical black level (default: 128)")
    parser.add_argument("--preview", action="store_true",
                        help="Also save 8-bit JPEG preview")
    parser.add_argument("--analyze-only", action="store_true",
                        help="Only analyze the RAW data, don't merge")

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"ERROR: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    # Default output name
    if args.output is None:
        base = os.path.splitext(args.input)[0]
        args.output = base + "_merged.tiff"

    print(f"Loading: {args.input}")
    data = load_raw(args.input)

    print("Analyzing RAW data...")
    valid = analyze_raw(data, args.black_level)

    if args.analyze_only:
        if valid:
            ratio = auto_detect_gain_ratio(data, args.black_level)
        return

    if not valid:
        print("WARNING: Data doesn't look like ClearHDR RAW16. Proceeding anyway.")

    # Auto-detect or use specified gain ratio
    if args.gain_ratio <= 0:
        gain_ratio = auto_detect_gain_ratio(data, args.black_level)
    else:
        gain_ratio = args.gain_ratio
        print(f"  Using specified gain ratio: {gain_ratio:.2f}x")

    print(f"Merging HCG/LCG (gain ratio={gain_ratio:.2f}x, "
          f"black_level={args.black_level})...")
    merged = merge_hcg_lcg(data, gain_ratio, args.black_level)

    print(f"  Merged range: [{merged.min():.0f}, {merged.max():.0f}]")

    save_tiff(args.output, merged)

    if args.preview:
        preview_path = os.path.splitext(args.output)[0] + "_preview.jpg"
        save_preview(preview_path, merged)

    print("Done!")


if __name__ == "__main__":
    main()
