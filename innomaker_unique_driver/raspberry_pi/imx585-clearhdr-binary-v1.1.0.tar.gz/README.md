# IMX585 ClearHDR Support Package

Sony IMX585 Dual Conversion Gain HDR (ClearHDR) driver and tools for Raspberry Pi 5.

## Quick Start

### 1. Install

- **Binary package** (recommended): for kernel `6.12.47+rpt-rpi-2712`
  ```bash
  cd driver-binary
  ./install.sh
  ```

- **Build from source**: for other kernel versions
  ```bash
  cd driver-source
  ./build.sh
  ```

### 2. Configure

Edit `/boot/firmware/config.txt`:
```ini
camera_auto_detect=0

# Color camera
dtoverlay=imx585,cam0

# Mono camera
dtoverlay=imx585,cam0,mono
```

### 3. Reboot

```bash
sudo reboot
```

### 4. Test Three Modes

**Normal SDR (default)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0
rpicam-hello -t 5s --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json
```

**ClearHDR 12-bit (real-time HDR)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
rpicam-hello -t 5s --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json
```

**ClearHDR 16-bit (maximum dynamic range, manual exposure)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
media-ctl -d /dev/media0 --set-v4l2 '"imx585 10-001a":0[fmt:Y16_1X16/3856x2180]'
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --raw -o raw16.jpg --shutter 20000 --gain 4 --awbgains 1,1 --immediate
```

**Return to Normal SDR**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0
```

> Color cameras: replace `imx585_mono.json` / `imx585_mono_hdr.json` with `imx585.json` / `imx585_hdr.json`.

## Documentation

See **[USAGE.md](USAGE.md)** for the full usage guide.

## Contents

- IMX585 driver module (ClearHDR 12/16-bit support)
- Tuning files (SDR + HDR, color + mono)
- HCG/LCG merge tool (16-bit post-processing)
- Install / build scripts

## Requirements

- Raspberry Pi 5
- Raspberry Pi OS Bookworm or later
- Kernel 6.12.x+rpt-rpi-2712 (6.12.47 recommended)
- Sony IMX585 camera module

## Known Issues

- 16-bit mode requires manual exposure (PiSP statistics do not support 16-bit)
- ClearHDR 12-bit HDR tuning is preliminary; image quality may vary across lighting conditions

## Version

- **Version**: 1.1.0
- **Date**: 2026-06-10
- **Kernel**: 6.12.47+rpt-rpi-2712

### v1.1.0 Changelog
- Fix Normal SDR grid pattern (mode-dependent registers 0x493C/0x4940)
- Fix ClearHDR 12-bit garbled display (format code priority)
- Fix segfault when enabling ClearHDR (NULL mode pointer guard)
- Add ClearHDR HDR tuning files (`imx585_hdr.json`, `imx585_mono_hdr.json`)
- Separate HMAX lookup tables for 10-bit and 12-bit modes
- ClearHDR timing improvements (SHR_MIN_HDR, HMAX floor=550)
- Dedicated 16-bit mode support with precise OB region handling
