# IMX585 ClearHDR Support Package

Sony IMX585 Dual Conversion Gain HDR (ClearHDR) driver and tools for Raspberry Pi 5.

## Quick Start

### 1. Install

- **Binary package**: for kernel `6.12.47+rpt-rpi-2712`
  ```bash
  cd driver-binary
  ./install.sh
  ```

### 2. Configure

Edit `/boot/firmware/config.txt`:
```ini
# Color camera
dtoverlay=imx585,cam0

# Mono camera
dtoverlay=imx585,cam0,mono
```

### 3. Reboot

```bash
sudo reboot
```

### 4. Usage

**Normal SDR (default)**:
```bash
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json
```

**ClearHDR 12-bit (real-time HDR)**:
```bash
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --width 3840 --height 2160 --hdr
```

**ClearHDR 16-bit (maximum dynamic range)**:
```bash
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --width 3840 --height 2160 --hdr --mode 3840:2160:SRGGB16
```

> The `--hdr` flag automatically switches ClearHDR on/off. No manual `v4l2-ctl` needed.

## Documentation

See **[USAGE.md](USAGE.md)** for detailed usage guide.

## Contents

- IMX585 driver module (ClearHDR 12/16-bit support)
- Tuning files (color / mono)
- HCG/LCG merge tool (16-bit post-processing)
- Install / build scripts
- Full documentation

## Requirements

- Raspberry Pi 5
- Raspberry Pi OS Bookworm
- Kernel 6.12.x+rpt-rpi-2712 (6.12.47 recommended)
- Sony IMX585 camera module

## Known Issues

- 16-bit mode requires manual exposure (PiSP does not support 16-bit statistics)

## Version

- **Version**: 1.1.0
- **Date**: 2026-06-09
- **Kernel**: 6.12.47+rpt-rpi-2712

### v1.1.0 Changelog
- Fix Normal SDR grid pattern issue
- Separate HMAX lookup tables for 10-bit and 12-bit modes
- ClearHDR timing improvements
- Dedicated 16-bit mode support
- Precise OB region handling
