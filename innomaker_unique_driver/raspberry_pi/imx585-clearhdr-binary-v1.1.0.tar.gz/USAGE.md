# IMX585 ClearHDR Usage Guide

## Overview

This package provides ClearHDR (Dual Conversion Gain HDR) support for the Sony IMX585 sensor with three operating modes:

- **Normal SDR**: Standard single conversion gain mode (default)
- **ClearHDR 12-bit**: Gradation-compressed HDR (sensor-internal fusion, real-time preview/recording)
- **ClearHDR 16-bit**: Linear RAW HDR (post-processing merge, maximum dynamic range)

**Requirements**:
- Raspberry Pi 5
- Sony IMX585 camera module
- Raspberry Pi OS (Bookworm) or later
- Kernel: 6.12.47+rpt-rpi-2712 (recommended) or compatible

---

## Installation

### Option 1: Binary Package (Recommended)

For kernel `6.12.47+rpt-rpi-2712`:

```bash
cd driver-binary
chmod +x install.sh
./install.sh
sudo reboot
```

---

### Option 2: Build from Source

For other kernel versions or custom builds:

#### Step 1: Install kernel headers

```bash
sudo apt update
sudo apt install raspberrypi-kernel-headers
```

#### Step 2: Build and install

```bash
cd driver-source
chmod +x build.sh
./build.sh
sudo reboot
```

---

## Configuration

### Device Tree

Edit `/boot/firmware/config.txt`:

```ini
# Color camera
dtoverlay=imx585,cam0

# Mono camera
dtoverlay=imx585,cam0,mono
```

Save and reboot.

### Verify Installation

```bash
# Check driver log
dmesg | grep imx585

# Check device nodes
ls /dev/v4l-subdev*

# List cameras
rpicam-hello --list-cameras
```

---

## Quick Start

### Mode Switching

The v1.1.0 driver supports `--hdr` flag for automatic ClearHDR switching. No manual `v4l2-ctl` commands needed.

**Normal SDR (default)**:
```bash
# Color camera
rpicam-hello -t 0

# Mono camera
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json
```

**ClearHDR 12-bit (real-time HDR preview/recording)**:
```bash
# Color camera
rpicam-hello -t 0 --width 3840 --height 2160 --hdr

# Mono camera
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --width 3840 --height 2160 --hdr
```

**ClearHDR 16-bit (maximum dynamic range)**:
```bash
# Color camera
rpicam-hello -t 0 --width 3840 --height 2160 --hdr --mode 3840:2160:SRGGB16

# Mono camera
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --width 3840 --height 2160 --hdr --mode 3840:2160:SRGGB16
```

> **Note**: The `--hdr` flag triggers automatic WDR register switching in the driver.

---

## Detailed Usage

### Option A: 12-bit ClearHDR (Gradation Compression)

Sensor-internal HCG/LCG fusion, outputs 12-bit compressed HDR. Best for real-time applications.

#### Still Capture

**Auto exposure** (recommended):
```bash
# Color
rpicam-still -o hdr_photo.jpg -t 2000 --hdr

# Mono
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  -o hdr_photo.jpg -t 2000 --hdr
```

**Manual exposure**:
```bash
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  -o hdr_photo.jpg --shutter 20000 --gain 4 --immediate --hdr
```

#### Video

```bash
rpicam-vid --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  -o hdr_video.h264 -t 10000 --hdr
```

#### Parameters

- `--hdr`: Enable ClearHDR mode (required)
- `--shutter`: Exposure time in microseconds (100-60000)
- `--gain`: Analog gain (1.0-8.0, max 8 in ClearHDR)
- `-t`: Preview duration in milliseconds (for AE stabilization)

---

### Option B: 16-bit RAW (Post-Processing Merge)

Full dynamic range preserved. HCG/LCG merged in software for highest quality HDR.

#### Capture 16-bit RAW

```bash
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --mode 3840:2160:SRGGB16 --raw -o raw16.jpg \
  --shutter 20000 --gain 4 --awbgains 1,1 --immediate --hdr
```

**Important**: 16-bit mode requires manual exposure (`--shutter`, `--gain`) as PiSP statistics do not support 16-bit.

#### Merge HCG/LCG

Process the RAW DNG with the merge tool:

```bash
# Auto-detect gain ratio
clearhdr_merge.py raw16.dng -o merged.tiff

# Specify gain ratio
clearhdr_merge.py raw16.dng -o merged.tiff --gain-ratio 4.0

# Generate 8-bit preview
clearhdr_merge.py raw16.dng -o merged.tiff --preview

# Analyze only (no merge)
clearhdr_merge.py raw16.dng --analyze-only
```

#### Parameters

- `--gain-ratio`: HCG/LCG gain ratio (auto-detected by default), corresponds to EXP_GAIN register
  - `+12dB` (default) = 4.0x
  - `+6dB` = 2.0x
- `--black-level`: Optical black level (default 128)
- `--preview`: Generate 8-bit JPEG preview

#### Output Formats

- `.tiff`: 16-bit linear TIFF, full dynamic range, for post-processing
- `_preview.jpg`: 8-bit gamma-corrected preview (requires `--preview`)

---

## FAQ

### Q: Image is all black or shows a fixed pattern?

**A**: Check the following:
1. Lens cap removed
2. Sufficient lighting
3. Reasonable exposure parameters (shutter >= 10000, gain >= 2)
4. `--hdr` flag is present for ClearHDR modes

### Q: How to choose between 12-bit and 16-bit?

**A**:
- **12-bit (Option A)**: Real-time applications, video streaming, quick capture
- **16-bit (Option B)**: High-quality stills, maximum dynamic range, post-processing flexibility

### Q: Must I specify a tuning file for mono cameras?

**A**: Yes. Mono cameras require `imx585_mono.json`, otherwise the ISP applies Bayer demosaicing and produces artifacts.

### Q: What is the ClearHDR dynamic range?

**A**:
- 12-bit mode: ~90-100 dB (depends on gradation compression parameters)
- 16-bit mode: ~120+ dB (theoretical max, limited by sensor noise floor)

### Q: How to disable ClearHDR?

**A**: Simply omit the `--hdr` flag. The driver automatically switches back to Normal SDR.

### Q: Merge tool reports "not ClearHDR RAW16 data"?

**A**:
- Ensure `--mode 3840:2160:SRGGB16` was used
- Confirm `--hdr` flag was present during capture
- Confirm the `.dng` file was generated (`--raw` flag)

---

## Advanced Configuration

### Tuning the 12-bit Gradation Compression Curve

Edit the `rpi.hdr` section in the tuning JSON for more aggressive compression or smoother transitions.

---

## Technical Details

### How ClearHDR Works

IMX585 ClearHDR captures two readings per pixel simultaneously:
- **LCG (Low Conversion Gain)**: Low gain, captures highlight detail, avoids saturation
- **HCG (High Conversion Gain)**: High gain (+12dB), captures shadow detail, reduces noise

**12-bit mode**: The sensor internally fuses HCG and LCG via CCMP (gradation compression) into a single 12-bit value.

**16-bit mode**: The sensor outputs interleaved HCG/LCG columns:
```
Even columns (0, 2, 4, ...): LCG readings
Odd columns  (1, 3, 5, ...): HCG readings
```
The merge tool combines them into a full-resolution HDR image.

---

## Support

**Known Issues**:
- PiSP does not support AGC statistics for 16-bit input; manual exposure required

**Bug Reports**: Please provide:
- Kernel version: `uname -r`
- Driver log: `dmesg | grep imx585`
- Camera type (color/mono)
- Steps to reproduce

---

## Appendix

### File List

```
imx585-clearhdr-release/
├── driver-binary/          # Pre-built driver
│   ├── imx585.ko           # Compiled driver module
│   ├── install.sh          # Install script
│   └── README.txt          # Kernel version info
├── driver-source/          # Source package
│   ├── imx585-driver-source.tar.gz  # Driver source
│   └── build.sh            # Build script
├── tools/                  # Utilities
│   └── clearhdr_merge.py   # HCG/LCG merge tool
├── tuning/                 # Tuning files
│   ├── imx585_color.json   # Color camera
│   └── imx585_mono.json    # Mono camera
└── USAGE.md                # This document
```

### Dependencies

Runtime:
```bash
# For merge tool
pip install rawpy numpy tifffile pillow --break-system-packages

# Or system packages
sudo apt install python3-numpy python3-pil
```

Build (source install only):
```bash
sudo apt install raspberrypi-kernel-headers build-essential
```

---

**Version**: 1.1.0
**Date**: 2026-06-09
