# IMX585 ClearHDR Usage Guide

## Overview

This package provides ClearHDR (Dual Conversion Gain HDR) support for the Sony IMX585 sensor with three operating modes:

- **Normal SDR**: Standard single conversion gain mode (default)
- **ClearHDR 12-bit**: Gradation-compressed HDR (sensor-internal fusion, real-time preview/recording)
- **ClearHDR 16-bit**: Linear RAW HDR (post-processing merge, maximum dynamic range)

**Requirements**:
- Raspberry Pi 5
- Sony IMX585 camera module
- Raspberry Pi OS (Bookworm) or later
- Kernel: 6.12.47+rpt-rpi-2712 (recommended) or compatible

---

## Installation

### Option 1: Binary Package (Recommended)

For kernel `6.12.47+rpt-rpi-2712`:

```bash
cd driver-binary
chmod +x install.sh
./install.sh
sudo reboot
```

---

### Option 2: Build from Source

For other kernel versions or custom builds:

#### Step 1: Install kernel headers

```bash
sudo apt update
sudo apt install raspberrypi-kernel-headers
```

#### Step 2: Build and install

```bash
cd driver-source
chmod +x build.sh
./build.sh
sudo reboot
```

---

## Configuration

### Device Tree

Edit `/boot/firmware/config.txt`:

```ini
camera_auto_detect=0

# Color camera, 4-lane, default link speed (720 MHz)
dtoverlay=imx585,cam0

# Mono camera, 4-lane, default link speed (720 MHz)
dtoverlay=imx585,cam0,mono

# Full example: mono, always-on, high-speed link
dtoverlay=imx585,cam0,mono,always-on,link-frequency=1039500000
```

#### Key Parameters

| Parameter | Description |
|-----------|-------------|
| `cam0` | Use CAM0 port (CAM1 also supported) |
| `mono` | Mono sensor mode (disables Bayer demosaicing) |
| `2lane` | Use 2-lane CSI-2 (default is 4-lane). HMAX doubles automatically |
| `always-on` | Keep sensor powered on between captures |
| `link-frequency=<Hz>` | CSI-2 link clock frequency (see table below) |

#### Supported Link Frequencies

| link-frequency | Data Rate (per lane) | Notes |
|---------------:|---------------------:|-------|
| 297000000 | 594 Mbps | 2-lane recommended |
| 360000000 | 720 Mbps | 2-lane recommended |
| 445500000 | 891 Mbps | |
| 594000000 | 1188 Mbps | |
| **720000000** | **1440 Mbps** | **Default (no parameter needed)** |
| 891000000 | 1782 Mbps | |
| 1039500000 | 2079 Mbps | High-speed, verify signal integrity |
| 1188000000 | 2376 Mbps | Maximum, requires good PCB/cable |

> **Note**: Higher link frequencies allow faster frame rates but require good signal integrity. If you experience frame errors, try a lower frequency.

Save and reboot.

### Verify Installation

```bash
# Check driver loaded
dmesg | grep imx585

# Check device nodes
ls /dev/v4l-subdev*

# List cameras
rpicam-hello --list-cameras
```

---

## Quick Start — Three Modes

ClearHDR mode is controlled via `v4l2-ctl` **before** launching rpicam. The sensor subdevice is typically `/dev/v4l-subdev2` (verify with `v4l2-ctl --list-devices`).

### Mode 1: Normal SDR (Default)

Standard 12-bit single gain mode. Best image quality for well-lit scenes.

```bash
# Ensure ClearHDR is off (default after boot)
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0

# Preview (mono)
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json

# Preview (color)
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585.json
```

### Mode 2: ClearHDR 12-bit (Real-time HDR)

Sensor-internal HCG/LCG fusion with gradation compression. Best for real-time HDR preview, video recording, and still capture.

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Preview with HDR tuning (mono)
rpicam-hello -t 0 --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json

# Preview with HDR tuning (color)
rpicam-hello -t 0 --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_hdr.json

# Still capture (mono)
rpicam-still --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json \
  -o hdr_photo.jpg -t 2000

# Video recording (mono)
rpicam-vid --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json \
  -o hdr_video.h264 -t 10000
```

> **Note**: The `--hdr` flag activates the ISP's HDR tone mapping pipeline, which compensates for the CCMP compressed data. Always use `--hdr` with the `_hdr.json` tuning files for ClearHDR 12-bit.

### Mode 3: ClearHDR 16-bit (Maximum Dynamic Range)

Full 16-bit linear HDR output. Requires manual exposure and post-processing merge.

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Force sensor to 16-bit output (mono)
media-ctl -d /dev/media0 --set-v4l2 '"imx585 10-001a":0[fmt:Y16_1X16/3856x2180]'

# Capture 16-bit RAW (mono, manual exposure required)
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --raw -o raw16.jpg --shutter 20000 --gain 4 --awbgains 1,1 --immediate
```

For color cameras, replace `Y16_1X16` with `SRGGB16_1X16` and use `imx585.json`.

> **Important**: 16-bit mode requires manual exposure (`--shutter`, `--gain`) as PiSP statistics do not support 16-bit data.

### Return to Normal SDR

```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0
```

> ClearHDR mode persists until changed or reboot. Normal SDR is restored automatically after reboot.

---

## HDR Controls

### HDR Gain

Adjust the HCG/LCG gain ratio (effective only when ClearHDR is active):

```bash
# Set HDR gain: 0=+0dB, 1=+6dB, 2=+12dB(default), 3=+18dB, 4=+24dB, 5=+29.1dB
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl hdr_gain_adder_db=2
```

### Tuning Files

| File | Usage |
|------|-------|
| `imx585.json` | Color camera, Normal SDR |
| `imx585_mono.json` | Mono camera, Normal SDR |
| `imx585_hdr.json` | Color camera, ClearHDR 12-bit |
| `imx585_mono_hdr.json` | Mono camera, ClearHDR 12-bit |

The HDR tuning files include:
- Adjusted AGC for ClearHDR dynamic range
- Adaptive tone mapping to compensate for gradation compression
- Steeper gamma curve for better contrast

---

## 16-bit Merge Tool

Process 16-bit RAW DNG files captured in Mode 3:

```bash
# Auto-detect gain ratio
clearhdr_merge.py raw16.dng -o merged.tiff

# Specify gain ratio
clearhdr_merge.py raw16.dng -o merged.tiff --gain-ratio 4.0

# Generate 8-bit preview
clearhdr_merge.py raw16.dng -o merged.tiff --preview

# Analyze only (no merge)
clearhdr_merge.py raw16.dng --analyze-only
```

### Parameters

- `--gain-ratio`: HCG/LCG gain ratio (auto-detected by default)
  - `+12dB` (default) = 4.0x
  - `+6dB` = 2.0x
- `--black-level`: Optical black level (default 128)
- `--preview`: Generate 8-bit JPEG preview

---

## FAQ

### Q: Image is all black or shows a fixed pattern?

**A**: Check the following:
1. Lens cap removed
2. Sufficient lighting
3. Reasonable exposure parameters (shutter >= 10000, gain >= 2)
4. ClearHDR state: `v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range`

### Q: ClearHDR 12-bit image looks washed out?

**A**: Make sure you are using both `--hdr` flag and the `_hdr.json` tuning file:
```bash
rpicam-hello -t 0 --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json
```
Without `--hdr`, the ISP does not apply HDR tone mapping, causing a flat/washed look.

### Q: How to choose between 12-bit and 16-bit?

**A**:
- **12-bit (Mode 2)**: Real-time applications, video streaming, quick capture
- **16-bit (Mode 3)**: High-quality stills, maximum dynamic range, post-processing flexibility

### Q: Must I specify a tuning file for mono cameras?

**A**: Yes. Mono cameras require the `_mono` variant, otherwise the ISP applies Bayer demosaicing and produces artifacts.

### Q: What is the ClearHDR dynamic range?

**A**:
- 12-bit mode: ~90-100 dB (depends on gradation compression parameters)
- 16-bit mode: ~120+ dB (theoretical max, limited by sensor noise floor)

### Q: How to find the sensor subdevice?

**A**: Run `v4l2-ctl --list-devices` and look for `imx585`. Typically `/dev/v4l-subdev2`.

### Q: Merge tool reports "not ClearHDR RAW16 data"?

**A**:
- Ensure 16-bit format was set via `media-ctl`
- Confirm ClearHDR was enabled: `v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range`
- Confirm the `.dng` file was generated (`--raw` flag)

---

## File List

```
imx585-clearhdr-release/
├── driver-binary/             # Pre-built driver
│   ├── imx585.ko              # Compiled driver module
│   ├── install.sh             # Install script
│   └── README.txt             # Kernel version info
├── driver-source/             # Source package
│   ├── imx585-driver-source.tar.gz  # Driver source
│   └── build.sh               # Build script
├── tools/                     # Utilities
│   └── clearhdr_merge.py      # HCG/LCG merge tool
├── tuning/                    # Tuning files
│   ├── imx585.json            # Color SDR
│   ├── imx585_mono.json       # Mono SDR
│   ├── imx585_hdr.json        # Color ClearHDR
│   └── imx585_mono_hdr.json   # Mono ClearHDR
├── README.md                  # Quick start
└── USAGE.md                   # This document
```

### Dependencies

Runtime:
```bash
# For merge tool
pip install rawpy numpy tifffile pillow --break-system-packages

# Or system packages
sudo apt install python3-numpy python3-pil
```

Build (source install only):
```bash
sudo apt install raspberrypi-kernel-headers build-essential
```

---

**Version**: 1.1.0
**Date**: 2026-06-10
