#!/bin/bash
# IMX585 ClearHDR Driver Binary Installation Script
# For Raspberry Pi 5 with kernel 6.12.47+rpt-rpi-2712

set -e

KERNEL_VER=$(uname -r)
TARGET_KERNEL="6.12.47+rpt-rpi-2712"

echo "=== IMX585 ClearHDR Driver Installer ==="
echo "Current kernel: $KERNEL_VER"
echo "Target kernel:  $TARGET_KERNEL"
echo ""

if [ "$KERNEL_VER" != "$TARGET_KERNEL" ]; then
    echo "WARNING: Kernel version mismatch!"
    echo "This driver was compiled for $TARGET_KERNEL"
    echo "Your kernel is $KERNEL_VER"
    echo ""
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 1
    fi
fi

echo "Installing driver module..."
sudo cp imx585.ko /lib/modules/$KERNEL_VER/kernel/drivers/media/i2c/
sudo depmod -a

echo "Installing tuning files..."
sudo mkdir -p /usr/local/share/libcamera/ipa/rpi/pisp
sudo cp ../tuning/imx585_color.json /usr/local/share/libcamera/ipa/rpi/pisp/imx585.json
sudo cp ../tuning/imx585_mono.json /usr/local/share/libcamera/ipa/rpi/pisp/

echo "Installing merge tool..."
sudo cp ../tools/clearhdr_merge.py /usr/local/bin/
sudo chmod +x /usr/local/bin/clearhdr_merge.py

echo ""
echo "Installation complete!"
echo ""
echo "Next steps:"
echo "  1. Reboot the system: sudo reboot"
echo "  2. Verify driver loaded: dmesg | grep imx585"
echo "  3. See ../USAGE.md for ClearHDR usage examples"
