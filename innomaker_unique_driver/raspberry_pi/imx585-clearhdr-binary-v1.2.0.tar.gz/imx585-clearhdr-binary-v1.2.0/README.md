# IMX585 ClearHDR Support Package

Sony IMX585 Dual Conversion Gain HDR (ClearHDR) driver and tools for Raspberry Pi 5.

## Quick Start

### 1. Install

For kernel `6.12.47+rpt-rpi-2712`:
```bash
cd driver-binary
./install.sh
```

### 2. Configure

Edit `/boot/firmware/config.txt`:
```ini
camera_auto_detect=0

# Color camera
dtoverlay=imx585,cam0

# Mono camera
dtoverlay=imx585,cam0,mono
```

### 3. Reboot

```bash
sudo reboot
```

### 4. Test the Modes

**Normal SDR / LCG (default)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0,hcg_enable=0
rpicam-hello -t 5s --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json
```

**HCG SDR (low-light, high conversion gain)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0,hcg_enable=1
rpicam-hello -t 5s --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json
```

**ClearHDR 12-bit (real-time HDR)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
rpicam-hello -t 5s --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json
```

**ClearHDR 16-bit (maximum dynamic range, manual exposure)**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
media-ctl -d /dev/media0 --set-v4l2 '"imx585 10-001a":0[fmt:Y16_1X16/3856x2180]'
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --raw -o raw16.jpg --shutter 20000 --gain 4 --awbgains 1,1 --immediate
```

**Return to Normal SDR**:
```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0
```

> Color cameras: replace `imx585_mono.json` / `imx585_mono_hdr.json` with `imx585.json` / `imx585_hdr.json`.

## Documentation

See **[USAGE.md](USAGE.md)** for the full usage guide.

## Contents

- IMX585 driver module (Normal SDR / HCG / ClearHDR 12/16-bit support)
- Tuning files (SDR + HDR, color + mono)
- 16-bit HDR merge tool (post-processing)
- Install script

## Requirements

- Raspberry Pi 5
- Raspberry Pi OS Bookworm or later
- Kernel 6.12.x+rpt-rpi-2712 (6.12.47 recommended)
- Sony IMX585 camera module

## Notes

- 16-bit mode uses manual exposure — set `--shutter` and `--gain` explicitly.
- For best ClearHDR 12-bit contrast, pair the `--hdr` flag with the matching `_hdr.json` tuning file.

## Version

- **Version**: 1.2.0
- **Date**: 2026-06-27
- **Kernel**: 6.12.47+rpt-rpi-2712

### v1.2.0 Changelog
- Document the three single-frame/HDR modes — Normal SDR (LCG), HCG SDR, ClearHDR — and how to switch
  them with the `wide_dynamic_range` and `hcg_enable` V4L2 controls (see USAGE.md)
- Installer now detects `config.txt`, reports whether the `dtoverlay=imx585` line is present, and can
  append it (with a backup) so the camera binds after reboot
- Add `CHECKSUMS.sha256` to the release package

### v1.1.0 Changelog
- Normal SDR image quality and stability improvements
- ClearHDR 12-bit real-time HDR support
- ClearHDR HDR tuning files (`imx585_hdr.json`, `imx585_mono_hdr.json`)
- Refined 10-bit and 12-bit mode timing
- Dedicated 16-bit maximum-dynamic-range mode
