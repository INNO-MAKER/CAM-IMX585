# IMX585 ClearHDR Usage Guide

## Overview

This package provides Dual Conversion Gain support for the Sony IMX585 sensor with the following operating modes:

- **Normal SDR (LCG)**: Standard low conversion gain, maximum full-well capacity (default)
- **HCG SDR**: High conversion gain — lower read noise for low-light scenes (single-frame SDR)
- **ClearHDR 12-bit**: Tone-compressed HDR (sensor-internal fusion, real-time preview/recording)
- **ClearHDR 16-bit**: Linear RAW HDR (post-processing merge, maximum dynamic range)

**Requirements**:
- Raspberry Pi 5
- Sony IMX585 camera module
- Raspberry Pi OS (Bookworm) or later
- Kernel: 6.12.47+rpt-rpi-2712 (recommended) or compatible

---

## Installation

For kernel `6.12.47+rpt-rpi-2712`:

```bash
cd driver-binary
chmod +x install.sh
./install.sh
sudo reboot
```

---

## Configuration

### Device Tree

Edit `/boot/firmware/config.txt`:

```ini
camera_auto_detect=0

# Color camera, 4-lane, default link speed (720 MHz)
dtoverlay=imx585,cam0

# Mono camera, 4-lane, default link speed (720 MHz)
dtoverlay=imx585,cam0,mono

# Full example: mono, always-on, high-speed link
dtoverlay=imx585,cam0,mono,always-on,link-frequency=1039500000
```

#### Key Parameters

| Parameter | Description |
|-----------|-------------|
| `cam0` | Use CAM0 port (CAM1 also supported) |
| `mono` | Mono sensor mode (disables Bayer demosaicing) |
| `2lane` | Use 2-lane CSI-2 (default is 4-lane). Line timing adjusts automatically |
| `always-on` | Keep sensor powered on between captures |
| `link-frequency=<Hz>` | CSI-2 link clock frequency (see table below) |

#### Supported Link Frequencies

| link-frequency | Data Rate (per lane) | Notes |
|---------------:|---------------------:|-------|
| 297000000 | 594 Mbps | 2-lane recommended |
| 360000000 | 720 Mbps | 2-lane recommended |
| 445500000 | 891 Mbps | |
| 594000000 | 1188 Mbps | |
| **720000000** | **1440 Mbps** | **Default (no parameter needed)** |
| 891000000 | 1782 Mbps | |
| 1039500000 | 2079 Mbps | High-speed, verify signal integrity |
| 1188000000 | 2376 Mbps | Maximum, requires good PCB/cable |

> **Note**: Higher link frequencies allow faster frame rates but require good signal integrity. If you experience frame errors, try a lower frequency.

Save and reboot.

### Verify Installation

```bash
# Check driver loaded
dmesg | grep imx585

# Check device nodes
ls /dev/v4l-subdev*

# List cameras
rpicam-hello --list-cameras
```

---

## Quick Start — Operating Modes

The operating mode is selected through two V4L2 controls on the sensor subdevice (typically
`/dev/v4l-subdev2`, verify with `v4l2-ctl --list-devices`). Set the mode **before** launching rpicam.

### Mode Switching at a Glance

| Mode | `wide_dynamic_range` | `hcg_enable` | Use case |
|------|:--:|:--:|------|
| **Normal SDR (LCG)** | 0 | 0 | Default; bright scenes, maximum highlight headroom |
| **HCG SDR** | 0 | 1 | Low-light scenes; lower read noise, reduced full-well |
| **ClearHDR** | 1 | (auto 0) | High-contrast scenes; 12-bit real-time or 16-bit RAW |

```bash
# NORMAL SDR (low conversion gain)
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0,hcg_enable=0

# HCG SDR (high conversion gain, low-light)
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0,hcg_enable=1

# ClearHDR (hcg_enable is forced to 0 automatically)
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1
```

> **Set the mode before launching rpicam, or stop capture before switching.** Toggling `hcg_enable`
> is a light, live change, but toggling `wide_dynamic_range` reconfigures frame timing
> and the pixel format, so switch it while no capture is running. Entering ClearHDR
> automatically disables HCG; leaving ClearHDR restores Normal SDR (LCG).

### Mode 1: Normal SDR (Default)

Standard 12-bit low conversion gain (LCG). Best image quality and highlight headroom for well-lit scenes.

```bash
# Ensure ClearHDR is off (default after boot) and use low conversion gain
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0,hcg_enable=0

# Preview (mono)
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json

# Preview (color)
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585.json
```

### Mode 1b: HCG SDR (Low-Light)

High Conversion Gain — the same single-frame SDR pipeline as Mode 1, but the sensor switches to its
high-conversion-gain readout for **lower read noise** in dark scenes. Trade-offs: reduced full-well
(earlier highlight saturation) and a higher minimum analogue gain. Uses the same tuning files as
Normal SDR.

```bash
# Enable HCG (ClearHDR must be off)
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0,hcg_enable=1

# Preview (mono)
rpicam-hello -t 0 --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json

# Return to standard low conversion gain
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl hcg_enable=0
```

> HCG applies only in Normal SDR. The control is ignored (forced off) while ClearHDR is active.

### Mode 2: ClearHDR 12-bit (Real-time HDR)

Sensor-internal dual-gain HDR fusion with tone compression. Best for real-time HDR preview, video recording, and still capture.

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Preview with HDR tuning (mono)
rpicam-hello -t 0 --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json

# Preview with HDR tuning (color)
rpicam-hello -t 0 --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_hdr.json

# Still capture (mono)
rpicam-still --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json \
  -o hdr_photo.jpg -t 2000

# Video recording (mono)
rpicam-vid --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json \
  -o hdr_video.h264 -t 10000
```

> **Note**: The `--hdr` flag activates the ISP's HDR tone mapping pipeline, which compensates for the compressed HDR data. Always use `--hdr` with the `_hdr.json` tuning files for ClearHDR 12-bit.

### Mode 3: ClearHDR 16-bit (Maximum Dynamic Range)

Full 16-bit linear HDR output. Requires manual exposure and post-processing merge.

```bash
# Enable ClearHDR
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=1

# Force sensor to 16-bit output (mono)
media-ctl -d /dev/media0 --set-v4l2 '"imx585 10-001a":0[fmt:Y16_1X16/3856x2180]'

# Capture 16-bit RAW (mono, manual exposure required)
rpicam-still --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json \
  --raw -o raw16.jpg --shutter 20000 --gain 4 --awbgains 1,1 --immediate
```

For color cameras, replace `Y16_1X16` with `SRGGB16_1X16` and use `imx585.json`.

> **Important**: 16-bit mode uses manual exposure — set `--shutter` and `--gain` explicitly.

### Return to Normal SDR

```bash
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl wide_dynamic_range=0
```

> ClearHDR mode persists until changed or reboot. Normal SDR is restored automatically after reboot.

---

## HDR Controls

### HDR Gain

Adjust the HDR dual-gain ratio (effective only when ClearHDR is active):

```bash
# Set HDR gain: 0=+0dB, 1=+6dB, 2=+12dB(default), 3=+18dB, 4=+24dB, 5=+29.1dB
v4l2-ctl -d /dev/v4l-subdev2 --set-ctrl hdr_gain_adder_db=2
```

### Tuning Files

| File | Usage |
|------|-------|
| `imx585.json` | Color camera, Normal SDR |
| `imx585_mono.json` | Mono camera, Normal SDR |
| `imx585_hdr.json` | Color camera, ClearHDR 12-bit |
| `imx585_mono_hdr.json` | Mono camera, ClearHDR 12-bit |

The HDR tuning files include:
- Adjusted AGC for ClearHDR dynamic range
- Adaptive tone mapping to compensate for HDR tone compression
- Steeper gamma curve for better contrast

---

## 16-bit Merge Tool

Process 16-bit RAW DNG files captured in Mode 3:

```bash
# Auto-detect gain ratio
clearhdr_merge.py raw16.dng -o merged.tiff

# Specify gain ratio
clearhdr_merge.py raw16.dng -o merged.tiff --gain-ratio 4.0

# Generate 8-bit preview
clearhdr_merge.py raw16.dng -o merged.tiff --preview

# Analyze only (no merge)
clearhdr_merge.py raw16.dng --analyze-only
```

### Parameters

- `--gain-ratio`: HDR dual-gain ratio (auto-detected by default)
  - `+12dB` (default) = 4.0x
  - `+6dB` = 2.0x
- `--black-level`: Optical black level (default 128)
- `--preview`: Generate 8-bit JPEG preview

---

## FAQ

### Q: The preview does not look like the scene?

**A**: Check the following:
1. Lens cap removed
2. Sufficient lighting
3. Reasonable exposure parameters (shutter >= 10000, gain >= 2)
4. Selected mode matches the tuning file (Normal vs ClearHDR):
   `v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range`

### Q: How do I get the best ClearHDR 12-bit contrast?

**A**: Pair the `--hdr` flag with the matching `_hdr.json` tuning file so the ISP applies HDR tone
mapping, and lock exposure manually for the most consistent result:
```bash
rpicam-hello -t 0 --hdr --tuning-file /usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono_hdr.json
# For the steadiest contrast, also set --shutter and --gain explicitly.
```

### Q: When should I use HCG instead of Normal SDR?

**A**: Use **HCG** (`hcg_enable=1`) for dark / low-light scenes — the high conversion gain lowers read
noise, improving shadow detail and SNR. Stay on **Normal LCG** (`hcg_enable=0`) for bright scenes,
where the larger full-well preserves highlight headroom. HCG also raises the minimum analogue gain,
so very bright scenes may clip earlier. HCG is a single-frame SDR mode (not HDR) and only takes effect
while `wide_dynamic_range=0`.

### Q: How to choose between 12-bit and 16-bit?

**A**:
- **12-bit (Mode 2)**: Real-time applications, video streaming, quick capture
- **16-bit (Mode 3)**: High-quality stills, maximum dynamic range, post-processing flexibility

### Q: Must I specify a tuning file for mono cameras?

**A**: Yes. Mono cameras require the `_mono` variant, otherwise the ISP applies Bayer demosaicing and produces artifacts.

### Q: What is the ClearHDR dynamic range?

**A**:
- 12-bit mode: ~90-100 dB (depends on HDR compression parameters)
- 16-bit mode: ~120+ dB (theoretical max, limited by sensor noise floor)

### Q: How to find the sensor subdevice?

**A**: Run `v4l2-ctl --list-devices` and look for `imx585`. Typically `/dev/v4l-subdev2`.

### Q: Merge tool reports "not ClearHDR RAW16 data"?

**A**:
- Ensure 16-bit format was set via `media-ctl`
- Confirm ClearHDR was enabled: `v4l2-ctl -d /dev/v4l-subdev2 --get-ctrl wide_dynamic_range`
- Confirm the `.dng` file was generated (`--raw` flag)

---

## File List

```
imx585-clearhdr/
├── driver-binary/             # Pre-built driver
│   ├── imx585.ko              # Driver module
│   ├── install.sh             # Install script
│   └── README.txt             # Kernel version info
├── tools/                     # Utilities
│   └── clearhdr_merge.py      # 16-bit HDR merge tool
├── tuning/                    # Tuning files
│   ├── imx585.json            # Color SDR
│   ├── imx585_mono.json       # Mono SDR
│   ├── imx585_hdr.json        # Color ClearHDR
│   └── imx585_mono_hdr.json   # Mono ClearHDR
├── README.md                  # Quick start
└── USAGE.md                   # This document
```

### Dependencies

Runtime:
```bash
# For merge tool
pip install rawpy numpy tifffile pillow --break-system-packages

# Or system packages
sudo apt install python3-numpy python3-pil
```

---

**Version**: 1.2.0
**Date**: 2026-06-27
