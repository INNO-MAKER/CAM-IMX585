#!/bin/bash
# IMX585 ClearHDR Driver Binary Installation Script
# For Raspberry Pi 5 with kernel 6.12.47+rpt-rpi-2712

set -e

KERNEL_VER=$(uname -r)
TARGET_KERNEL="6.12.47+rpt-rpi-2712"

echo "=== IMX585 ClearHDR Driver Installer ==="
echo "Current kernel: $KERNEL_VER"
echo "Target kernel:  $TARGET_KERNEL"
echo ""

if [ "$KERNEL_VER" != "$TARGET_KERNEL" ]; then
    echo "WARNING: Kernel version mismatch!"
    echo "This driver was compiled for $TARGET_KERNEL"
    echo "Your kernel is $KERNEL_VER"
    echo ""
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 1
    fi
fi

echo "Installing driver module..."
sudo cp imx585.ko /lib/modules/$KERNEL_VER/kernel/drivers/media/i2c/
sudo depmod -a

echo "Installing tuning files..."
sudo mkdir -p /usr/local/share/libcamera/ipa/rpi/pisp
sudo cp ../tuning/imx585.json /usr/local/share/libcamera/ipa/rpi/pisp/
sudo cp ../tuning/imx585_mono.json /usr/local/share/libcamera/ipa/rpi/pisp/
sudo cp ../tuning/imx585_hdr.json /usr/local/share/libcamera/ipa/rpi/pisp/
sudo cp ../tuning/imx585_mono_hdr.json /usr/local/share/libcamera/ipa/rpi/pisp/

echo "Installing merge tool..."
sudo cp ../tools/clearhdr_merge.py /usr/local/bin/
sudo chmod +x /usr/local/bin/clearhdr_merge.py

# --- Device Tree overlay (config.txt) ---
CONFIG_TXT=/boot/firmware/config.txt
[ -f "$CONFIG_TXT" ] || CONFIG_TXT=/boot/config.txt

echo ""
echo "=== Device Tree overlay (config.txt) ==="
echo "Using: $CONFIG_TXT"
if grep -qE '^[[:space:]]*dtoverlay=imx585' "$CONFIG_TXT" 2>/dev/null; then
    echo "Found an existing imx585 overlay line:"
    grep -nE '^[[:space:]]*dtoverlay=imx585' "$CONFIG_TXT"
    echo "No change needed. (For a mono camera the line must include ',mono'.)"
else
    echo "No 'dtoverlay=imx585' line was found."
    echo "The driver will NOT bind until the overlay is enabled. Required lines:"
    echo ""
    echo "    camera_auto_detect=0"
    echo "    dtoverlay=imx585,cam0          # add ',mono' for a mono camera"
    echo ""
    read -p "Append these lines to $CONFIG_TXT now? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        BACKUP="${CONFIG_TXT}.imx585.bak.$(date +%Y%m%d%H%M%S)"
        sudo cp "$CONFIG_TXT" "$BACKUP"
        echo "Backed up current config to: $BACKUP"
        # Disable any active autodetect so it does not collide with the manual overlay.
        sudo sed -i 's/^[[:space:]]*camera_auto_detect=1/#&  # disabled by imx585 installer/' "$CONFIG_TXT"
        printf '\n# IMX585 ClearHDR driver\ncamera_auto_detect=0\ndtoverlay=imx585,cam0\n' | sudo tee -a "$CONFIG_TXT" >/dev/null
        echo "Appended overlay lines. Edit $CONFIG_TXT to add ',mono' if you use a mono camera."
    else
        echo "Skipped. Add the lines above to $CONFIG_TXT manually before rebooting."
    fi
fi

echo ""
echo "Installation complete!"
echo ""
echo "Next steps:"
echo "  1. Make sure $CONFIG_TXT has the 'dtoverlay=imx585' line (see above)"
echo "  2. Reboot the system: sudo reboot"
echo "  3. Verify driver loaded: dmesg | grep imx585"
echo "  4. See ../USAGE.md for mode switching (Normal / HCG / ClearHDR) and capture examples"
