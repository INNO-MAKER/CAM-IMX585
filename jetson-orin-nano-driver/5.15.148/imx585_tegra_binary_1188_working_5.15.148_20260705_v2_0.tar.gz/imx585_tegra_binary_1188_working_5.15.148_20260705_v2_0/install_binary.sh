#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULE_DIR="/lib/modules/$(uname -r)/kernel/drivers/media/i2c"
CAM0_DTBO_NAME="tegra234-p3767-camera-p3768-imx585-cam0.dtbo"
CAM1_DTBO_NAME="tegra234-p3767-camera-p3768-imx585-cam1.dtbo"
DUAL_DTBO_NAME="tegra234-p3767-camera-p3768-imx585-dual.dtbo"
ISP_NAME="camera_overrides.imx585_starter.isp"
ISP_SRC="${PACKAGE_DIR}/isp/${ISP_NAME}"
ISP_SETTINGS_DIR="/var/nvidia/nvcam/settings"
ISP_DST="${ISP_SETTINGS_DIR}/camera_overrides.isp"
ISP_BACKUP_DIR="${ISP_SETTINGS_DIR}/backup_imx585_isp"

for f in \
	"${PACKAGE_DIR}/binary/imx585.ko" \
	"${PACKAGE_DIR}/overlays/${CAM0_DTBO_NAME}" \
	"${PACKAGE_DIR}/overlays/${CAM1_DTBO_NAME}" \
	"${PACKAGE_DIR}/overlays/${DUAL_DTBO_NAME}" \
	"${ISP_SRC}"; do
	if [ ! -f "$f" ]; then
		echo "ERROR: missing $f" >&2
		exit 1
	fi
done

install_starter_isp() {
	local stamp backup_file

	echo "Installing IMX585 starter ISP override"
	sudo mkdir -p "$ISP_SETTINGS_DIR" "$ISP_BACKUP_DIR"

	if [ -f "$ISP_DST" ] && ! cmp -s "$ISP_SRC" "$ISP_DST"; then
		stamp="$(date +%Y%m%d_%H%M%S)"
		backup_file="${ISP_BACKUP_DIR}/camera_overrides.isp.${stamp}.bak"
		sudo cp "$ISP_DST" "$backup_file"
		echo "Backed up existing ISP override to: ${backup_file}"
	fi

	sudo install -m 0644 "$ISP_SRC" "$ISP_DST"
	sudo install -m 0644 "$ISP_SRC" "${ISP_SETTINGS_DIR}/${ISP_NAME}"
}

cleanup_stale_imx585() {
	# Remove leftover imx585 artifacts from previous installs BEFORE writing the
	# fresh ones, so an old overlay/module can't shadow this package:
	#   * jetson-io scans /boot and a stale differently-named dtbo could be picked;
	#   * old .ko / .dtbo backup copies (imx585.ko.before_*, ...cam1.dtbo.before_*)
	#     from ad-hoc swaps clutter the tree and confuse diagnosis.
	# The three canonical dtbos and imx585.ko are reinstalled right after this,
	# so only stale/backup and non-canonical copies are actually deleted.
	local kdir="${MODULE_DIR}"
	local keep=" ${CAM0_DTBO_NAME} ${CAM1_DTBO_NAME} ${DUAL_DTBO_NAME} "
	local f base

	echo "Cleaning up stale imx585 artifacts from previous installs..."

	# Backup/variant copies of the module (imx585.ko.before_*, imx585.ko.bak, ...).
	# The live imx585.ko is left in place; it is overwritten by the install below.
	for f in "${kdir}"/imx585.ko.*; do
		[ -e "$f" ] || continue
		echo "  removing stale module copy: $f"
		sudo rm -f "$f"
	done

	# imx585 overlays in /boot: delete backup/variant suffixes and any non-canonical
	# old name. The canonical three are overwritten by the install below.
	for f in /boot/*imx585*.dtbo /boot/*imx585*.dtbo.*; do
		[ -e "$f" ] || continue
		base="$(basename "$f")"
		case "${keep}" in
			*" ${base} "*) continue ;;   # canonical .dtbo: keep, will be overwritten
		esac
		echo "  removing stale overlay: $f"
		sudo rm -f "$f"
	done
}

reload_imx585_module() {
	echo "Reloading imx585 kernel module"
	sudo systemctl stop nvargus-daemon || true

	if lsmod | awk '{print $1}' | grep -qx imx585; then
		if ! sudo modprobe -r imx585; then
			echo "WARNING: failed to unload imx585. Stop active camera users or reboot before testing the newly installed module." >&2
			sudo systemctl restart nvargus-daemon || true
			return 0
		fi
	fi

	if ! sudo modprobe imx585; then
		echo "WARNING: failed to load imx585. Reboot or run 'sudo modprobe imx585' after checking dmesg." >&2
		sudo systemctl restart nvargus-daemon || true
		return 0
	fi

	sudo systemctl restart nvargus-daemon || true
}

echo "Installing IMX585 binary driver package"
echo "Kernel: $(uname -r)"

cleanup_stale_imx585

sudo install -D -m 0644 "${PACKAGE_DIR}/binary/imx585.ko" "${MODULE_DIR}/imx585.ko"
sudo depmod -a

for name in "$CAM0_DTBO_NAME" "$CAM1_DTBO_NAME" "$DUAL_DTBO_NAME"; do
	sudo install -D -m 0644 "${PACKAGE_DIR}/overlays/${name}" "/boot/${name}"
done

# Auto-stamp the live CSI header name into each installed overlay so jetson-io
# lists it regardless of the BSP's header convention (24pin vs 22pin). The
# shipped value then never matters. See the dtbo-handling skill.
echo "Stamping jetson-header-name into installed overlays..."
HDR_NAME="$(sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l 2>/dev/null \
            | grep -oE 'Jetson [0-9]+pin CSI Connector' | head -1 || true)"
if [ -n "${HDR_NAME}" ]; then
	for name in "$CAM0_DTBO_NAME" "$CAM1_DTBO_NAME" "$DUAL_DTBO_NAME"; do
		sudo fdtput -t s "/boot/${name}" / jetson-header-name "${HDR_NAME}"
	done
	echo "  jetson-header-name set to: ${HDR_NAME}"
else
	echo "  WARNING: could not detect CSI header name; overlays keep their shipped value." >&2
fi

install_starter_isp
reload_imx585_module

echo "Configuring module autoload..."
MODULES_LOAD_DIR="/etc/modules-load.d"
MODPROBE_DIR="/etc/modprobe.d"
IMX585_MODULES_CONF="${MODULES_LOAD_DIR}/imx585.conf"
IMX585_MODPROBE_CONF="${MODPROBE_DIR}/imx585.conf"

sudo mkdir -p "${MODULES_LOAD_DIR}" "${MODPROBE_DIR}"

sudo tee "${IMX585_MODULES_CONF}" > /dev/null <<'EOF'
# Load IMX585 camera driver at boot
# Note: imx585 should load automatically via device tree when the dtbo is active.
# This is a fallback configuration in case device tree autoloading fails.
imx585
EOF

sudo tee "${IMX585_MODPROBE_CONF}" > /dev/null <<'EOF'
# IMX585 camera driver options
# Add options here if needed, e.g.:
# options imx585 debug=1
EOF

echo "Module autoload configured: ${IMX585_MODULES_CONF}"
echo

# Install imx585-reload.service to auto-load ClearHDR at boot (v1.4)
echo "Installing imx585-reload.service (auto-loads ClearHDR 12bit at boot)..."
RELOAD_SCRIPT="${PACKAGE_DIR}/scripts/install_imx585_reload_service.sh"
if [ -x "$RELOAD_SCRIPT" ]; then
    sudo "$RELOAD_SCRIPT"
else
    echo "WARNING: ${RELOAD_SCRIPT} not found or not executable"
    echo "         You may need to manually install the reload service"
fi
echo

echo "Installed:"
echo "  ${MODULE_DIR}/imx585.ko"
echo "  /boot/${CAM0_DTBO_NAME}"
echo "  /boot/${CAM1_DTBO_NAME}"
echo "  /boot/${DUAL_DTBO_NAME}"
echo "  ${ISP_DST}"
echo "  /etc/systemd/system/imx585-reload.service (enabled)"
echo
echo "The installer reloaded imx585 and restarted nvargus-daemon for immediate testing."
echo
echo "To activate the camera overlay at boot, use NVIDIA jetson-io (do NOT hand-edit extlinux):"
echo "  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l        # list available overlays"
echo "  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX585 CAM1'"
echo "  sudo reboot"
echo "Header 2 is the CSI connector. Pick one of:"
echo "    'Camera IMX585 CAM0' | 'Camera IMX585 CAM1' | 'Dual Camera IMX585 CAM0 CAM1'"
echo "Interactive equivalent: sudo /opt/nvidia/jetson-io/jetson-io.py"
echo "This script does not reboot the system."
