#!/usr/bin/env bash
# Install IMX585 reload service to fix boot initialization issue

set -euo pipefail

SERVICE_FILE="imx585-reload.service"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVICE_DST="/etc/systemd/system/${SERVICE_FILE}"

# The .service file may sit next to this script (scripts/) or at the package
# root (one level up), depending on the package layout. Search both.
SERVICE_SRC=""
for cand in "${HERE}/${SERVICE_FILE}" "${HERE}/../${SERVICE_FILE}"; do
    if [ -f "$cand" ]; then
        SERVICE_SRC="$cand"
        break
    fi
done

if [ -z "$SERVICE_SRC" ]; then
    echo "ERROR: ${SERVICE_FILE} not found (looked in ${HERE} and ${HERE}/..)" >&2
    exit 1
fi

echo "Installing IMX585 reload service..."
sudo install -m 0644 "$SERVICE_SRC" "$SERVICE_DST"

echo "Enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable imx585-reload.service

echo ""
echo "Service installed and enabled."
echo "This service will reload imx585 module after boot to ensure proper initialization."
echo ""
echo "To test: sudo systemctl start imx585-reload.service"
echo "To check status: sudo systemctl status imx585-reload.service"
echo ""
echo "Reboot to verify automatic fix."
