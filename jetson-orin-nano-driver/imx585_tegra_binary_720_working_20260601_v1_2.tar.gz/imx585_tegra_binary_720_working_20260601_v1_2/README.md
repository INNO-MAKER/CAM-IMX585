# IMX585 Tegra Binary Package - 720 Mbps Working State v1.2

Build date: 2026-06-01
Kernel ABI validated: 5.15.148-tegra

This package contains a prebuilt IMX585 kernel module, CAM0/CAM1/dual DTBO files, the validated starter ISP override, and runtime usage scripts for the validated 2-lane 720 Mbps/lane state.

V4L2 RAW/MONO works without ISP. Argus preview/JPEG color was validated with `camera_overrides.imx585_starter.isp`. Testing with no active `camera_overrides.isp` produced a purple color cast on this setup.

Included binaries:

- `binary/imx585.ko`
- `overlays/tegra234-p3767-camera-p3768-imx585-cam0.dtbo`
- `overlays/tegra234-p3767-camera-p3768-imx585-cam1.dtbo`
- `overlays/tegra234-p3767-camera-p3768-imx585-dual.dtbo`
- `isp/camera_overrides.imx585_starter.isp`
- `isp_source/camera_overrides.imx585_starter.isp`

Validated state:

- CAM1, 2 lanes, `serial_c`, `/dev/video0`
- `cil_settletime=30`
- `line_length=2640`
- `pix_clk_hz=74250000`
- `max_framerate=12500000`
- `IMX585_EMBEDDED_DATA` (`0x303a`) kept at `0x03`
- `binary/imx585.ko` md5: `fe374cabdce825f5795a308d2e29b89b`

Install:

```bash
cd imx585_tegra_binary_720_working_20260601_v1_2
sudo ./install_binary.sh
```

The install script installs `imx585.ko`, runs `depmod -a`, copies all three DTBO files to `/boot`, installs the validated starter ISP to `/var/nvidia/nvcam/settings/camera_overrides.isp`, configures module autoload via `/etc/modules-load.d/imx585.conf`, reloads the `imx585` kernel module, and restarts `nvargus-daemon`. It does not reboot the system.

Reinstall only the validated starter ISP:

```bash
sudo ./scripts/install_starter_isp.sh
```

Overlay activation:

```bash
sudo ./scripts/configure_extlinux_overlay.sh
```

Changing an active DTBO requires a reboot before runtime device tree changes. The scripts do not reboot automatically.

Usage examples:

```bash
./scripts/capture_mono_image.sh 1080p /tmp/imx585_mono.png
./scripts/preview_mono.sh 1080p
./scripts/capture_v4l2_image.sh 1080p /tmp/imx585_1080p.png
./scripts/capture_argus_image.sh 1080p /tmp/imx585_1080p.jpg
./scripts/preview_argus.sh 1080p
./scripts/soak_argus_stream.sh 1080p 30
```

Notes:

- This binary package is intended for the same Jetson/L4T kernel ABI it was built on: `5.15.148-tegra`.
- v1.2 keeps only the validated starter ISP in the default package.
- Diagnostic and R/B swap ISP experiments were removed from this release package.
- Future ISP tuning should start from `isp_source/camera_overrides.imx585_starter.isp` and then sync the edited result to `isp/camera_overrides.imx585_starter.isp`.
- The installer reloads `imx585.ko` after installation so the new module and a clean sensor runtime state are used immediately. If unload fails because a camera process is active, stop the process or reboot before testing.
- V4L2 image conversion defaults to `SHIFT_RIGHT=4` and `AUTO_LEVELS=1` for Tegra `RG12` frames.
- `preview_mono.sh` uses V4L2 + OpenCV software display and does not use Argus or ISP. Use `HEADLESS=1 FRAMES=30 ./scripts/preview_mono.sh 1080p 0` for a no-window smoke test.
- Default Argus framerate is `25/2`.
