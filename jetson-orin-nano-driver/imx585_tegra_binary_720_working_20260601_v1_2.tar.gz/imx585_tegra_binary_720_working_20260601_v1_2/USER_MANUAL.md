# IMX585 Tegra Binary Package - User Manual

Version: v1.2  
Date: 2026-06-01  
Kernel: 5.15.148-tegra (Jetson Orin Nano)

## Overview

This package provides a prebuilt IMX585 camera driver for NVIDIA Jetson Orin Nano, validated at 720 Mbps/lane on 2-lane MIPI CSI-2. It includes the kernel module, device tree overlays, ISP configuration, and usage scripts.

**Validated Configuration:**
- 2-lane MIPI CSI-2 @ 720 Mbps/lane
- CAM1 connector (serial_c, i2c@1)
- Device: /dev/video0
- Resolutions: 1080p (1920×1080) and 4K (3840×2160)
- Frame rate: up to 18 fps (1188 Mbps mode)
- Color output via Argus ISP

## Package Contents

```
imx585_tegra_binary_720_working_20260601_v1_2/
├── README.md                          # Technical details
├── USER_MANUAL.md                     # This file
├── install_binary.sh                  # Main installation script
├── imx585-reload.service              # Boot initialization service
├── binary/
│   └── imx585.ko                      # Prebuilt kernel module
├── overlays/
│   ├── tegra234-p3767-camera-p3768-imx585-cam0.dtbo
│   ├── tegra234-p3767-camera-p3768-imx585-cam1.dtbo
│   └── tegra234-p3767-camera-p3768-imx585-dual.dtbo
├── isp/
│   └── camera_overrides.imx585_starter.isp
└── scripts/
    ├── install_imx585_reload_service.sh
    ├── install_starter_isp.sh
    ├── configure_extlinux_overlay.sh
    ├── preview_argus.sh               # Live color preview
    ├── preview_argus_mono.sh          # Live preview for MONO IMX585 (grayscale pipeline)
    ├── capture_argus_image.sh         # Capture JPEG image
    ├── capture_argus_video.sh         # Record video
    ├── capture_v4l2_image.sh          # Capture RAW image
    ├── soak_argus_stream.sh           # Stress test
    └── check_argus_imx585.sh          # Quick verification
```

## Installation

### Prerequisites

- NVIDIA Jetson Orin Nano with L4T R36.4.4
- Kernel 5.15.148-tegra
- IMX585 camera connected to CAM1 connector
- sudo access

### Step 1: Install Driver

```bash
cd imx585_tegra_binary_720_working_20260601_v1_2
sudo ./install_binary.sh
```

The installer will:
1. Install kernel module to `/lib/modules/$(uname -r)/kernel/drivers/media/i2c/`
2. Install device tree overlays to `/boot/`
3. Install ISP configuration to `/var/nvidia/nvcam/settings/`
4. Configure module autoload
5. Install boot initialization service
6. Reload module and restart nvargus-daemon

### Step 2: Configure Device Tree Overlay

```bash
sudo ./scripts/configure_extlinux_overlay.sh
```

Select the overlay for your camera configuration:
- **CAM0**: Camera on CAM0 connector
- **CAM1**: Camera on CAM1 connector (recommended)
- **Dual**: Cameras on both CAM0 and CAM1

### Step 3: Reboot

```bash
sudo reboot
```

After reboot, the driver will automatically load and initialize.

## Verification

Check that the camera is detected:

```bash
# Check kernel module
lsmod | grep imx585

# Check video device
v4l2-ctl --list-devices

# Quick Argus test
cd scripts
./check_argus_imx585.sh
```

Expected output:
```
NVIDIA Tegra Video Input Device (platform:tegra-camrtc-ca):
	/dev/media0

vi-output, imx585 9-001a (platform:tegra-capture-vi:2):
	/dev/video0
```

## Usage Examples

### Live Preview

```bash
cd scripts

# 1080p preview (color sensor)
./preview_argus.sh 1080p

# 4K preview (color sensor)
./preview_argus.sh 4k

# Live preview for MONO version IMX585 (forces grayscale,
# neutralizes Argus AWB/CCM pink cast on no-Bayer sensors)
./preview_argus_mono.sh 1080p
./preview_argus_mono.sh 4k
```

Press `q` or `Ctrl+C` to stop.

### Capture Images

```bash
# Capture JPEG (1080p)
./capture_argus_image.sh 1080p /tmp/imx585_photo.jpg

# Capture JPEG (4K)
./capture_argus_image.sh 4k /tmp/imx585_4k.jpg

# Capture RAW (for analysis)
./capture_v4l2_image.sh 1080p /tmp/imx585_raw.png
```

### Record Video

```bash
# Record 30 seconds at 1080p
./capture_argus_video.sh 1080p /tmp/imx585_video.mp4 30

# Record 10 seconds at 4K
./capture_argus_video.sh 4k /tmp/imx585_4k.mp4 10
```

### Stress Test

```bash
# Stream for 60 seconds
./soak_argus_stream.sh 1080p 60
```

## Camera Controls

Adjust exposure, gain, and frame rate using environment variables:

```bash
# Custom exposure (microseconds, range: 2-39000)
EXPOSURE=20000 ./preview_argus.sh 1080p

# Custom gain (range: 0-240)
GAIN=10 ./preview_argus.sh 1080p

# Custom frame rate (micro-fps)
FRAME_RATE=18000000 ./preview_argus.sh 1080p  # 18 fps

# Combine multiple settings
EXPOSURE=15000 GAIN=5 ./capture_argus_image.sh 1080p /tmp/custom.jpg
```

## Troubleshooting

### Camera not detected after reboot

**Symptom:** `/dev/video0` missing or `v4l2-ctl --list-devices` shows no camera

**Solution:**
```bash
# Check if module loaded
lsmod | grep imx585

# If not loaded, load manually
sudo modprobe imx585

# Check dmesg for errors
sudo dmesg | grep -i imx585
```

### Preview shows corrupted/garbled image

**Symptom:** Preview window shows distorted colors or patterns

**Solution:** The boot initialization service should fix this automatically. If not:
```bash
# Manually reload module
sudo systemctl stop nvargus-daemon
sudo rmmod imx585
sudo modprobe imx585
sudo systemctl start nvargus-daemon

# Then try preview again
./scripts/preview_argus.sh 1080p
```

### "Connection refused" error

**Symptom:** `Connecting to nvargus-daemon failed: Connection refused`

**Solution:**
```bash
# Restart nvargus-daemon
sudo systemctl restart nvargus-daemon

# Check status
sudo systemctl status nvargus-daemon
```

### Device tree overlay not active

**Symptom:** Camera not detected even though module loads

**Solution:**
```bash
# Check extlinux.conf
grep OVERLAYS /boot/extlinux/extlinux.conf

# Should show:
# OVERLAYS /boot/...,/boot/tegra234-p3767-camera-p3768-imx585-cam1.dtbo

# If missing, run:
sudo ./scripts/configure_extlinux_overlay.sh
sudo reboot
```

## Uninstallation

To remove the driver:

```bash
# Stop and disable services
sudo systemctl stop imx585-reload.service
sudo systemctl disable imx585-reload.service
sudo rm /etc/systemd/system/imx585-reload.service
sudo systemctl daemon-reload

# Remove module
sudo rmmod imx585
sudo rm /lib/modules/$(uname -r)/kernel/drivers/media/i2c/imx585.ko
sudo depmod -a

# Remove overlays from extlinux.conf (manual edit)
sudo nano /boot/extlinux/extlinux.conf
# Remove the imx585 dtbo from OVERLAYS line

# Reboot
sudo reboot
```

## Technical Specifications

**Sensor:** Sony IMX585 (Color, RGGB Bayer)  
**Interface:** 2-lane MIPI CSI-2  
**Data Rate:** 720 Mbps/lane (validated), 1188 Mbps/lane (experimental)  
**Resolutions:**
- 4K: 3856×2180 (sensor), 3840×2160 (output)
- 1080p: 1928×1090 (sensor), 1920×1080 (output)

**Frame Rates:**
- 720 Mbps: up to 12.5 fps
- 1188 Mbps: up to 18 fps

**Pixel Format:** RG12 (12-bit Bayer)  
**ISP:** Argus with starter tuning profile

## Known Limitations

1. **Frame rate limited by link speed** - Maximum 18 fps at 1188 Mbps
2. **ISP tuning is basic** - Color accuracy not production-calibrated
3. **Single camera only** - Dual camera mode not fully tested
4. **No hardware trigger support** - Software trigger only

## Support

For issues or questions:
1. Check dmesg: `sudo dmesg | grep -i imx585`
2. Check nvargus logs: `sudo journalctl -u nvargus-daemon`
3. Verify installation: `./scripts/check_argus_imx585.sh`

## Version History

**v1.2 (2026-06-01)**
- Added boot initialization service for reliable startup
- Integrated ISP installation into main installer
- Integrated module autoload configuration
- Improved installation reliability

**v1.1 (2026-05-31)**
- Added ISP starter tuning profile
- Fixed color preview issues

**v1.0 (2026-05-30)**
- Initial release
- 720 Mbps validated configuration
