#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULE_DIR="/lib/modules/$(uname -r)/kernel/drivers/media/i2c"
CAM0_DTBO_NAME="tegra234-p3767-camera-p3768-imx585-cam0.dtbo"
CAM1_DTBO_NAME="tegra234-p3767-camera-p3768-imx585-cam1.dtbo"
DUAL_DTBO_NAME="tegra234-p3767-camera-p3768-imx585-dual.dtbo"
ISP_NAME="camera_overrides.imx585_starter.isp"
ISP_SRC="${PACKAGE_DIR}/isp/${ISP_NAME}"
ISP_SETTINGS_DIR="/var/nvidia/nvcam/settings"
ISP_DST="${ISP_SETTINGS_DIR}/camera_overrides.isp"
ISP_BACKUP_DIR="${ISP_SETTINGS_DIR}/backup_imx585_isp"

for f in \
	"${PACKAGE_DIR}/binary/imx585.ko" \
	"${PACKAGE_DIR}/overlays/${CAM0_DTBO_NAME}" \
	"${PACKAGE_DIR}/overlays/${CAM1_DTBO_NAME}" \
	"${PACKAGE_DIR}/overlays/${DUAL_DTBO_NAME}" \
	"${ISP_SRC}"; do
	if [ ! -f "$f" ]; then
		echo "ERROR: missing $f" >&2
		exit 1
	fi
done

install_starter_isp() {
	local stamp backup_file

	echo "Installing IMX585 starter ISP override"
	sudo mkdir -p "$ISP_SETTINGS_DIR" "$ISP_BACKUP_DIR"

	if [ -f "$ISP_DST" ] && ! cmp -s "$ISP_SRC" "$ISP_DST"; then
		stamp="$(date +%Y%m%d_%H%M%S)"
		backup_file="${ISP_BACKUP_DIR}/camera_overrides.isp.${stamp}.bak"
		sudo cp "$ISP_DST" "$backup_file"
		echo "Backed up existing ISP override to: ${backup_file}"
	fi

	sudo install -m 0644 "$ISP_SRC" "$ISP_DST"
	sudo install -m 0644 "$ISP_SRC" "${ISP_SETTINGS_DIR}/${ISP_NAME}"
}

reload_imx585_module() {
	echo "Reloading imx585 kernel module"
	sudo systemctl stop nvargus-daemon || true

	if lsmod | awk '{print $1}' | grep -qx imx585; then
		if ! sudo modprobe -r imx585; then
			echo "WARNING: failed to unload imx585. Stop active camera users or reboot before testing the newly installed module." >&2
			sudo systemctl restart nvargus-daemon || true
			return 0
		fi
	fi

	if ! sudo modprobe imx585; then
		echo "WARNING: failed to load imx585. Reboot or run 'sudo modprobe imx585' after checking dmesg." >&2
		sudo systemctl restart nvargus-daemon || true
		return 0
	fi

	sudo systemctl restart nvargus-daemon || true
}

echo "Installing IMX585 binary driver package"
echo "Kernel: $(uname -r)"

sudo install -D -m 0644 "${PACKAGE_DIR}/binary/imx585.ko" "${MODULE_DIR}/imx585.ko"
sudo depmod -a

for name in "$CAM0_DTBO_NAME" "$CAM1_DTBO_NAME" "$DUAL_DTBO_NAME"; do
	sudo install -D -m 0644 "${PACKAGE_DIR}/overlays/${name}" "/boot/${name}"
done

install_starter_isp
reload_imx585_module

echo "Configuring module autoload..."
MODULES_LOAD_DIR="/etc/modules-load.d"
MODPROBE_DIR="/etc/modprobe.d"
IMX585_MODULES_CONF="${MODULES_LOAD_DIR}/imx585.conf"
IMX585_MODPROBE_CONF="${MODPROBE_DIR}/imx585.conf"

sudo mkdir -p "${MODULES_LOAD_DIR}" "${MODPROBE_DIR}"

sudo tee "${IMX585_MODULES_CONF}" > /dev/null <<'EOF'
# Load IMX585 camera driver at boot
# Note: imx585 should load automatically via device tree when the dtbo is active.
# This is a fallback configuration in case device tree autoloading fails.
imx585
EOF

sudo tee "${IMX585_MODPROBE_CONF}" > /dev/null <<'EOF'
# IMX585 camera driver options
# Add options here if needed, e.g.:
# options imx585 debug=1
EOF

echo "Module autoload configured: ${IMX585_MODULES_CONF}"
echo
echo "Installed:"
echo "  ${MODULE_DIR}/imx585.ko"
echo "  /boot/${CAM0_DTBO_NAME}"
echo "  /boot/${CAM1_DTBO_NAME}"
echo "  /boot/${DUAL_DTBO_NAME}"
echo "  ${ISP_DST}"
echo
echo "The installer reloaded imx585 and restarted nvargus-daemon for immediate testing."
echo "If the DTBO overlay was not already active at boot, configure extlinux and reboot manually."
echo "This script does not reboot the system."
