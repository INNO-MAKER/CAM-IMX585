#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-1080p}"
OUT="${2:-/tmp/imx585_argus_${MODE}.jpg}"
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-25/2}"

case "${MODE}" in
	1080p|1920x1080)
		SENSOR_MODE=1
		OUT_W=1920
		OUT_H=1080
		;;
	2160p|4k|3840x2160)
		SENSOR_MODE=0
		OUT_W=3840
		OUT_H=2160
		;;
	native4k|full4k|3856x2180)
		SENSOR_MODE=0
		OUT_W=3856
		OUT_H=2180
		;;
	*)
		echo "Usage: $0 {1080p|1920x1080|2160p|4k|3840x2160|native4k|full4k|3856x2180} [output.jpg]" >&2
		exit 2
		;;
esac

case "${OUT##*.}" in
	jpg|jpeg) ;;
	*)
		echo "Only JPEG output is supported by this Argus helper: ${OUT}" >&2
		exit 2
		;;
esac

rm -f "${OUT}"

gst-launch-1.0 -e \
	nvarguscamerasrc sensor-id="${SENSOR_ID}" sensor-mode="${SENSOR_MODE}" num-buffers=1 \
	! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
	! nvjpegenc \
	! filesink location="${OUT}"

echo "Wrote ${OUT}"
