#!/bin/bash
# =============================================================================
# 包 1：IMX585 V4L2 驱动 本地编译安装脚本
# Package 1: IMX585 V4L2 Driver Local Build & Install Script
#
# 目标 / Target：Raspberry Pi 5，内核 6.12.y（Trixie / Bookworm 64-bit）
# 源码 / Source：will127534/imx585-v4l2-driver @ 6.12.y（已预先打包，无需访问 GitHub）
#                (Pre-packaged, no GitHub access required on Pi5)
#
# 用法 / Usage：
#   chmod +x install.sh
#   sudo ./install.sh
# =============================================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
section() { echo -e "\n${CYAN}==============================${NC}"; echo -e "${CYAN} $1${NC}"; echo -e "${CYAN}==============================${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRIVER_SRC="$SCRIPT_DIR/imx585-v4l2-driver"
KERNEL_VER=$(uname -r)
CONFIG_FILE="/boot/firmware/config.txt"
OVERLAY_DIR="/boot/firmware/overlays"

section "IMX585 V4L2 Driver Installer (Offline / Local Build)"
info "当前内核版本 / Kernel version: $KERNEL_VER"
info "驱动源码路径 / Driver source: $DRIVER_SRC"

[ "$(uname -m)" != "aarch64" ] && error "需要 64-bit ARM 系统 / Requires 64-bit ARM system (aarch64)"
[ ! -d "$DRIVER_SRC" ] && error "驱动源码目录不存在 / Driver source directory not found: $DRIVER_SRC"

# --- Step 1: 安装内核头文件 / Install kernel headers ---
section "Step 1/4: 安装内核头文件和编译工具 / Installing kernel headers and build tools"
sudo apt-get update -qq
info "尝试安装 / Trying to install: linux-headers-${KERNEL_VER}..."
if sudo apt-get install -y "linux-headers-${KERNEL_VER}" 2>/dev/null; then
    info "已安装 / Installed: linux-headers-${KERNEL_VER}"
else
    warn "精确版本头文件不可用，尝试备选方案 / Exact version not available, trying fallback: linux-headers-rpi-v8..."
    if sudo apt-get install -y linux-headers-rpi-v8 2>/dev/null; then
        info "已安装 / Installed: linux-headers-rpi-v8"
        # 创建符号链接 / Create symlink
        if [ ! -d "/lib/modules/${KERNEL_VER}/build" ]; then
            RPI_HDR=$(ls /usr/src/ | grep "linux-headers.*rpi" | sort | tail -1)
            [ -n "$RPI_HDR" ] && sudo ln -sf "/usr/src/$RPI_HDR" "/lib/modules/${KERNEL_VER}/build" && \
                info "已创建符号链接 / Symlink created: /lib/modules/${KERNEL_VER}/build -> /usr/src/$RPI_HDR"
        fi
    else
        error "无法安装内核头文件，请手动执行 / Cannot install kernel headers, run manually:\n  sudo apt install linux-headers-\$(uname -r)"
    fi
fi
sudo apt-get install -y make gcc device-tree-compiler 2>&1 | grep "Setting up" || true
info "编译工具安装完成 / Build tools ready"

# --- Step 2: 编译驱动 / Build driver ---
section "Step 2/4: 编译 imx585.ko / Building imx585.ko"
cd "$DRIVER_SRC"
make clean 2>/dev/null || true
make -j$(nproc) KDIR="/lib/modules/${KERNEL_VER}/build"
[ ! -f "imx585.ko" ] && error "编译失败，imx585.ko 未生成 / Build failed, imx585.ko not found"
info "编译成功 / Build successful: imx585.ko ($(du -h imx585.ko | cut -f1))"
info "模块信息 / Module info:"
modinfo imx585.ko 2>/dev/null | grep -E "^(vermagic|description)" | sed 's/^/    /' || true

# --- Step 3: 编译并安装设备树 / Build and install device tree overlay ---
section "Step 3/4: 编译并安装设备树覆盖文件 / Building and installing device tree overlay"
if [ -f "imx585-overlay.dts" ]; then
    dtc -@ -I dts -O dtb -o imx585.dtbo imx585-overlay.dts 2>/dev/null
    info "已编译 / Compiled: imx585.dtbo ($(du -h imx585.dtbo | cut -f1))"
    sudo cp imx585.dtbo "${OVERLAY_DIR}/imx585.dtbo"
    info "已安装 / Installed: ${OVERLAY_DIR}/imx585.dtbo"
else
    warn "未找到 imx585-overlay.dts，跳过设备树编译 / imx585-overlay.dts not found, skipping dtbo build"
fi

# 安装内核模块 / Install kernel module
sudo cp imx585.ko "/lib/modules/${KERNEL_VER}/kernel/drivers/media/i2c/"
sudo depmod -a
info "imx585.ko 已安装，depmod 已更新 / imx585.ko installed, depmod updated"

# --- Step 4: 更新 config.txt / Update config.txt ---
section "Step 4/4: 更新启动配置 / Updating /boot/firmware/config.txt"
if grep -q "^camera_auto_detect=1" "$CONFIG_FILE" 2>/dev/null; then
    sudo sed -i 's/^camera_auto_detect=1/camera_auto_detect=0/' "$CONFIG_FILE"
    info "已修改 / Modified: camera_auto_detect=1 -> camera_auto_detect=0"
elif ! grep -q "camera_auto_detect" "$CONFIG_FILE" 2>/dev/null; then
    echo "camera_auto_detect=0" | sudo tee -a "$CONFIG_FILE" > /dev/null
    info "已添加 / Added: camera_auto_detect=0"
else
    info "camera_auto_detect 已正确配置 / camera_auto_detect already configured"
fi

if grep -q "dtoverlay=imx585" "$CONFIG_FILE" 2>/dev/null; then
    warn "dtoverlay=imx585 已存在，跳过 / dtoverlay=imx585 already exists, skipping"
else
    printf "\n# IMX585 Camera\ndtoverlay=imx585\n" | sudo tee -a "$CONFIG_FILE" > /dev/null
    info "已添加 / Added: dtoverlay=imx585"
fi

info "当前相机配置 / Current camera config:"
grep -E "camera_auto_detect|dtoverlay=imx585" "$CONFIG_FILE" | sed 's/^/    /'

section "安装完成！/ Installation Complete!"
echo ""
echo -e "  ${GREEN}下一步 / Next Steps：${NC}"
echo "  1. 重启系统 / Reboot:               sudo reboot"
echo "  2. 验证驱动加载 / Verify driver:    dmesg | grep imx585"
echo "  3. 列出相机 / List cameras:         rpicam-hello --list-cameras"
echo ""
echo -e "  ${CYAN}dtoverlay 选项 / dtoverlay options（编辑 / edit $CONFIG_FILE）：${NC}"
echo "    dtoverlay=imx585           # 默认 / Default: CAM1, 彩色 / Color"
echo "    dtoverlay=imx585,cam0      # 使用 CAM0 接口 / Use CAM0 port"
echo "    dtoverlay=imx585,mono      # 单色传感器 / Mono sensor"
echo "    dtoverlay=imx585,cam0,mono # CAM0 + 单色 / CAM0 + Mono"
echo ""
echo -e "  ${YELLOW}注意 / Note：${NC}此包仅安装内核驱动 / This package installs the kernel driver only."
echo "  若 rpicam-hello 仍看不到相机，还需运行包 2 编译 libcamera。"
echo "  If rpicam-hello cannot detect the camera, run Package 2 to build libcamera."
echo ""
