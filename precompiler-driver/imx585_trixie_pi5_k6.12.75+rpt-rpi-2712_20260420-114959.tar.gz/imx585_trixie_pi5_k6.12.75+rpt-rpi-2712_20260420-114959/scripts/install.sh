#!/bin/bash
# imx585 bundle installer — copies binaries into place.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
TS="$(date +%Y%m%d-%H%M%S)"
HOST_REL="$(uname -r)"
LC_DIR="/usr/lib/aarch64-linux-gnu"

# Source manifest to get base_driver info
if [ -f "$ROOT/MANIFEST" ]; then
    . "$ROOT/MANIFEST"
else
    echo "WARN: MANIFEST not found, using defaults"
    base_driver="imx585.ko"
    base_driver_name="imx585"
fi

# Auto-detect which IPA .so is in this bundle (pi5=pisp, pi4=vc4)
IPA_PATH="$(ls "$ROOT"/libcamera/ipa_rpi_*.so 2>/dev/null | head -1)"
[ -n "$IPA_PATH" ] || { echo "ERROR: no ipa_rpi_*.so found in $ROOT/libcamera/"; exit 1; }
IPA_NAME="$(basename "$IPA_PATH")"
case "$IPA_NAME" in
    ipa_rpi_pisp.so) TUNE_SUBDIR="pisp" ;;
    ipa_rpi_vc4.so)  TUNE_SUBDIR="vc4" ;;
    *)               echo "ERROR: unexpected IPA name $IPA_NAME"; exit 1 ;;
esac
# Auto-detect tuning directory
TUNE_DIR=""
for _td in \
    /usr/local/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
    /usr/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
; do
    if [ -d "$_td" ]; then
        TUNE_DIR="$_td"
        break
    fi
done
[ -n "$TUNE_DIR" ] || TUNE_DIR="/usr/share/libcamera/ipa/rpi/${TUNE_SUBDIR}"

echo "Installing IMX585 ($IPA_NAME, kernel $HOST_REL, base driver: $base_driver)..."

# ─── 1. kernel driver ───────────────────────────────────────────────────────
DEST="/lib/modules/$HOST_REL/kernel/drivers/media/i2c"
mkdir -p "$DEST"

# Back up existing driver (handle both compressed and uncompressed)
for EXT in .ko.xz .ko.zst .ko; do
    if [ -f "$DEST/${base_driver_name}${EXT}" ]; then
        mv "$DEST/${base_driver_name}${EXT}" "$DEST/${base_driver_name}${EXT}.bak.$TS"
        echo "  backed up existing ${base_driver_name}${EXT}"
    fi
done

cp "$ROOT/driver/$base_driver" "$DEST/"
depmod -a
echo "  driver installed ($base_driver)"

# ─── 2. device tree overlay ─────────────────────────────────────────────────
cp "$ROOT/dts/imx585.dtbo" /boot/firmware/overlays/
echo "  dtbo installed"

# ─── 3. libcamera IPA ───────────────────────────────────────────────────────
# Auto-detect IPA install directory on target system
IPA_DEST=""
for _d in \
    /usr/local/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/local/lib/aarch64-linux-gnu/libcamera \
    /usr/lib/aarch64-linux-gnu/libcamera \
; do
    if [ -d "$_d" ] && ls "$_d"/ipa_rpi_*.so >/dev/null 2>&1; then
        IPA_DEST="$_d"
        break
    fi
done
[ -n "$IPA_DEST" ] || { echo "ERROR: cannot find libcamera IPA directory on target"; exit 1; }
[ -f "$IPA_DEST/$IPA_NAME" ] \
    && cp "$IPA_DEST/$IPA_NAME" "$IPA_DEST/${IPA_NAME}.bak.$TS"
cp "$ROOT/libcamera/$IPA_NAME" "$IPA_DEST/"
[ -f "$ROOT/libcamera/${IPA_NAME}.sign" ] \
    && cp "$ROOT/libcamera/${IPA_NAME}.sign" "$IPA_DEST/"
ldconfig
echo "  IPA installed to $IPA_DEST"

# ─── 4. tuning file ─────────────────────────────────────────────────────────
mkdir -p "$TUNE_DIR"
if [ -f "$ROOT/tuning/imx585.json" ]; then
    cp "$ROOT/tuning/imx585.json" "$TUNE_DIR/"
    echo "  tuning file installed (real imx585.json)"
else
    # Try fallback tuning files bundled with us
    FALLBACK_INSTALLED=0
    for FB in imx477.json imx462.json; do
        if [ -f "$ROOT/tuning/$FB" ]; then
            cp "$ROOT/tuning/$FB" "$TUNE_DIR/"
            [ -e "$TUNE_DIR/imx585.json" ] && rm -f "$TUNE_DIR/imx585.json"
            ln -sf "$FB" "$TUNE_DIR/imx585.json"
            echo "  tuning file: imx585.json -> $FB (symlink from bundled fallback)"
            FALLBACK_INSTALLED=1
            break
        fi
    done
    # Last resort: use whatever is already on the system
    if [ "$FALLBACK_INSTALLED" = "0" ]; then
        for FB in imx477.json imx462.json; do
            if [ -f "$TUNE_DIR/$FB" ]; then
                [ -e "$TUNE_DIR/imx585.json" ] && rm -f "$TUNE_DIR/imx585.json"
                ln -sf "$FB" "$TUNE_DIR/imx585.json"
                echo "  tuning file: imx585.json -> $FB (symlink to existing)"
                break
            fi
        done
    fi
fi

# ─── 5. config.txt ──────────────────────────────────────────────────────────
CFG=/boot/firmware/config.txt
cp "$CFG" "$CFG.bak.$TS"
sed -i '/^dtoverlay=imx585/d;/^camera_auto_detect/d' "$CFG"
{
    echo ""
    echo "# IMX585 (from bundle, installed $TS)"
    echo "camera_auto_detect=0"
    echo "dtoverlay=imx585,cam0"
} >> "$CFG"
echo "  config.txt updated"

echo ""
echo "All done. Reboot required:  sudo reboot"
echo "After reboot:                rpicam-hello --list-cameras"
