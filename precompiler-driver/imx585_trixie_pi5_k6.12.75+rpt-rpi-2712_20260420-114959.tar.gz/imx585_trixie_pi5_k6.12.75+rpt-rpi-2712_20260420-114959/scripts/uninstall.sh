#!/bin/bash
# imx585 bundle uninstaller — restores backups.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }

HOST_REL="$(uname -r)"
DEST="/lib/modules/$HOST_REL/kernel/drivers/media/i2c"
LC_DIR="/usr/lib/aarch64-linux-gnu/libcamera"

if grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null; then
    TUNE_DIR="/usr/share/libcamera/ipa/rpi/pisp"
else
    TUNE_DIR="/usr/share/libcamera/ipa/rpi/vc4"
fi

echo "=== IMX585 bundle uninstall ==="

# Restore driver backup (find the most recent .bak.*)
for DRV in imx585 imx477; do
    LATEST_BAK="$(ls -t "$DEST/${DRV}.ko"*.bak.* 2>/dev/null | head -1)"
    if [ -n "$LATEST_BAK" ]; then
        ORIG="${LATEST_BAK%.bak.*}"
        cp "$LATEST_BAK" "$ORIG"
        echo "  restored driver: $ORIG"
        depmod -a
        break
    fi
done

# Remove overlay
[ -f /boot/firmware/overlays/imx585.dtbo ] \
    && rm -f /boot/firmware/overlays/imx585.dtbo \
    && echo "  removed imx585.dtbo"

# Remove tuning symlink
[ -L "$TUNE_DIR/imx585.json" ] \
    && rm -f "$TUNE_DIR/imx585.json" \
    && echo "  removed imx585.json symlink"

# Restore config.txt backup
LATEST_CFG="$(ls -t /boot/firmware/config.txt.bak.* 2>/dev/null | head -1)"
if [ -n "$LATEST_CFG" ]; then
    cp "$LATEST_CFG" /boot/firmware/config.txt
    echo "  restored config.txt from $LATEST_CFG"
fi

echo ""
echo "Uninstall done. Reboot required:  sudo reboot"
