#!/bin/bash
# Auto-detect which IPA variant this host should have based on Pi model
if grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null; then
    IPA_NAME="ipa_rpi_pisp.so"; TUNE_SUBDIR="pisp"
else
    IPA_NAME="ipa_rpi_vc4.so";  TUNE_SUBDIR="vc4"
fi

# Auto-detect IPA location
IPA=""
for _d in \
    /usr/local/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa \
    /usr/lib/aarch64-linux-gnu/libcamera/ipa/rpi/${TUNE_SUBDIR} \
    /usr/local/lib/aarch64-linux-gnu/libcamera \
    /usr/lib/aarch64-linux-gnu/libcamera \
; do
    [ -f "$_d/$IPA_NAME" ] && IPA="$_d/$IPA_NAME" && break
done

# Auto-detect tuning location
T=""
for _td in \
    /usr/local/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
    /usr/share/libcamera/ipa/rpi/${TUNE_SUBDIR} \
; do
    [ -e "$_td/imx585.json" ] && T="$_td/imx585.json" && break
done

F=0

echo "=== IMX585 bundle verification ==="
echo ""

# IPA binary
if [ -n "$IPA" ] && [ -f "$IPA" ]; then
    echo "[PASS] $IPA"
    strings "$IPA" 2>/dev/null | grep -qi imx585 \
        && echo "[PASS] imx585 in $IPA_NAME" \
        || echo "[WARN] imx585 not in $IPA_NAME (OK if using fallback cam_helper)"
else
    echo "[FAIL] $IPA_NAME not found in any standard location"; F=1
fi

# Tuning
if [ -n "$T" ] && [ -e "$T" ]; then
    echo "[PASS] tuning $T"
    [ -L "$T" ] && echo "  NOTE: imx585.json is a symlink -> $(readlink "$T")"
else
    echo "[FAIL] imx585.json not found in any standard location"; F=1
fi

# Kernel driver — check both imx585.ko and imx477.ko (if imx585 was built on imx477 base)
DRIVER_FOUND=0
for DRV_NAME in imx585 imx477; do
    if modinfo "$DRV_NAME" 2>/dev/null | grep -qi imx585; then
        echo "[PASS] kernel driver $DRV_NAME advertises imx585"
        DRIVER_FOUND=1
        break
    fi
done
[ "$DRIVER_FOUND" = "1" ] || echo "[WARN] no kernel driver advertising imx585 found (did you reboot?)"

# Overlay
[ -f /boot/firmware/overlays/imx585.dtbo ] \
    && echo "[PASS] imx585.dtbo present" \
    || echo "[FAIL] imx585.dtbo missing"

# config.txt
grep -q "dtoverlay=imx585" /boot/firmware/config.txt 2>/dev/null \
    && echo "[PASS] config.txt has imx585 overlay" \
    || echo "[WARN] config.txt missing imx585 overlay entry"

echo ""
echo "--- camera enumeration ---"
rpicam-hello --list-cameras 2>&1 | head -30 || true

exit $F
