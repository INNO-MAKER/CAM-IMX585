# IMX662 libcamera + rpicam-apps Source Package

## Contents

- `libcamera/` - libcamera source with IMX662 support
  - IPA helper: `cam_helper_imx662.cpp`
  - Tuning files: `imx662.json` (for both vc4 and pisp)
- `rpicam-apps/` - Raspberry Pi camera applications
- `build.sh` - Compilation and installation script

## Prerequisites

1. Install pkg1-imx662-driver-source.tar.gz first
2. Reboot after driver installation
3. Ensure camera is detected: `dmesg | grep imx662`

## Installation

```bash
tar -xzf pkg2-imx662-libcamera-source.tar.gz
cd pkg2-imx662-libcamera-source
sudo ./build.sh
```

**Note**: Compilation takes 20-30 minutes on Raspberry Pi 5.

## What it does

1. Installs all required dependencies
2. Compiles libcamera with IMX662 IPA support
3. Installs libcamera to `/usr/local/lib` and `/usr/local/share`
4. Compiles and installs rpicam-apps

## IMX662 Tuning

The tuning file includes:
- `black_level: 3200` (default for IMX662)
- AGC, AWB, and other ISP parameters optimized for IMX662
- HDR and night mode support

## Testing

```bash
# List cameras
rpicam-hello --list-cameras

# Preview
rpicam-hello -t 0

# Capture image
rpicam-still -o test.jpg

# Record video
rpicam-vid -t 10000 -o test.h264
```
