#!/bin/bash
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Building and Installing libcamera + rpicam-apps (IMX585) ==="
echo ""

# 1. 安装依赖
echo "[1/4] Installing dependencies..."
apt-get update
apt-get install -y \
    meson ninja-build pkg-config \
    libgnutls28-dev openssl libyaml-dev \
    python3-yaml python3-ply python3-jinja2 \
    libboost-dev libgtest-dev \
    libudev-dev libdrm-dev \
    libexif-dev libjpeg-dev libtiff-dev libpng-dev \
    qtbase5-dev libqt5core5a libqt5gui5 libqt5widgets5 \
    libavcodec-dev libavdevice-dev libavformat-dev libswresample-dev \
    libx11-dev libepoxy-dev libegl-dev libgles-dev

# 2. 编译 libcamera
echo ""
echo "[2/4] Building libcamera..."
cd "$SCRIPT_DIR/libcamera"
meson setup build \
    --buildtype=release \
    -Dpipelines=rpi/vc4,rpi/pisp \
    -Dipas=rpi/vc4,rpi/pisp \
    -Dv4l2=true \
    -Dtest=false
ninja -C build

# 3. 安装 libcamera
echo ""
echo "[3/4] Installing libcamera..."
ninja -C build install
ldconfig

# 4. 编译并安装 rpicam-apps
echo ""
echo "[4/4] Building and installing rpicam-apps..."
cd "$SCRIPT_DIR/rpicam-apps"
meson setup build \
    -Denable_libav=enabled \
    -Denable_drm=enabled \
    -Denable_egl=enabled \
    -Denable_qt=enabled \
    -Denable_opencv=disabled \
    -Denable_tflite=disabled
meson compile -C build
meson install -C build

echo ""
echo "✓ Installation complete!"
echo ""
echo "Test with:"
echo "  rpicam-hello --list-cameras"
echo "  rpicam-hello -t 0"
echo "  rpicam-still -o test.jpg"
