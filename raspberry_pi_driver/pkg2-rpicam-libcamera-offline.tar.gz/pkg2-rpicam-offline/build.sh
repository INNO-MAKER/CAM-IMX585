#!/bin/bash
# =============================================================================
# 包 2：libcamera + rpicam-apps 离线编译安装脚本
# Package 2: libcamera + rpicam-apps Offline Build & Install Script
#
# 目标 / Target：Raspberry Pi 5，Trixie / Bookworm 64-bit
# 源码 / Source：will127534/libcamera + will127534/rpicam-apps
#               （已预先打包，无需访问 GitHub / Pre-packaged, no GitHub access required）
#
# 用法 / Usage：
#   chmod +x build.sh
#   ./build.sh          # 完整版 / Full build（含 Qt/EGL/libav）
#   ./build.sh --lite   # Lite 版（无 Qt/EGL/libav，适合无桌面系统 / headless system）
# =============================================================================

set -e

LITE_MODE=false
[[ "$1" == "--lite" ]] && LITE_MODE=true

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
section() { echo -e "\n${CYAN}======================================${NC}"; echo -e "${CYAN} $1${NC}"; echo -e "${CYAN}======================================${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIBCAMERA_SRC="$SCRIPT_DIR/libcamera-imx585"
RPICAM_SRC="$SCRIPT_DIR/rpicam-apps-imx585"

echo "============================================================"
echo "  包 2 / Package 2：libcamera + rpicam-apps 离线编译 / Offline Build"
echo "  IMX585 支持版本 / IMX585 Support（will127534 fork）"
if $LITE_MODE; then
    echo "  模式 / Mode: Lite（无 Qt/EGL/libav / No Qt/EGL/libav）"
else
    echo "  模式 / Mode: Full（含 Qt/EGL/libav / With Qt/EGL/libav）"
fi
echo "============================================================"

[ "$(uname -m)" != "aarch64" ] && error "需要 64-bit ARM 系统 / Requires 64-bit ARM system (aarch64)"
[ ! -d "$LIBCAMERA_SRC" ] && error "libcamera 源码不存在 / libcamera source not found: $LIBCAMERA_SRC"
[ ! -d "$RPICAM_SRC" ]    && error "rpicam-apps 源码不存在 / rpicam-apps source not found: $RPICAM_SRC"

info "libcamera 源码路径 / Source path: $LIBCAMERA_SRC"
info "rpicam-apps 源码路径 / Source path: $RPICAM_SRC"
info "libcamera 版本 / Commit: $(cd $LIBCAMERA_SRC && git log --oneline -1 2>/dev/null || echo 'unknown')"
info "rpicam-apps 版本 / Commit: $(cd $RPICAM_SRC && git log --oneline -1 2>/dev/null || echo 'unknown')"

# =============================================================================
section "Step 1/5: 安装编译依赖 / Installing build dependencies"
# =============================================================================
info "更新软件包列表 / Updating package list..."
sudo apt-get update -qq

info "安装核心依赖 / Installing core dependencies..."
sudo apt-get install -y \
    meson ninja-build cmake python3-yaml python3-ply python3-jinja2 \
    python3-dev pybind11-dev \
    libboost-dev libgnutls28-dev openssl libtiff5-dev \
    libdrm-dev libepoxy-dev libexif-dev libjpeg-dev libpng-dev \
    libavcodec-dev libavdevice-dev libavformat-dev libswresample-dev \
    libboost-program-options-dev \
    2>&1 | grep -E "^(Setting up|already)" | head -20

if ! $LITE_MODE; then
    info "安装 Qt 依赖（完整模式）/ Installing Qt dependencies (full mode)..."
    sudo apt-get install -y \
        qtbase5-dev libqt5core5a libqt5gui5 libqt5widgets5 \
        2>&1 | grep -E "^(Setting up|already)" | head -10 || \
    sudo apt-get install -y \
        libqt6widgets6 libqt6core6 libqt6opengl6 libqt6openglwidgets6 \
        2>&1 | grep -E "^(Setting up|already)" | head -10 || \
        warn "Qt 安装失败，将以 Lite 模式继续 / Qt install failed, continuing in Lite mode"
fi
info "依赖安装完成 / Dependencies installed"

# =============================================================================
section "Step 2/5: 移除系统自带 libcamera / Removing system libcamera to avoid conflicts"
# =============================================================================
sudo apt-get remove -y libcamera-dev libcamera0* rpicam-apps* 2>/dev/null || true
sudo ldconfig
info "系统 libcamera 已移除 / System libcamera removed"

# =============================================================================
section "Step 3/5: 编译 libcamera（含 IMX585 IPA）/ Building libcamera (with IMX585 IPA)"
# =============================================================================
cd "$LIBCAMERA_SRC"
info "配置 libcamera / Configuring libcamera (meson setup)..."

[ -d "build" ] && { warn "清理旧的 build 目录 / Cleaning old build directory..."; rm -rf build; }

meson setup build \
    --buildtype=release \
    -Dpipelines=rpi/vc4,rpi/pisp \
    -Dipas=rpi/vc4,rpi/pisp \
    -Dv4l2=enabled \
    -Dgstreamer=disabled \
    -Dtest=false \
    -Dlc-compliance=disabled \
    -Dcam=disabled \
    -Dqcam=disabled \
    -Ddocumentation=disabled \
    -Dpycamera=enabled \
    -Dwrap_mode=forcefallback \
    2>&1 | tail -10

info "编译 libcamera（约 10-20 分钟，请耐心等待）/ Building libcamera (approx. 10-20 min, please wait)..."
ninja -C build -j$(nproc)

info "安装 libcamera / Installing libcamera..."
sudo ninja -C build install
sudo ldconfig
info "libcamera 安装完成 / libcamera installation complete"

# =============================================================================
section "Step 4/5: 配置 picamera2 Python 路径 / Configuring picamera2 Python path"
# =============================================================================
PYTHON_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
SITE_PKG="/usr/local/lib/aarch64-linux-gnu/python${PYTHON_VER}/site-packages"
DIST_PKG="/usr/local/lib/python${PYTHON_VER}/dist-packages"
if [ -d "$SITE_PKG" ]; then
    echo "$SITE_PKG" | sudo tee "$DIST_PKG/local-libcamera.pth" > /dev/null
    info "已配置 picamera2 路径 / picamera2 path configured: $SITE_PKG"
else
    warn "未找到 site-packages 路径，picamera2 可能需要手动配置 / site-packages not found, picamera2 may need manual config"
fi

# =============================================================================
section "Step 5/5: 编译 rpicam-apps / Building rpicam-apps"
# =============================================================================
cd "$RPICAM_SRC"
info "配置 rpicam-apps / Configuring rpicam-apps (meson setup)..."

[ -d "build" ] && { warn "清理旧的 build 目录 / Cleaning old build directory..."; rm -rf build; }

if $LITE_MODE; then
    info "使用 Lite 模式配置 / Using Lite mode configuration..."
    meson setup build \
        -Denable_libav=disabled \
        -Denable_drm=enabled \
        -Denable_egl=disabled \
        -Denable_qt=disabled \
        -Denable_opencv=disabled \
        -Denable_tflite=disabled \
        2>&1 | tail -5
else
    info "使用完整模式配置 / Using Full mode configuration..."
    meson setup build \
        -Denable_libav=enabled \
        -Denable_drm=enabled \
        -Denable_egl=enabled \
        -Denable_qt=enabled \
        -Denable_opencv=disabled \
        -Denable_tflite=disabled \
        2>&1 | tail -5
fi

info "编译 rpicam-apps（约 5-10 分钟）/ Building rpicam-apps (approx. 5-10 min)..."
meson compile -C build -j$(nproc)

info "安装 rpicam-apps / Installing rpicam-apps..."
sudo meson install -C build
sudo ldconfig
info "rpicam-apps 安装完成 / rpicam-apps installation complete"

# =============================================================================
section "编译安装全部完成！/ Build & Installation Complete!"
# =============================================================================
echo ""
echo -e "  ${GREEN}下一步 / Next Steps：${NC}"
echo "  1. 确认驱动已加载 / Verify driver loaded:    dmesg | grep imx585"
echo "  2. 列出可用相机 / List available cameras:    rpicam-hello --list-cameras"
echo "  3. 拍摄测试图片 / Capture test image:        rpicam-still -r -o test.jpg -f -t 0"
echo "  4. 录制视频 / Record video:                  rpicam-vid -t 5000 -o test.h264"
echo ""
echo -e "  ${YELLOW}注意 / Note：${NC}"
echo "  如果相机仍不可见，请确认已完成包 1 的驱动安装并重启。"
echo "  If the camera is still not detected, ensure Package 1 driver is installed and reboot."
echo ""
