# imx585 driver + overlay

Exported from a running system. Kernel module and device-tree overlay only.

Kernel: **6.12.47+rpt-rpi-2712**    Variant: pi5
Built on: debian trixie (13)    Date: 20260720-092432

## Contents
- `driver/imx585.ko` -- vermagic `6.12.47+rpt-rpi-2712`
- `driver/imx585.dtbo`
- `install.sh`

## Install
```bash
sudo ./install.sh
sudo reboot
```

`install.sh` refuses to run on any kernel other than `6.12.47+rpt-rpi-2712`.
It does **not** modify `config.txt` -- manage the `dtoverlay=` line yourself.

Overlay params available: `2lane always-on cam0 ccmp link-frequency media-controller mono orientation rotation sync-mode `

## Scope
Kernel side only. libcamera/IPA is packaged separately; nothing here depends on
the target's libcamera version.
