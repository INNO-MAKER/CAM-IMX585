#!/bin/bash
# imx585 driver + overlay installer.
# Installs the kernel module and the device-tree overlay only.
# Does NOT modify config.txt and does NOT touch libcamera.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KERNEL_REL="$(uname -r)"; TS="$(date +%Y%m%d-%H%M%S)"
SENSOR="imx585"
OVERLAY_NAME="imx585"
OV_PARAMS="2lane always-on cam0 ccmp link-frequency media-controller mono orientation rotation sync-mode "

VM="$(modinfo -F vermagic "$SCRIPT_DIR/driver/$SENSOR.ko" 2>/dev/null | awk '{print $1}')"
[ "$VM" = "$KERNEL_REL" ] || {
    echo "ERROR: module was built for kernel '$VM' but this system runs '$KERNEL_REL'."
    echo "       Rebuild from source for this kernel."
    exit 1
}

echo "[1/2] Kernel module ($SENSOR)..."
DEST="/lib/modules/$KERNEL_REL/updates/dkms"
KDEST="/lib/modules/$KERNEL_REL/kernel/drivers/media/i2c"
mkdir -p "$DEST"
# Displace older copies in BOTH directories, .ko and .ko.xz -- a stale .ko.xz
# outranks a fresh .ko and would keep getting loaded instead.
for d in "$DEST" "$KDEST"; do
    [ -f "$d/$SENSOR.ko" ]    && mv "$d/$SENSOR.ko"    "$d/$SENSOR.ko.bak.$TS"
    [ -f "$d/$SENSOR.ko.xz" ] && mv "$d/$SENSOR.ko.xz" "$d/$SENSOR.ko.xz.bak.$TS"
done
cp "$SCRIPT_DIR/driver/$SENSOR.ko" "$DEST/"
depmod -a
LOADED="$(modinfo -F filename "$SENSOR" 2>/dev/null || true)"
case "$LOADED" in
    */updates/dkms/$SENSOR.ko) echo "      OK: will load $LOADED";;
    *) echo "      ERROR: modprobe would load '$LOADED' instead"; exit 1;;
esac

echo "[2/2] Device-tree overlay..."
OVDIR=/boot/firmware/overlays; [ -d "$OVDIR" ] || OVDIR=/boot/overlays
[ -f "$OVDIR/$OVERLAY_NAME.dtbo" ] && cp "$OVDIR/$OVERLAY_NAME.dtbo" "$OVDIR/$OVERLAY_NAME.dtbo.bak.$TS"
cp "$SCRIPT_DIR/driver/$OVERLAY_NAME.dtbo" "$OVDIR/"
echo "      OK: $OVDIR/$OVERLAY_NAME.dtbo"

echo ""
echo "Done. config.txt was NOT modified -- add or keep your own line, e.g.:"
echo "    dtoverlay=$OVERLAY_NAME,<params>"
[ -n "$OV_PARAMS" ] && echo "  available params: $OV_PARAMS"
echo ""
echo "A reboot is required for an overlay change to take effect."
