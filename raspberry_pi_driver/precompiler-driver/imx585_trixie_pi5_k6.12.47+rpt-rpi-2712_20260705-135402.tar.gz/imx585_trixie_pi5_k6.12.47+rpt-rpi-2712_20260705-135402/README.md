# IMX585 prebuilt bundle: imx585_trixie_pi5_k6.12.47+rpt-rpi-2712_20260705-135402

## Sensor info

- Sony IMX585, STARVIS 2 technology
- 1/1.2" format, 8.3MP (3856×2180)
- 2.9µm pixel pitch
- Color and mono variants available
- Excellent low-light performance

## Build environment

- Model:    Raspberry Pi 5 Model B Rev 1.1
- OS:       debian trixie (13)
- Kernel:   6.12.47+rpt-rpi-2712
- libcamera: libcamera.so.0.6 / libcamera-base.so.0.6
- Base driver: imx585.ko

For best results, install on systems with the same kernel release and
libcamera soname. If the kernel module's vermagic doesn't match, modprobe
will refuse to load the driver at boot (check `dmesg | grep imx585`
after reboot).

## Install

    tar -xzf imx585_trixie_pi5_k6.12.47+rpt-rpi-2712_20260705-135402.tar.gz
    cd imx585_trixie_pi5_k6.12.47+rpt-rpi-2712_20260705-135402
    sudo ./scripts/install.sh
    sudo reboot
    ./scripts/verify.sh

## Uninstall

    sudo ./scripts/uninstall.sh
    sudo reboot

## ClearHDR

This sensor supports ClearHDR (single-frame wide dynamic range). See
`UserManual.md` for the full feature guide, exposure notes, and controls.
Quick toggle with the bundled helper:

    ./clearhdr.sh on        # enable ClearHDR
    ./clearhdr.sh off       # back to normal SDR
    ./clearhdr.sh status    # current state + exposure/gain ranges
    ./clearhdr.sh preview   # enable ClearHDR and preview a known-good baseline

## Notes

- If no dedicated imx585.json tuning file was available at build time,
  the installer creates a symlink from a compatible sensor's tuning.
  For best image quality, a custom imx585.json should be created.
- IMX585 is a rolling shutter sensor. For applications requiring
  global shutter, consider IMX296 instead.
