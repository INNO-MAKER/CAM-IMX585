#!/usr/bin/env bash
#
# clearhdr.sh - toggle and preview IMX585 ClearHDR (wide_dynamic_range)
#
# Usage:
#   ./clearhdr.sh on        Enable ClearHDR (wide_dynamic_range=1)
#   ./clearhdr.sh off       Disable ClearHDR, back to normal SDR
#   ./clearhdr.sh status    Show current state and exposure/gain ranges
#   ./clearhdr.sh preview    Enable ClearHDR and preview with a known-good
#                            manual exposure baseline (--gain 80 --shutter 200)
#
# The script auto-detects the IMX585 sensor subdevice. Override with:
#   SUBDEV=/dev/v4l-subdevN ./clearhdr.sh <cmd>
#
# For mono cameras, pass the mono tuning file to preview:
#   TUNING=/usr/local/share/libcamera/ipa/rpi/pisp/imx585_mono.json ./clearhdr.sh preview

set -euo pipefail

CTRL="wide_dynamic_range"

find_subdev() {
	if [ -n "${SUBDEV:-}" ]; then
		echo "$SUBDEV"
		return 0
	fi
	local s
	for s in /dev/v4l-subdev*; do
		[ -e "$s" ] || continue
		if v4l2-ctl -d "$s" --list-ctrls 2>/dev/null | grep -q "$CTRL"; then
			echo "$s"
			return 0
		fi
	done
	return 1
}

require_subdev() {
	local dev
	if ! dev=$(find_subdev); then
		echo "ERROR: no IMX585 subdevice exposing '$CTRL' found." >&2
		echo "       Is the driver loaded and the sensor bound? Try: dmesg | grep imx585" >&2
		exit 1
	fi
	echo "$dev"
}

cmd_set() {
	local dev val
	dev=$(require_subdev)
	val="$1"
	v4l2-ctl -d "$dev" --set-ctrl "${CTRL}=${val}"
	echo "$dev : ${CTRL} = $(v4l2-ctl -d "$dev" --get-ctrl "$CTRL" | awk '{print $2}')"
}

cmd_status() {
	local dev
	dev=$(require_subdev)
	echo "Subdevice: $dev"
	v4l2-ctl -d "$dev" --get-ctrl "$CTRL"
	echo "--- exposure / gain ranges ---"
	v4l2-ctl -d "$dev" --list-ctrls 2>/dev/null | grep -E 'exposure|analogue_gain|wide_dynamic_range'
}

cmd_preview() {
	local dev args
	dev=$(require_subdev)
	v4l2-ctl -d "$dev" --set-ctrl "${CTRL}=1"
	echo "ClearHDR enabled on $dev. Starting preview (gain 80, shutter 200 us)..."
	args=(-t 0 --gain 80 --shutter 200 --awb auto)
	if [ -n "${TUNING:-}" ]; then
		args+=(--tuning-file "$TUNING")
	fi
	exec rpicam-hello "${args[@]}"
}

case "${1:-}" in
	on)      cmd_set 1 ;;
	off)     cmd_set 0 ;;
	status)  cmd_status ;;
	preview) cmd_preview ;;
	*)
		grep -E '^#( |$)' "$0" | sed -E 's/^# ?//' | sed -n '2,20p'
		exit 1
		;;
esac
