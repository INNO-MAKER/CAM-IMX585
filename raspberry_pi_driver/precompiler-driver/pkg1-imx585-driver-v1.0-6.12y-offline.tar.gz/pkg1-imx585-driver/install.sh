#!/bin/bash
# =============================================================================
# Package 1: IMX585 V4L2 Driver — Local Build & Install (upstream reference)
#
# Target : Raspberry Pi 5, kernel 6.12.y (Trixie / Bookworm 64-bit)
# Source : will127534/imx585-v4l2-driver @ 6.12.y (upstream as-is, no changes;
#          pre-packaged, no GitHub access required on the Pi)
#
# Usage  : chmod +x install.sh && sudo ./install.sh
# =============================================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
section() { echo -e "\n${CYAN}==============================${NC}"; echo -e "${CYAN} $1${NC}"; echo -e "${CYAN}==============================${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRIVER_SRC="$SCRIPT_DIR/imx585-v4l2-driver"
KERNEL_VER=$(uname -r)
CONFIG_FILE="/boot/firmware/config.txt"
OVERLAY_DIR="/boot/firmware/overlays"
TS="$(date +%Y%m%d-%H%M%S)"

section "IMX585 V4L2 Driver Installer (Upstream Reference / Local Build)"
info "Kernel version: $KERNEL_VER"
info "Driver source : $DRIVER_SRC"

[ "$(uname -m)" != "aarch64" ] && error "Requires a 64-bit ARM system (aarch64)"
[ ! -d "$DRIVER_SRC" ] && error "Driver source directory not found: $DRIVER_SRC"

# --- Step 1: Install kernel headers and build tools ---
section "Step 1/5: Installing kernel headers and build tools"
sudo apt-get update -qq
info "Trying to install: linux-headers-${KERNEL_VER} ..."
if sudo apt-get install -y "linux-headers-${KERNEL_VER}" 2>/dev/null; then
    info "Installed: linux-headers-${KERNEL_VER}"
else
    warn "Exact version not available, trying fallback: linux-headers-rpi-v8 ..."
    if sudo apt-get install -y linux-headers-rpi-v8 2>/dev/null; then
        info "Installed: linux-headers-rpi-v8"
        if [ ! -d "/lib/modules/${KERNEL_VER}/build" ]; then
            RPI_HDR=$(ls /usr/src/ | grep "linux-headers.*rpi" | sort | tail -1)
            [ -n "$RPI_HDR" ] && sudo ln -sf "/usr/src/$RPI_HDR" "/lib/modules/${KERNEL_VER}/build" && \
                info "Symlink created: /lib/modules/${KERNEL_VER}/build -> /usr/src/$RPI_HDR"
        fi
    else
        error "Cannot install kernel headers. Run manually: sudo apt install linux-headers-\$(uname -r)"
    fi
fi
sudo apt-get install -y make gcc device-tree-compiler 2>&1 | grep "Setting up" || true
info "Build tools ready"

# --- Step 2: Build the driver ---
section "Step 2/5: Building imx585.ko"
cd "$DRIVER_SRC"
make clean 2>/dev/null || true
make -j"$(nproc)" KDIR="/lib/modules/${KERNEL_VER}/build"
[ ! -f "imx585.ko" ] && error "Build failed, imx585.ko not found"
info "Build successful: imx585.ko ($(du -h imx585.ko | cut -f1))"
modinfo imx585.ko 2>/dev/null | grep -E "^(vermagic|description)" | sed 's/^/    /' || true

# --- Step 3: Clear stale modules that would shadow the new one ---
# Raspberry Pi module load priority (high -> low):
#   updates/dkms/*.ko.xz > updates/dkms/*.ko > kernel/.../*.ko.xz > kernel/.../*.ko
# A leftover compressed .ko.xz (or a previous DKMS build) is loaded INSTEAD of the
# freshly built .ko, making it look like the new driver had no effect. Move them all
# aside before depmod, and unload any running instance.
section "Step 3/5: Backing up stale imx585 modules"
sudo modprobe -r imx585 2>/dev/null && info "Unloaded the running imx585 module" || true
DKMS_DIR="/lib/modules/${KERNEL_VER}/updates/dkms"
KI2C_DIR="/lib/modules/${KERNEL_VER}/kernel/drivers/media/i2c"
for d in "$DKMS_DIR" "$KI2C_DIR"; do
    for f in "$d/imx585.ko" "$d/imx585.ko.xz"; do
        if [ -f "$f" ]; then
            sudo mv "$f" "${f}.bak.${TS}"
            warn "Backed up and moved aside: ${f} -> ${f}.bak.${TS}"
        fi
    done
done
# Drop any stale DKMS registration so a kernel update won't resurrect an old build.
sudo dkms remove -m imx585 --all 2>/dev/null || true

# --- Step 4: Install module + device tree overlay ---
section "Step 4/5: Installing module and device tree overlay"
sudo mkdir -p "$KI2C_DIR"
sudo cp imx585.ko "$KI2C_DIR/"
sudo depmod -a
info "Installed: $KI2C_DIR/imx585.ko"
# Confirm the loader now resolves to our .ko, not some leftover .ko.xz.
RESOLVED=$(modinfo -k "$KERNEL_VER" imx585 2>/dev/null | awk '/^filename:/{print $2}')
info "Resolved module path: ${RESOLVED:-<none>}"
case "$RESOLVED" in
    *.ko.xz) warn "Resolved to a .ko.xz — an old build may still load; check the module tree" ;;
esac

if [ -f "imx585-overlay.dts" ]; then
    dtc -@ -I dts -O dtb -o imx585.dtbo imx585-overlay.dts 2>/dev/null
    sudo cp imx585.dtbo "${OVERLAY_DIR}/imx585.dtbo"
    info "Overlay installed: ${OVERLAY_DIR}/imx585.dtbo"
else
    warn "imx585-overlay.dts not found, skipping dtbo build"
fi

# --- Step 5: Update config.txt ---
section "Step 5/5: Updating $CONFIG_FILE"
sudo cp "$CONFIG_FILE" "${CONFIG_FILE}.bak.${TS}" 2>/dev/null && info "Backed up config.txt" || true
if grep -q "^camera_auto_detect=1" "$CONFIG_FILE" 2>/dev/null; then
    sudo sed -i 's/^camera_auto_detect=1/camera_auto_detect=0/' "$CONFIG_FILE"
    info "Modified: camera_auto_detect=1 -> 0"
elif ! grep -q "camera_auto_detect" "$CONFIG_FILE" 2>/dev/null; then
    echo "camera_auto_detect=0" | sudo tee -a "$CONFIG_FILE" > /dev/null
    info "Added: camera_auto_detect=0"
else
    info "camera_auto_detect already configured"
fi
if grep -q "^dtoverlay=imx585" "$CONFIG_FILE" 2>/dev/null; then
    warn "dtoverlay=imx585 already present, left as-is:"
    grep -nE "^dtoverlay=imx585" "$CONFIG_FILE" | sed 's/^/    /'
else
    printf "\n# IMX585 Camera\ndtoverlay=imx585\n" | sudo tee -a "$CONFIG_FILE" > /dev/null
    info "Added: dtoverlay=imx585"
fi

section "Installation Complete"
echo ""
echo -e "  ${GREEN}Next steps:${NC}"
echo "  1. Reboot:                       sudo reboot"
echo "  2. Confirm the NEW driver loaded:"
echo "       modinfo -F filename imx585      # must NOT be a .ko.xz"
echo "       dmesg | grep imx585"
echo "  3. List cameras:                 rpicam-hello --list-cameras"
echo ""
echo -e "  ${CYAN}dtoverlay options (edit $CONFIG_FILE):${NC}"
echo "    dtoverlay=imx585              # default: CAM1, color"
echo "    dtoverlay=imx585,cam0         # use CAM0 port"
echo "    dtoverlay=imx585,mono         # mono sensor"
echo "    dtoverlay=imx585,cam0,mono    # CAM0 + mono"
echo ""
echo -e "  ${YELLOW}Note:${NC} this package installs the kernel driver only."
echo "  If rpicam-hello cannot detect the camera, run Package 2 to install libcamera."
echo ""
